﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Invoking_Methods_Using_Named_Parameters
{
    class Invoking_Methods_Using_Named_Parameters
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***** Fun with Methods *****");
            //если передавать параметры по старому, как ты привык, то нужно смотреть заголовок метода и указывать
            //их по порядку. Это не сложно, но придумали еще один способ, который может понравится, а может и нет
            //он заключается в том, что не обязательно передвать параметры по порядку, а можно указывать имя параметра:
            //и далее писать значение, которое мы хотим присвоить такому параметру. Это позволяет не думать
            //о порядке передачи параметров, а явно указывать какой переменной что присваивается
            //в других языках я такого не видел и может быть так, что ты привыкнешь к этому, а потом на другом 
            //языке тебе будет этого не хватать и будет неудобно. Потому я скептически отношусь к таким нововведениям
            //и стараюсь если есть альтернатива - использовать общепринятые нормы

            //итого: не паримся и не используем в будущем!!! но будем готовы к тому, что в чужом коде такое можно
            //встретить и понимаем как это работает

            DisplayFancyMessage(message: "Wow! Very Fancy indeed!", textColor: ConsoleColor.DarkRed,
                backgroundColor: ConsoleColor.White);
            DisplayFancyMessage(backgroundColor: ConsoleColor.Green, 
                message: "Testing...",textColor: ConsoleColor.DarkBlue);
            Console.ReadLine();
        }

        static void DisplayFancyMessage(ConsoleColor textColor, ConsoleColor backgroundColor, string message)
        {
            // Store old colors to restore after message is printed.
            ConsoleColor oldTextColor = Console.ForegroundColor;
            ConsoleColor oldbackgroundColor = Console.BackgroundColor;
            // Set new colors and print message.
            Console.ForegroundColor = textColor;
            Console.BackgroundColor = backgroundColor;
            Console.WriteLine(message);
            // Restore previous colors.
            Console.ForegroundColor = oldTextColor;
            Console.BackgroundColor = oldbackgroundColor;
        }
    }
}
