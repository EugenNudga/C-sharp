﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_1
{
    class Task_1
    {
        static void Main(string[] args)
        {
//            Вывести результаты пяти разных арифметических действий над двумя введенными числами.
//Пример ввода

//1 2

//Пример вывода

//1 + 2 = 3
//1 - 2 = -1
//1 * 2 = 2
//1 / 2 = 0 - здесь показано именнно целочисленное деление, когда дробная часть отбрасывается
//1 % 2 = 1 - % - это операция "остаток от деления, она имеет смысл только для целых чисел"

            Console.Write("Enter any first digit: ");
            //какой конкретно метод выбрать зависит от того, какие максимальные числа нужно вводить
            var dig1 = Convert.ToByte(Console.ReadLine()); //поначалу тут было ToByte, потом ToSingle
            Console.Write("Enter any second digit: ");
            var dig2 = Convert.ToByte(Console.ReadLine());
            
            Console.WriteLine("{0} + {1} = {2}", dig1, dig2, dig1 + dig2);
            Console.WriteLine("{0} - {1} = {2}", dig1, dig2, dig1 - dig2);
            Console.WriteLine("{0} * {1} = {2}", dig1, dig2, dig1 * dig2);
            Console.WriteLine("{0} / {1} = {2}", dig1, dig2, dig1 / dig2);
            Console.WriteLine("{0} % {1} = {2}", dig1, dig2, dig1 % dig2);

            Console.ReadKey();
        }
    }
}
