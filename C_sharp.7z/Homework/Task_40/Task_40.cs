﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_40
{
    class Task_40
    {
        static void Main(string[] args)
        {
            while (true)
            {
                //Вывести числовой квадрат заданного размера.
                //Выведенные числа начинаются с единицы и постоянно увеличиваются.
                //В каждой строке числа разделены пробелами.
                //Порядок строк обратный.
                //Размер считать с клавиатуры.
                //Пример ввода      //2
                //Пример вывода
                //3 4
                //1 2

                //7 8 9
                //4 5 6 
                //1 2 3

                //maxValue = rows * rows;

                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter a positive integer number (amount of rows and columns): ");
                    //назвал n, так как это к-во и строк и столбцов
                    var n = Convert.ToInt32(Console.ReadLine());

                    //второй способ, не такой "очевидный" :)
                    for (var row = 1; row <= n; row++)
                    {
                        for (var column = 1; column <= n; column++)
                        {
                            //выведем формулу, как значение в таблице зависит от строки и столбца
                            //для первой строки: 
                            //9 - 3 + 1 - (1 - 1)*3 = 7 
                            //9 - 3 + 2 - (1 - 1)*3 = 8
                            //9 - 3 + 3 - (1 - 1)*3 = 9
                            //для второй строки: 
                            //9 - 3 + 1 - (2 - 1)*3 = 4 
                            //9 - 3 + 2 - (2 - 1)*3 = 5
                            //9 - 3 + 3 - (2 - 1)*3 = 6
                            Console.Write("{0,3} ", (n*n - n + column) - (row - 1)*n);
                        }
                    }

                    //первый способ, более наглядный
                        //var step = n*n;

                        ////так как нам нужно вывести n строк, в каждой из которых столько же столбцов
                        ////то нужно два цикла, первый перебирает строки, второй столбцы
                        //for (var row = 1; row <= n; row++)
                        //{
                        //    for (var column = 1; column <= n; column++)
                        //    {
                        //        var currentNumber = step - n + column;//9-3+1 = 7   9-3+2 = 8    9-3+3 = 9
                        //        Console.Write("{0,3} ", currentNumber);
                        //    }
                        //    step -= n; //9 - 3 = 6   6 - 3 = 3
                        //    Console.WriteLine();

                        //}

                }
                else
                    break;
            }
            Console.ReadKey();
        }
    }
}
