﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    //получается, что на данный момент класс Person содержит часть той же самой информации, 
    //что и в классах Student|Teacher
    //чтобы избежать этого идеально подходит наследование
    //наследование применяют, когда логично можно сформулировать, что, как в данном случае,
    //и студент и преподаватель являются личностью, у каждой из которых есть имя и адрес 
    //проживания, + еще какая-то специфичная только для этих классов информация
    //будем использовать класс Person как базовый - это нпрашивается само собой
    //единственное что мы чуток переделаем - заменим слово private на protected
    //когда видишь слово protected - так и знай, где-то рядом наследование ;)
    public class Person
    {
        //содержит ФИО и адрес
        //было так:
        //private string _fio;
        //private string _address;
        //protected ведет себя почти как private
        //этих данных не видно нигде больше кроме как в этом классе и всех его наследниках
        //стало:
        protected string _fio;
        protected string _address;

        public Person(string fio, string address)
        {
            _fio = fio;
            _address = address;
        }

        public string FIO
        {
            get { return _fio; }
        }

        public string Address
        {
            get { return _address; }
        }

        //как и гэттэры, можно наследовать и любые другие методы
        //этот класс уже содержит имя и адрес - можно их один раз описать здесь и больше не дублировать 
        //в наследниках, но с маленькой магией :)
        //сначала смотрим, что если больше ничего не делать
        public override string ToString()
        {
            return string.Format("Name: {0}\nAddress: {1}\n", _fio, _address);
        }
    }
}
