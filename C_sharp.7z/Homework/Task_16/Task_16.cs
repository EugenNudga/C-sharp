﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_16
{
    class Task_16
    {
        static void Main(string[] args)
        {
            //Написать функцию
            //int max2(int x, int y)
            Console.Write("Enter a number for x: ");
            var x = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter a number for y: ");
            var y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("The max number is {0}", max(x, y));

            Console.ReadKey();
        }

        static int max(int x, int y)
        {
            //if(x < y)
            //    return y;
            //else
            //    return x;

            return x < y ? y : x;
        }
    }
}
