﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Inheritance
{
    //как видим благодаря наследованию нам не пришлось копипастить и класс оказался вполне даже небольшим
    //проверим теперь на практике, как это все работает в плане использования
    //создай в main по одному объекту каждого класса
    public class Teacher:Person
    {
        //содержит ФИО, адресс проживания, название ВУЗа(перечисление), список групп
        private UniName _uniName;
        private List<string> _groups = new List<string>();

        public Teacher(string fio, string address, UniName uniName):base(fio, address)
        {
            _uniName = uniName;
        }

        //groupName - это имя группы, которую хотим добавить, а _groups - это список имен групп,
        //которые уже добавили
        public void AddGroup(string groupName)
        {
            //здесь маленький ньюанс, добавленные строки мы конечно же должны приводить в цикле, а вот
            //ту строку, которую мы добавляем можно привести только один раз - это повысить скорость
            //поиска повторений
            //var hasGroup = _groups.Any(g => g.ToLower().Contains(groupName.ToLower()));
            //хоть метод Any и не выглядит как цикл, но по факту внутри него цикл запускается
            //и при сравнении каждого элемента с введенной строкой, это введенная строка кодом выше
            //приводилась к нижнему регистру, что занимает некоторое время
            //всегда, если что-то можно вычислить до цикла - выноси в переменную до цикла
            //иначе действие приведения строки groupName к нижнему регистру будет произведено не один раз
            //а столько, сколько элементов в коллекции _groups
            //g.ToLower() приходится оставлять в цикле, потому как мы не хотим изменять то, что ввел
            //пользователь, пусть там хранится то, что он ввел первый раз, но все последующие вводы
            //мы проверяем уже в одном регистре
            //важно, чтобы и первая и вторая строка использовали приведение к одному и тому же регистру
            //не важно какому
            var loweredGroupName = groupName.ToLower();
            var hasGroup = _groups.Any(g => g.ToLower().Contains(loweredGroupName));
            if (hasGroup == true)//есл такое значание есть -> true
                Console.WriteLine("Teacher.AddGroup(): Ding-dong! We already have {0} group =)", groupName);
            else
            {
                Console.Write("Teacher.AddGroup(): ");
                //другой варинт был бы здесь добавлять не то, что пришло в groupName, а значение в 
                //каком либо регистре, но это не всегда понравится пользователю
                //например он всегда вводит все с большой буквы, а мы такие взяли и сделали все маленькими
                //потому надежнее добавлять так, как получили, но перед добавлением сравнивать в каком-либо
                //регистре, разницы нет, главное, чтобы и добавленные строки и та, которая пришла
                //приводились при проверке к одному и тому же
                //_groups.Add(groupName.ToLower());
                _groups.Add(groupName);
                Console.WriteLine("A group {0} was added to the list of groups", groupName);
            }
        }

        public override string ToString()
        {
            var baseClassString = base.ToString();

            //этот способ самый простой, но он плохой тем, что мы каждый раз плюсуем строки
            //переделай это под StringBuilder, как я написал в скайп
            //var groupsInfo = "";
            //for (var i = 0; i < _groups.Count; ++i)
            //    groupsInfo += string.Format("{0}\n", _groups[i]);//можно ещё _pilots[i].Fio
            //1) создаем объект типа StringBuilder
            //как создать объект конкретного типа?
            //var someObj = new ObjectType();
            var groupsInfo = new StringBuilder();
            //2) в цикле добавляем в него каждый элемент коллекции, которую преобразовываем в строку
            for(var i = 0; i < _groups.Count; ++i)
                //если бы у тебя был массив объектов, то былобы что-то типа этого
                //groupsInfo.Append(string.Format("{0}, ", _groups[i].GroupName));
                //но у тебя массив строк, следовательно каждый элемент - обычная строка, с которой не нужно
                //проводить дополнительных действий
                //у тебя каждый элемент списка _groups - это уже название группы, а не объект
                //одним из элементов которого есть это название
                groupsInfo.Append(string.Format("{0}, ", _groups[i]));
            //3) после цикла объект StringBuilder

            //содержит ФИО, адресс проживания, название ВУЗа(перечисление), список групп
            return string.Format("{0}Uni name: {1}\nList of groups: {2}",
                baseClassString, _uniName, groupsInfo);
        }
    }
}
