﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_47
{
    class Task_47
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    //Вывести N-ное по счёту простое число (см.Википедию).
                    //N считать с клавиатуры.
                    //Оптимизировать работу программы, насколько это возможно.
                    //В случае неопределенности ответа вывести - 1.
                    //Пример ввода      //3
                    //Пример вывода     //5
                    Console.Write("\nEnter a number for n: ");
                    var n = Convert.ToInt32(Console.ReadLine());

                    int result = isPrime(n);
                    if (result == 0)
                    {
                        Console.WriteLine("{0} is not a prime number", n);
                    }
                    else
                    {
                        Console.WriteLine("{0} is a prime number", n);
                    }
                }
                else
                    break;
            }
            Console.ReadKey();
        }

        static int isPrime(int n)
        {
            int i;
            for (i = 2; i <= n - 1; i++)
            {
                if (n % i == 0)
                {
                    return 0;
                }
            }
            if (i == n)
            {
                return 1;
            }
            return 0;
        }
    }
}
