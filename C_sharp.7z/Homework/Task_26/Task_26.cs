﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_26
{
    class Task_26
    {
        static void Main(string[] args)
        {
            //Считать min, max. Вывести в столбик чётные числа от min до max включительно.
            //Пример ввода      //0 8
            //Пример вывода     //0 2 4 6 8

            while (true)
            {
                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter a min integer number: ");
                    var min = Convert.ToByte(Console.ReadLine());
                    Console.Write("Enter a max integer number: ");
                    var max = Convert.ToByte(Console.ReadLine());

                    for (var output = min; output <= max; output++)
                    {
                        if ((output % 2) == 0)
                            Console.Write("{0} ", output);
                    }
                    Console.WriteLine();
                }
                else
                    break;
            }

        Console.ReadKey();
        }
    }
}
