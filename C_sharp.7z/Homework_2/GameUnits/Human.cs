﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameUnits
{
    public class Human : Unit
    {
        //живое существо, которое в будущих классах наследниках может быть пехотинцем, медиком, летчиком, танкистом и тп.
        //Дополнительно хранит: мужчина или женщина, военный или гражданский,
        private bool _isMale;
        private bool _isMilitary;

        public Human(string name, float health, float maxSpeed, bool isMale, bool isMilitary) :
            base(name, health, maxSpeed, false, true, true)
        {
            Console.WriteLine("Human constructor for {0}", name);
            _isMale = isMale;
            _isMilitary = isMilitary;
        }

        public void Heal(float healingPotion)
        {
            _health += healingPotion;
            if (_health > _maxHealth)
                _health = _maxHealth;
        }

        public override string ToString()
        {
            return string.Format("Name: {0}\nHealth: {1}\nMaxSpeed: {2}\nIs male: {3}\nIs military: {4}",
                _name, _health, _maxSpeed, _isMale, _isMilitary);
        }
    }
}
