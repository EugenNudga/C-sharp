﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//здесь в метод мы передаем не адрес переменной valueToDelete, который бы позволил
//изменить значение этой переменной, а только ее значение, что не дает методу повлиять
//на эту переменную здесь. Даже если попытаться это значение изменить в методе
//такой принцип передачи не адреса, а копирования значения из переменной применяется
//для переменных типа int, unsigned short, float, double, bool и тп. 
//Их в C# называют примитивными типами или типами значений
//принципиально другим типом есть объекты, которые всегда передаются в методы по адресу
//в С++ для этого мы использовали указатели, в нормальных языках все максимально упрощено
//если переменная хранит объект (ими являются любые классы, как например класс List),
//то в метод не копируются элементы этого списка, там не создается его копия,
//а просто копируется адрес в памяти, где этот список начинается
//это намного быстрее, так как для копирования адреса нужно скопировать всего лишь несколько байт
//(обычно 4) независимо от к-ва элементов в списке, а для полноценного копирования списка
//понадобилось бы передать абсолютно все элементы. Для списка из 1млн int = 4 млн байт
//по памяти это расточительно и могло бы быть очень долго
//еще раз, все что не простой тип данных "тип значение", например числа и тп - передаются копированием
//https://docs.microsoft.com/ru-ru/dotnet/csharp/language-reference/keywords/value-types
//все остальное - объекты или ссылочные типы данных, передаются копированием адреса
//https://docs.microsoft.com/ru-ru/dotnet/csharp/language-reference/keywords/reference-types

//для тебя выглядит, что не важно какой тип, он попадает в переменную в методе и все работает
//ссылочные типы в C# визуально не отличаются от типов-значений
//это хорошо, так как упрозает написание и читание кода, но нужно понимать как это работает внутри
namespace ValueTypeAndReferenceType
{
    class REF_and_OUT
    {
        //когда из метода нужно получить одно единственное значение, то это функция
        //тип результата которой не void, например здесь int - так как нужно вернуть к-во
        static int CalcPositiveNumbers(List<int> numbers)
        {
            var sum = 0;
            for (var i = 0; i < numbers.Count; ++i)
                if (numbers[i] > 0)
                    sum += numbers[i];

            return sum;
        }

        //если же нужно вернуть более одного значения, то вопрос, как это сделать?
        //на ум может придти что-то типа
        //static int, int, int CalcPositiveNegativeAndZero(List<int> numbers)
        //и в коде написать return negCounter, positiveCounter, zeroCounter;
        //но так не работает в типизированных языках
        //вторая идея, просто выводить Console.Write в методе на экран, 
        //но что если нужно вернуть из метода реально больше одного значения?
        //можно придумать что-то типа
        //static void CalcPositiveNegativeAndZero(List<int> numbers, int negsCount, int positiveCounter, int zeroCounter)
        //и в методе подсчитать все значения
        static void InvalidCalcPositiveNegativeAndZero(List<int> numbers, int negsCount, int positiveCounter, int zeroCounter)
        {
            positiveCounter = 0;
            negsCount = 0;
            zeroCounter = 0;
            for (var i = 0; i < numbers.Count; ++i)
                if (numbers[i] > 0)
                    positiveCounter++;
                else if (numbers[i] < 0)
                    negsCount++;
                else
                    zeroCounter++;
            //и будем надеятся, что потом в месте откуда вызовем метод полученные значения изменятся
            //но надежды были тщетны :)
            //как я раньше сказал, то, что ты меняешь в методе локальные переменные "типа значение" 
            //никак не отражается на переменных, которые были переданы в метод
        }

        //В C# правильно решать так
        //как видишь все свелось только к дописыванию слова ref перед переменными, которые нужно
        //передать по ссылке, и в месте вызова этих методов
        //обрати внимания, что если бы это были указатели С++, то звездочку пришлось бы писать везде!
        //здесь же слово ref только в заголовке!

        //как видишь, во всем остальном метод CalcPositiveNegativeAndZero абсолютно идентичен
        //методу InvalidCalcPositiveNegativeAndZero

        //что еще нужно понять из этого примера?
        //что для объектов ссылочного типа не нужно писать слово ref, но считается, что оно там
        //дописывается автоматически. Так как List - это объект, то ему ref не пишем, но он всегда работает как ref
        //объекты все, что не числа и подобные значения!
        //Именно по-этому метод RemoveValues работает как ожидается - удаляет из списка значения в методе
        //а потом в другом мы видим эти изменения
        static void CalcPositiveNegativeAndZero(List<int> numbers, ref int negsCount, ref int positiveCounter, ref int zeroCounter)
        {
            positiveCounter = 0;
            negsCount = 0;
            zeroCounter = 0;
            for (var i = 0; i < numbers.Count; ++i)
                if (numbers[i] > 0)
                    positiveCounter++;
                else if (numbers[i] < 0)
                    negsCount++;
                else
                    zeroCounter++;
        }

        //для закрепления, все объекты переданные в метод могут быть изменены в этих методах!
        //для этого не нужно их возвращать из метода и не нужно писать слово ref, компилятор позволяет, но в этом нет смысла
        //они передаются только по ссылке
        //а обычные значения по умолчанию изменить в методе нельзя, так как они передаются по значению, но слово ref
        //позволяет передавать их по ссылке и, следовательно, менять в методах
        static void RemoveValues(List<bool> trueOrFalse, bool valueToDelete)
        {
            for (var i = 0; i < trueOrFalse.Count;)
            {
                if (trueOrFalse[i] == valueToDelete)
                    trueOrFalse.RemoveAt(i);
                else
                    ++i;
            }
            //нужно понять, что переменная valueToDelete никак не связана с одноименной переменной 
            //в месте, откуда вызван метод
            valueToDelete = true;
        }

        static void AddNValues(List<int> numbers, int value, int count)
        {
            for (var i = 0; i < count; i++)
                numbers.Add(value);
        }

        static void Main(string[] args)
        {
            var numbers = new List<int>() { 10, -1, 20, 0, -5, 11 };
            int posCounter = 0, negCounter = 0, zeroCounter = 0;
            //так не работает!
            //мы просто скопировали 0 в метод, но назад никогда так ничего не получим
            //нам нужно как-то сказать компилятору, что мы хотим не копировать значения этих
            //переменных, а хотим передать их адрсе, чтобы метод получил возможность
            //изменить значения этих переменных
            InvalidCalcPositiveNegativeAndZero(numbers, posCounter, negCounter, zeroCounter);
            Console.WriteLine("posCounter = {0}, negCounter = {1}, zeroCounter = {2}", posCounter, negCounter, zeroCounter);
            //когда мы дописали слово ref (от слова reference - ссылка) - 
            //мы говорим компилятору, передавай в метод не значение переменной, а ее адрес
            //точнее, ссылку на нее, но по факту адрес :)
            //и так уже изменение переменной в методе будет менять переменную, которая туда была передана
            CalcPositiveNegativeAndZero(numbers, ref posCounter, ref negCounter, ref zeroCounter);
            Console.WriteLine("posCounter = {0}, negCounter = {1}, zeroCounter = {2}", posCounter, negCounter, zeroCounter);

            //добавим в список 10 значений 0одним методом
            AddNValues(numbers, 0, 10);
            CalcPositiveNegativeAndZero(numbers, ref posCounter, ref negCounter, ref zeroCounter);
            Console.WriteLine("posCounter = {0}, negCounter = {1}, zeroCounter = {2}", posCounter, negCounter, zeroCounter);

            Console.ReadKey();
        }
    }
}
