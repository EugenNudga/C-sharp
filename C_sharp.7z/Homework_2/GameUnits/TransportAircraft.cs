﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameUnits
{
    public class TransportAircraft : Flying
    {
        //транспортник без вооружения, только перевозит технику или людей.
        //Дополнительно содержит: максимальный вес груза, текущий вес груза,
        //максимальное количество пассажиров, сколько сейчас пассажиров

        private float _maxCargoWeight;
        private float _cargoWeight;
        private int _maxAmountOfPassengers;
        private int _amountOfPassengers;

        //обычно конструктор подразумевает создание объекта как типа с завода, не всегда, но 
        //чаще всего, потому можно немного упростить передачу количество грузов и пассажиров
        //скажем, что по умолчанию они равны 0, но при желании их можно будет таки указать
        public TransportAircraft(string name, float health, float maxSpeed, float maxHeight,
            float upSpeed, int crewSize, float maxCargoWeight, int maxAmountOfPassengers,
            //написать так нельзя, компилятор разрешает помещать необязательные параметры только подряд
            //и только последними в списке, потому мы немного изменим их порядок, чтобы было можно
            //float cargoWeight = 0, int maxAmountOfPassengers, int amountOfPassengers = 0) :
            float cargoWeight = 0, int amountOfPassengers = 0) :
            base(name, health, maxSpeed, maxHeight, upSpeed, crewSize)
        {
            _maxCargoWeight = maxCargoWeight;
            _cargoWeight = cargoWeight;
            _maxAmountOfPassengers = maxAmountOfPassengers;
            _amountOfPassengers = amountOfPassengers;
        }
    }
}
