﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework_Ref_Out
{
    class Homework_Ref_Out
    {
        static int IsValueInList(List<string> test, string word)
        {
            for ( int i = 0; i < test.Count; ++i )
            {
                if (test[i] == word)
                    return 1;
            }
            return -1;
        }

        static int IsValueInListIgnoreCase(List<string> test, string word)
        {
            for (int i = 0; i < test.Count; ++i)
            {
                if (test[i].ToLower() == word.ToLower())
                    return 1;
            }
            return -1;
        }

        static void PrintListOnScreen(List<string> test)
        {

            Console.Write("[ ");
            for (var i = 0; i < test.Count - 1; ++i)
            {
                Console.Write("{0}, ", test[i]);
            }
            //эти две строки можно заменить одной ;)
            //Console.Write("]");
            //Console.WriteLine();
            //он сначала выводит текст, а потом уже переводит курсор на следующую строку :)
            Console.WriteLine("{0} ]", test.Last());
        }

        static void Main(string[] args)
        {
            //домашнее задание:
            //написать методы, похожие на методы поиска факта наличия, которые мы с тобой написали
            //но пусть возвращают - 1, если элемент не найден
            //или индекс элемента, который нашли
            //первый метод без учета регистра
            //второй с учетом

            var test = new List<string>() { "shift", "lever", "crank", "arm", "April", "fool", "banana" };

            Console.WriteLine("Enter a word you wanna find in the list: ");
            var word = Convert.ToString(Console.ReadLine());

            PrintListOnScreen(test);
            IsValueInList(test, word);
            IsValueInListIgnoreCase(test, word);
        }
    }
}
