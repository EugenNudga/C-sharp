﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Olympic_Subject
{
    public enum Subjects { swimming, football, real_Life, parkour };
    public enum Countries { Ukraine, Germany, Zimbabwe, USA, Japan, Galaluna };

    public class OlympicSubject2
    {
        private Countries _firstPlaceCountry;
        private Countries _secondPlaceCountry;
        private Countries _thirdPlaceCountry;
        private Subjects _subject;
        //сделай гэттэр для поля _subject ;)
        public Subjects Subjects
        {
            get { return _subject; }
        }

        public OlympicSubject2(Subjects subject, Countries firstPlaceCountry, Countries secondPlaceCountry, Countries thirdPlaceCountry)
        {
            _subject = subject;
            _firstPlaceCountry = firstPlaceCountry;
            _secondPlaceCountry = secondPlaceCountry;
            _thirdPlaceCountry = thirdPlaceCountry;
        }
        //я показал, как сделать конструктор, который принимает не перечисления, а строки
        //но строки это другой тип и нет простого способа преобразовать из строки в перечисление
        //внутри этого конуструктора мы не написали никакого кода, потому всем полям были
        //присвоены значения по умолчанию, которыми в перечислениях являются те, которые равны 0
        //по умолчанию это значения первые в перечислениях
        //с одной стороны, строки немного проще, что не нужно подготавливать перчисление
        //но это палка о двух концах, перечисления позволяет выбирать только из предложенного списка
        //что упрощает работу с кодом и не дает сделать ошибки
        //рекомендую использовать в случае, когда заведомо известен ограниченный список значений,
        //исключительно перечисления - они быстрее и занимают меньше памяти
        public OlympicSubject2(string subject, string firstPlaceCountry, string secondPlaceCountry, string thirdPlaceCountry)
        {
            //_subject = subject;
            //_firstPlaceCountry = firstPlaceCountry;
            //_secondPlaceCountry = secondPlaceCountry;
            //_thirdPlaceCountry = thirdPlaceCountry;
        }
        //получается, если есть enum, то надо ещё один конструктор без полей создавать?
        public OlympicSubject2()
        {
            _subject = Subjects.swimming;
            _firstPlaceCountry = Countries.Ukraine;
            _secondPlaceCountry = Countries.Galaluna;
            _thirdPlaceCountry = Countries.Germany;
        }

        public override string ToString()
        {
            return string.Format("In {0} we have such results:\n1st place: {1}\n2nd place: {2}\n3rd place: {3}",
                _subject, _firstPlaceCountry, _secondPlaceCountry, _thirdPlaceCountry);
        }
    }
}
