﻿namespace Enum_Variables
{
    //паблик нужно писать, так как по умолчанию все private и его не будет видно в других файлах
    public enum MyEnum
    {
        First, Second, Third
    }
}