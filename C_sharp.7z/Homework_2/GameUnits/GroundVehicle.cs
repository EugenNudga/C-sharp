﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameUnits
{
    public class GroundVehicle : Vehicle
    {
        //техника, которая может двигаться по земле.
        //Дополнительно хранит: массу, количество членов экипажа
        protected float _weight;

        public GroundVehicle(string name, float health, float maxSpeed, float weight, int crewSize) :
            base(name, health, maxSpeed, false, false, true, crewSize)
        {
            _weight = weight;
        }
    }
}
