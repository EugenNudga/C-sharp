﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_15
{
    class Task_15
    {
        static void Main(string[] args)
        {
            //Написать функцию
            //int sum(int x, int y)
            Console.Write("Enter a number for x: ");
            var x = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter a number for y: ");
            var y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("The sum is {0}", sum(x, y));

            Console.ReadKey();
        }

        static int sum(int x, int y)
        {
            return x + y;
        }
    }
}
