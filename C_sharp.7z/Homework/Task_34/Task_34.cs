﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_34
{
    class Task_34
    {
        static void Main(string[] args)
        {
            while (true)
            {
                //Считать с клавиатуры три целых числа -первый член, шаг
                //и количество членов арифметической прогрессии.
                //Вывести в строку через пробел члены заданной прогрессии.
                //Задаваемое количество больше нуля.
                //Пример ввода      //12 2 4
                //Пример вывода     //12 14 16 18

                //в арифметической прогресии стартовое число может быть отрицательным, равно как и шаг
                //-10 -2 4
                //-10 -12 -14 -16
                //-10 2 4
                //-10 -8 -6 -4

                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter a integer number (from which we will start): ");  //
                    var initialValue = Convert.ToByte(Console.ReadLine());
                    Console.Write("Enter a integer number (which will be used for adding to first number): ");  //
                    var step = Convert.ToByte(Console.ReadLine());
                    Console.Write("Enter a positive integer number (amount of additions): ");  //
                    var amount = Convert.ToByte(Console.ReadLine());

                    //запомни простую запись, если тебе нужно выполнить цикл n раз, всегда незадумываясь пиши
                    //for(var i = 0; i < n; i++), если нужно начинать с 0
                    //если же нужно начать с 1, тогда
                    //for(var i = 1; i <= n; i++)
                    //но когда нужно перебирать в обратном порядке, то немного не так
                    //for (var i = n - 1; i >= 0; i++) - если нужно для числа 5 получить индексы 4 3 2 1 0
                    //for (var i = n; i >= 1; i++) - если нужно для числа 5 получить индексы 5 4 3 2 1
                    //for (var i = n; i > 0; i++) - еще вариант, если нужно для числа 5 получить индексы 5 4 3 2 1

                    //тот редкий случай, когда нужно явно указать тип
                    //мы присваиваем значение типа byte переменной, которая в сумме может стать больше чем этот тип
                    //потому мы явно указываем тип переменной int
                    int sum = initialValue;
                    for (var i = 0; i < amount; i++)
                    {
                        //было так, ты всегда к тому, что ввел в первое число, например 12, прибавлял шаг
                        //следовательно всегда получал 14
                        //sum = initialValue + step;
                        //при чем делал это до вывода, следовательно стартовое число, которое тоже нужно вывести
                        //пропускал. Если же сначала вывести сумму, которой раньше присвоили стартовое число
                        Console.Write("{0} ", sum);
                        //а потом уже прибавляем к сумме шаг и получаем новое число
                        //и так amount раз
                        sum += step;
                    }
                    Console.WriteLine();

                    //выше вполне рабочий способ, который лишний раз демонстрирует, что в вопросе оптимальности можно
                    //жертвовать либо скоростью, либо памятью
                    //в этой простой задаче жертва памятью всего лишь в лишней переменной sum, без которой можно обойтись
                    //код ниже немного короче, так как без дополнительной переменной, но будет работать немного
                    //медленнее, так как сложение быстрее умножения
                    for (var i = 0; i < amount; i++)
                        //это равносильно тому, что для i = 0 записать 12 + 2*0 = 12
                        //для i = 1 => 12 + 2*1 = 14
                        //для i = 2 => 12 + 2*2 = 16 и тд.
                        Console.Write("{0} ", initialValue + step*i);

                    Console.WriteLine();
                    //на самом деле, можно еще хитрее сделать, на столько оператор for гибкий
                    var maxValue = initialValue + step * (amount - 1);
                    for(var value = initialValue; value <= maxValue; value += step )
                        Console.Write("{0} ", value);

                    Console.WriteLine();
                }
	            else
		            break;
            }
            Console.ReadKey();
        }
    }
}
