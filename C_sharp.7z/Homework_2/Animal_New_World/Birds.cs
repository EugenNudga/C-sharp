﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal_New_World
{
    public class Birds : Animals
    {
        //птицы пусть дополнительно содержат: размах крыльев, максимальную высоту полета,
        //признак "перелетные или постоянно живущие", для перелетных -на какое максимальное расстояние летают

        protected int _wingspan;
        protected int _maxFlyHeight;
        protected bool _isMigratory;
        protected int _maxMigrationDistance;
        //вот так. Но есть прикол, C# гарантированно присваивает всем переменным значение по умолчанию. Для типа bool это false, для int - это 0
        //потому писать _isInAir = false избыточно, достаточно просто описать переменную
        //private bool _isInAir = false;
        //Читаем задание: просто присвой ему false. (При рождении все птицы сидят)
        //для того, чтобы протестировать как изменяется это поле нужно просто несколько раз вызвать метод Fly
        protected bool _isInAir;

        //если какой-то из параметров базового класса всегда получает одно и то же значение, то конечно же нет нужды заставлять 
        //передавать параметр, который еще может быть с ошибкой
        //параметр maxMigrationDistance получается необязательный, потому мы дали ему значение по-умолчанию
        //если вводим, что птица неперелетная, то можно последний параметр не передавать и там подставится 0 автоматически
        //даже если мы передадим какое-то значение, MigrationString будет его игнорировать, так как там проверка на поле _isMigratory
        //public Birds(string name, int age, int weight, bool canSwim, bool isPredator,
        //    int wingspan, int maxFlyHeight, bool isMigratory, int maxMigrationDistance = 0) :
        //    base(name, age, weight, TypeOfReproduction.egg, canSwim, true, isPredator)
        //{
        //    _wingspan = wingspan;
        //    _maxFlyHeight = maxFlyHeight;
        //    _isMigratory = isMigratory;
        //    _maxMigrationDistance = maxMigrationDistance;
        //}

        //необязательное поле можно было еще обыграть по другому, создадим пример другого конструктора
        //если мы передаем дистанцию миграции, тогда птица автоматически перелетная, не передаем ничего или 0 - неперелетная
        //так надежнее, система гарантировано правильно выставитт флаг и реальная дистанция будет только у перелетных птиц
        public Birds(string name, int age, int weight, bool canSwim/*, bool canFly*/, bool isPredator, int levelOfFullness,
            int wingspan, int maxFlyHeight, int maxMigrationDistance = 0) :
            base(name, age, weight, TypeOfReproduction.egg, canSwim, true, isPredator, levelOfFullness)
            //так можно вычислить умение летать, но мы решили, что это не лучший вариант
            //base(name, age, weight, TypeOfReproduction.egg, canSwim, maxFlyHeight > 0, isPredator, levelOfFullness)
        {
            //этот код вызывается после вызова base, потому нет возможности в base() обратиться к значению, которое будет присвоено ниже
            _wingspan = wingspan;
            _maxFlyHeight = maxFlyHeight;
            _isMigratory = maxMigrationDistance > 0;
            _maxMigrationDistance = maxMigrationDistance;
            //да, так можно конечно, но можно это делать прямо в месте создания переменой, так надежнее
            //_isInAir = false;
        }

        //создай в классе Bird виртуальный метод Fly(bool flag), который изменяет значение поля _isInAir
        //если flag равняется true - выводит сообщение "птица такая-то летит",
        //если flag равняется false и _isInAir до вызова метода равнялся true - выводит сообщение "птица такая-то села",
        //иначе выводит сообщение "птица такая-то сидит"
        public virtual void Fly(bool flag)
        {
            //ты должен присваивать переменной _isInAir значение, которое мы передали в этот метод, но только уже после всех проверок
            //когда я пишу условия как выше - это подразумевает конструкцию if.. else if..else if..else
            //смотри, наши кейсы проверяют текущее значение с тем, которое пришло, потому мы не можем сразу написать так
            //_isInAir = flag;
            //этот код теперь правильный, но немного не оптимальный. Новичку понятнее так, но ниже пишу, как бы написал программист среднего уровня и выше
            //if (flag == true)
            //    Console.WriteLine("{0} is flying", _name);
            //else if (flag == false && _isInAir == true)
            //    Console.WriteLine("{0} landed on some spot", _name);
            //else
            //    Console.WriteLine("{0} is sitting", _name);
            //булевую переменную никогда не сравнивают на == true. Если просто написать имя переменной это тоже самое. Если нужно проверить ее на false
            //пишут !flag, это равнозначно тому, что написать flag != true или flag == false, но намного короче
            if (flag)
                Console.WriteLine("{0} is flying", _name);
            //следующий момент
            //сюда мы можем попать только если flag == false, следовательно еще раз проверять это нет смысла и эту проверку можно выбросить вообще
            //это называется упрощение выражений в коснтрукции if..esle if..else. В каждый следующий блок ниже мы попадаем только тогда, когда проверка
            //выше оказалась ложью. Выше была проверка на то, что flag == true, следовательно, если мы ниже - он != true, ну или ==false, что ты писал явно
            //_isInAir тоже упростили из вида _isInAir == true, по той же причине, почему и flag == true выше
            //ты можешь конечно писать как писал выше - компилятору не важно, он понимает и так и так, но нужно стремиться к тому, чтобы уметь писать как
            //здесь, потому, что в реальных компаниях люди пишут именно так, а ты должен понимать чужой код
            //можешь сначала писать как тебе понятнее, а потом пробовать ниже написать упрощенную версию для тренировки, чтобы быстрее научиться
            else if (_isInAir)
                Console.WriteLine("{0} landed on some spot", _name);
            else
                Console.WriteLine("{0} is sitting", _name);
            //после всех проверок - это под ними. После того, как мы обработали все ситуации, мы можем присвоить переменной новое значение
            //если это не сделать, то птица всегда будет в начальном состоянии
            _isInAir = flag;
        }

        //как видим, стоило нам написать только слово override и поставить пробел - IDE сразу предложило список методов, которые 
        //определены в базовом классе как виртуальные и которые можно переопределить
        //так же IDE сразу нам дописало код, который вызывает такой же метод у базового класса
        //так как мы договорились, что у Animals метод пустой, то и вызывать его нет смысла, потому мы напишем только свой код
        public override void Voice()
        {
            //здесь мы по простому выведем, что кто-то издал звук, не указывая какой- пока этого будет достаточно, чтобы отличить его от звука другого класса
            Console.WriteLine("{0} makes a typical \"birdie\" sound (if shown twice -> look into Birds -> method Eat and you will see two Voice(); )", _name);
        }

        public override void Eat(int amount)
        {
            //смотри, сначала кормим, после проверяем:
            //птица сыта на 100% - не издаёт звука, если нет - издает два звука
            base.Eat(amount);
            //не выводится, потому, что _levelOfFullness == 100
            if (_levelOfFullness < 100)
            {
                Voice();
                Voice();
            }
        }

        //если бы мы хотели получать как текст строку "перелетная, до 2000км" для перелетных или "неперелетная" для неперелетных
        //то можно создать такой гэттер
        public string MigrationString
        {
            get
            {
                //string.Format нужен только если тебе нужно слепить строку, где есть текс + значения переменных
                return _isMigratory ? string.Format("перелетная, до {0} км", _maxMigrationDistance) : "неперелетная";
            }
        }

        public int Wingspan
        {
            get { return _wingspan; }
        }

        public override string ToString()
        {
            var animalInfo = base.ToString();
            return string.Format("{0}\nWingspan: {1}m\n{2}", animalInfo, _wingspan, MigrationString);
        }
    }
}