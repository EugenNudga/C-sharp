﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StringBuilderTest
{
    class StringBuilderTest
    {
        static void Main(string[] args)
        {
            FunWithStringBuilder();
        }

        static void FunWithStringBuilder()
        {
            Console.WriteLine("=> Using the StringBuilder:");
            StringBuilder sb = new StringBuilder("**** Fantastic Games ****");
            sb.Append("\n");
            sb.AppendLine("Half Life");
            sb.AppendLine("Morrowind");
            sb.AppendLine("Deus Ex" + "2");
            sb.AppendLine("System Shock");
            Console.WriteLine(sb.ToString());
            sb.Replace("2", " Invisible War");
            Console.WriteLine(sb.ToString());
            Console.WriteLine("sb has {0} chars.", sb.Length);
            Console.WriteLine();

            //этот класс нужен для того, чтобы эффективно с точки зрения памяти и скорости создавать строку из нескольки других
            //так код выше создает одну большую строку, в которой есть символы переноса
            //его можно заменить, и многие новички заменяют!, таким кодом
            var badTechnic = "**** Fantastic Games ****" + "\n" + "Half Life\n" + "Morrowind";//ну и так далее
            //каждая операция сложения из двух соседних строк делает одну, в которую последовательно копирует их содержимое
            //и так для каждого +. Для такой простой программы это не особо страшно, но если делать такое часто в 
            //какой-то высоконагруженной программе, то это может стать проблемой. Если такое написать пару раз
            //ничего страшного не произойдет, но рекомендуют сразу не доводить до проблем, а писать код граммотно
            //нужно сложение большого количества строк - используй StringBuilder
            //обычно новички + часто ставят в Console.Write, так вместо способа, который я тебе показал
            //Console.Write("a = {0}, b = {1}, c = {2}", a, b, c); 
            //часто можно увидеть Console.Write("a = " + a + ", b = " + b + ", c = " + ");
            //такой код вроде быстрее написать, но потом не так то и удобно читать, а уж скорость его работы
            //значительно ниже первого. Потому то я тебе сразу показал только первый и молчал о втором
            //который ты использовал в Java, хотя там подобное можно записать:
            //Console.Write("a = %d, b = %d, c = %d", a, b, c);
            //удобство варианта C# в том, что тебе не нужно знать типы переменных, компилятор сам их поймет
            //а в Джава тебе нужно было знать букву для каждого типа данных
            var a = 10;
            var b = "some string";
            var c = true;
            //этот способ нравится новичкам, но я крайне не рекомендую его использовать
            //это не StringBuilder
            Console.Write("a = " + a + ", b = " + b + ", c = " + c);
            Console.WriteLine();
            //если бы тебе нужно было слепить строку типа Console.Write("a = " + a + ", b = " + b + ", c = " + c);
            //используя его, то пришлось бы написать код
            var sb2 = new StringBuilder();
            sb2.Append("a = ");
            sb2.Append(a);
            sb2.Append(", b = ");
            sb2.Append(b);
            sb2.Append(", c = ");
            sb2.Append(c);

            Console.WriteLine(sb2);

            //если нам нужно записать то, что выводим на экран в строковую переменную, то удобнее
            //чем StringBuilder использовать строковую интерполяцию
            //по синтаксису она очень похожа на то, что делаем для Console.Write
            //если мне нужно получить строку, которая содержит какой-то текст и значения каких-то переменных
            //то я пишу так - это удобнее StringBuilder, но так же эффективно
            var resultString = string.Format("a = {0}, b = {1}, c = {2}", a, b, c);
            Console.WriteLine(resultString);
            //если значение в переменной не нужно, то делаем как и раньше
            Console.WriteLine("a = {0}, b = {1}, c = {2}", a, b, c);

            Console.ReadKey();
        }
    }
}
