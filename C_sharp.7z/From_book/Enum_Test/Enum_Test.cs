﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enum_Test
{
    //обычно не заморачиваются и после двоеточия ничего не пишут enum EmpType. Это эквивалентно записи
    //enum EmpType : int    
    //но если мы хотим поэкономить память и точно знаем, что значения перечисления не вылезут за какой-то тип
    //то можно указать тип меньше int, ну или больше, если вдруг 2 млрд комбинаций не хватит :)
    //другими словами, по факту, когда ты создаешь переменную типа перечисление, ты создаешь числовую переменную
    //через двоеточие можно указать сколько байт она будет занимать и так экономить память.
    //на текущем этапе можно не заморачиваться
    enum EmpType : byte
    {
        Manager, // = 0
        Grunt, // = 1
        Contractor, // = 2
        VicePresident // = 3

        //Manager = 102,
        //Grunt,        // = 103
        //Contractor,   // = 104
        //VicePresident // = 105

        // Elements of an enumeration need not be sequential!
        //Manager = 10,
        //Grunt = 1,
        //Contractor = 100,
        //VicePresident = 9
    }

    class Enum_Test
    {
        static void Main(string[] args)
        {
            //EmpType profession = EmpType.Manager;
            var profession = EmpType.Manager;
            
            //любое значения enum можно приравнять (привести) к числу и получить именно числовое значение
            //чаще всего в этом нет никакого смысла, важно само слово, а не число, но если нужно число, то так
            Console.WriteLine("{0}: {1}", profession, (byte)profession);

            Console.ReadKey();
        }
    }
}
