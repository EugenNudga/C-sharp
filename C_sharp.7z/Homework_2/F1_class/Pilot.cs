﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace F1_class
{
    class Pilot
    {
        //ФИО, команда(из перечисления), проведенное к-во этапов,
        //сколько раз был в тройке победителей этапа, очки

        private string _fio;
        //перечисление хранит только короткое имя
        private Teams _team_name;
        //а класс абсолютно всю информацию
        //никто не запрещает хранить ссылку на любой класс внутри другого
        private Team _team;
        private int _amountOfStages;
        private int _stagesWon;
        private int _score;

        public Pilot(string fio, int amountOfStages, int stagesWon, int score)
        {
            _fio = fio;
            _amountOfStages = amountOfStages;
            _stagesWon = stagesWon;
            _score = score;
            _team_name = Teams.None;
        }

        //отличие от создания метода в том, что после имени, нету скобок
        //и то, что внутри первой пары фигурных скобок стоит get, после которого еще одна пара 
        //скобок, которая уже и определяет, что делает гэттэр - возвращает значение поля
        public string Fio
        {
            get { return _fio; }
        }
        //не обязательно, что гэттер просто возвращает какое-то поле
        //он может выполнять какую-то дополнительную работу
        //гэттэров может быть произвольное количество и имена тоже могут быть любыми
        //но обычно придерживаются правиал, что они начинаются с большой буквы
        //ну и camel style, ну и осмысленное название тому, что возвращается
        public string ShortFio
        {
            get
            {
                //ищем позицию первого пробела в строке
                var firstSpacePosition = _fio.IndexOf(" ");
                //IndexOf возвращает индекс найденной строки или -1, если ее нет
                //следовательно firstSpacePosition != -1 - когда пробел найден
                if (firstSpacePosition != -1)
                {
                    //Substring возвращает строку, которая содержит только число символов
                    //переданное как параметр, firstSpacePosition в данном случае
                    //в нашем случае это все, что будет до первого пробела
                    //Substring(0, n) - говорит возьми от 0 симола n символов
                    //было Substring(n) - говорило возьми все символы от позиции n до конца
                    //что не то, что нам было нужно
                    var shortString = _fio.Substring(0, firstSpacePosition);
                    //var shortString = _fio.Substring(firstSpacePosition);
                    return shortString;
                }
                //else можно не писать, так как выше return, но тебе так будет понятнее пока
                else
                    //получается если пробелов не найдено, то короткое имя равно полному
                    return _fio;
            }
        }

        //здесь можно было бы сделать поле любого типа
        //например типа Team - это все, что мы храним о команде
        //public void AssignTeam(Team team)
        //{
        //    _team = team;
        //}

        //а перечисление - это только короткий идентификатор, которого в нашем примере
        //было достаточно. У команды же можно спросить и идентификатор и любую другую 
        //информацию, для которой будут сделаны гэттэры
        public void AssignTeam(Teams teamID)
        {
            //var currentPilot = this;
            _team_name = teamID;
        }

        //ФИО, команда(из перечисления), проведенное к-во этапов,
        //сколько раз был в тройке победителей этапа, очки
        public override string ToString()
        {
            return string.Format("FIO: {0} team: {1} amount of stages: {2} stages won: {3} score: {4}",
                Fio, _team_name, _amountOfStages, _stagesWon, _score);
        }
    }
}
