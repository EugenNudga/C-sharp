﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_39
{
    class Task_39
    {
        static void Main(string[] args)
        {
            while (true)
            {
                //Вывести числовой квадрат заданного размера.
                //Выведенные числа начинаются с единицы и постоянно увеличиваются.
                //В каждой строке числа разделены пробелами.
                //Размер считать с клавиатуры.
                //Пример ввода      //2
                //Пример вывода
                //1 2
                //3 4
                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter a positive integer number (amount of rows): ");
                    var rows = Convert.ToInt32(Console.ReadLine());
                    var step = 1;

                    //double output = 0;
                    for (var i = 1; i <= rows; i++)
                    {
                        for (var j = 1; j <= rows; j++)
                        {
                            Console.Write("{0,3} ", step);
                            step++;
                        }
                        Console.WriteLine();
                    }

                }
                else
                    break;
                Console.WriteLine();
            }
            Console.ReadKey();
        }
    }
}
