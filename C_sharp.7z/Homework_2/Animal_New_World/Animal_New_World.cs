﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//виртуальные функции - это функции, которые активно используются при наследовании. Мы уже давно с тобой используем одну из них
//и ты даже не догадывался об этом. Как ты думаешь, какую ;)? ToString
//она уже заголовком отличается от всех функций, которые мы создавали до этого - там присутствует слово override
//это признак того, что в базомо классе объявлен метод/функция с таким именем, но мы хотим для этого класса создать другой метод, который
//имеет такое же имя, такой же набор и тип параметров, но делает другую работу
//виртуальный метод, может обращать к работе базового класса, как мы уже много раз делали, вызывай base.ToString()
//а потом дополняя эту работу еще какой-то, специфичной для этого класса
//но это не обязательное действие, перегружая виртуальный метод можно спокойно игнорировать работу метода базового класса, если в этом есть нужда
//компилятор в этом плане не делает ни каких ограничений

//предположим, что у нас каждое животное издает какой-то звук, более того, у птецов он один, а у взрослых особей он другой
//давай для начала скажем, что звук не зависит от возраста

namespace Animal_New_World
{
    class Animal_New_World
    {
        static void Main(string[] args)
        {
            //делаем систему классов для иммитации животного мира
            //каждое животное содержит: название, возраст, вес, тип размножения
            //(создай энемку: яйцами, живородящие, опылением, споры, делением и тп), умеют ли плавать, умеют ли летать, хищник ли

            //хочу отдельный класс для птиц, рыб и млекопитающих
            //птицы пусть дополнительно содержат: размах крыльев, максимальную высоту полета,
            //признак "перелетные или постоянно живущие", для перелетных -на какое максимальное расстояние летают
            //рыбы пусть содержат: максимальную глубину, на которой встречаются, в каком месяце нерестятся(из энумки 12 месяцев),
            //список особых умений если есть(например мурена ядовита, скаты с электричеством,
            //осьминоги используют чернила для маскировки + имеют присоски...)
            //млекопитающие пусть содержат: сколько минимально/ максимально рождают за раз детей, впадают ли в спячку, стадное ли животное

            // ToString особо не заполняй данными, достаточно выводить что-то типа "рыба Кит 1500кг" или "птица Ворон 50 лет"
            //Создай по парочке объектов каждого типа, добавь в конструкторы вывод данных о животном, которое создается

            //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!
            //маленькое замечание
            //класс - это всегда шаблон для одного объекта, копий которого может быть конечно сколько угодно
            //потому имена классам обычно дают в единственном числе
            //!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!

            var bird_1 = new Birds("Hawk", 2, 5, false, true, 20, 1, 3);
            var bird_2 = new Birds("Duck", 1, 5, false, true, 20, 1, 3, 3000);

            //здесь мы не создавали массив способностей, так как считаем, что их нет. Тогда используем ключевое слово null, которое
            //обозначет отстутствие объекта, в данном случае массива свойств. Но это слово будет нам еще часто встречаться
            //например, если автомобиль предусматривает установку ABS, но ее в конкретно этом экземпляре нет, то там полю _abs будет присвоено null
            var fishSalmon = new Fishes("Salmon", 1, 2, false, 20, 1, Months.April, null);
            //массив абилок можно создать как прямо в конструкторе, так и до него, присвоив переменной
            //var sharkAbilities = new Abilities[] { Abilities.HasSharpTeeth, Abilities.SwordNose };
            //var fish_2 = new Fishes("Shark", 2, 500, true, 2, Months.February, sharkAbilities);
            var fishShark = new Fishes("Shark", 2, 500, true, 20, 2, Months.February, new Abilities[] { Abilities.HasSharpTeeth, Abilities.SwordNose });

            var cow = new Mammals("Cow", 3, 500, false, false, 20, 2, false, true);
            var monkey = new Mammals("Monkey", 3, 50, false, false, 20, 2, false, false);

            Console.WriteLine(" Info about a bird:");
            Console.WriteLine(bird_1);
            Console.WriteLine("\n Info about a bird:");
            Console.WriteLine(bird_2);

            Console.WriteLine("\n Info about a fish:");
            Console.WriteLine(fishSalmon);
            Console.WriteLine("\n Info about a fish:");
            Console.WriteLine(fishShark);

            Console.WriteLine("\n Info about a cow:");
            Console.WriteLine(cow);
            Console.WriteLine("\n Info about a monkey:");
            Console.WriteLine(monkey);

            //пусть наши животные пошумят ;)
            Console.WriteLine();
            //конечно же можно найти звуковые файлы, для каждого животного и их проиграть, но для понимания темы это не принципиально
            monkey.Voice();
            fishSalmon.Voice();
            bird_2.Voice();

            monkey.Eat(20);
            fishSalmon.Eat(50);
            bird_2.Eat(50);

            //птица и так сидела - просим сесть еще и смотрим на реакцию
            bird_2.Fly(false);
            //взлетаем
            bird_2.Fly(true);
            //еще раз пробуем взлететь, хоть и уже летели
            bird_2.Fly(true);
            //садимся
            bird_2.Fly(false);
            //сидим. Этот тест мы уже прошли выше, так как знали, что она сразу сидит и вызвали самый первый bird_2.Fly(false);
            bird_2.Fly(false);

            var ostrichAfrican = new Ostrich("African ostrich", 1, 5, 20, 3);

            ostrichAfrican.Fly(false);

            ostrichAfrican.Voice();

            var ostrichNandu = new Ostrich("Nandu ostrich", 6, 5, 20, 2);
            var ostrichEmu = new Ostrich("Emu ostrich", 20, 5, 20, 1);
            var ostrichAmerican = new Ostrich("American ostrich", 3, 5, 20, 3);
            var ostrichCassowary = new Ostrich("Cassowary ostrich", 40, 5, 20, 4);


            var fishCod = new Fishes("Cod", 6, 2, false, 20, 2, Months.April, null);
            var fishPike = new Fishes("Pike", 6, 2, true, 20, 1, Months.April, null);

            //особенность абстракных классов в том, что нельзя создавать экземпляры этих классов!
            //это и понятно, так как они не имеют понятия, как выполнить работу в абстрактных методах
            //но это не проблема, наследуемся от такого класса, перегружаем все абстрактные методы и уже от таких наследников можно создавать объекты
            //именно это мы и сделали с классами Fishes, Birds ну и тд.
            //на следующем уроке мы поговорим больше о абстрактных классах и том, как их можно использовать еще ;)
            //var someAnimal = new Animals("some name", 10, 100, TypeOfReproduction.dividing, true, false, false);



            //-создай коллекцию страусов
            //найди, используя LINQ:
            //-у какого страуса самый большой вес
            //- есть ли хоть один страус старше 5 лет
            //- все ли страусы имеют размах крыльев больше 2м

            var ostrichs = new List<Ostrich>() { ostrichAfrican, ostrichNandu, ostrichEmu, ostrichAmerican, ostrichCassowary };

            var fishes = new List<Fishes>() { fishSalmon, fishShark, fishCod, fishPike };


            //-у какого страуса самый большой вес
            var biggestWeight = ostrichs.Max(w => w.Weight);
            var ostrichWithBiggestWeight = ostrichs.FirstOrDefault(w => w.Weight == biggestWeight);
            Console.WriteLine("\nAnimal_New_World.Tests(): Ostrich ({0}) with biggest weight {1}",
                ostrichWithBiggestWeight.Name, ostrichWithBiggestWeight.Weight);

            //-у каких страусов самый большой вес
            //здесь оставим ToList, чтобы показать, что можно и так, но если можно обойтись без приведение - это лучшее решение
            //ибо не будет лишнего копирования данных и потом чистки мусора
            var ostrichsWithBiggestWeight = ostrichs.Where(w => w.Weight == biggestWeight).ToList();
            Console.WriteLine("\nAnimal_New_World.Tests(): Ostrichs with biggest weight:");
            foreach (var o in ostrichsWithBiggestWeight)
                Console.Write("{0}, ", o.Name);

            Console.WriteLine("\n");

            //- есть ли хоть один страус старше 5 лет
            var ostrichsOlderThanFiveYears = ostrichs.Any(a => a.Age > 5);
            if (!ostrichsOlderThanFiveYears)
                Console.WriteLine("Animal_New_World.Tests(): There are no ostrichs with age over 5 years");
            else
                Console.WriteLine("Animal_New_World.Tests(): There is at least one ostrich with age over 5 years");

            //- все ли страусы имеют размах крыльев больше 2м
            var ostrichsWingspanOverTwoMeters = ostrichs.All(w => w.Wingspan > 2);
            if (!ostrichsWingspanOverTwoMeters)
                Console.WriteLine("\nAnimal_New_World.Tests(): Not all of ostrichs are with wingspan over 2m");
            else
                Console.WriteLine("\nAnimal_New_World.Tests(): all ostrichs are with wingspan over 2m");

            //создай коллекцию рыб
            //выполни те же самые действия для нее, что и для страусов

            //-у какой рыбы самый большой вес
            biggestWeight = fishes.Max(w => w.Weight);
            var fishWithBiggestWeight = fishes.FirstOrDefault( w => w.Weight == biggestWeight);
            Console.WriteLine("\nAnimal_New_World.Tests(): Fish ({0}) with biggest weight of {1} kg",
                fishWithBiggestWeight.Name, fishWithBiggestWeight.Weight);

            //-у каких рыб самый большой вес
            //когда метод Where возвращает коллекцию отфильтрованных объектов не обязательно приводить его к списку или массиву
            //var fishesWithBiggestWeight = fishes.Where(w => w.Weight == biggestWeight).ToList();
            //если ты на каждым элементом списка проводишь какую-то разовую операцию в цикле foreach, например, выводишь его на экран,
            //то можно (и даже желательно) использовать такую упрощенную запись. С точки зрения кода, больше ничего не меняется
            //а вот создание списка или массива приводит к выделению еще одного блока памяти, которая уже выделена под текущую коллекцию
            //это и время и перерасход памяти. Потому для себя придерживайся правила, "сначала не пишем никакого приведения, но если без этого никак"
            //(например нужно еще узнать количество элементов или обязательно использовать цикл for) - то тогда уже:
            //ToArray - он занимает меньше памяти, если тебе не нужно изменять размер этой коллекции
            //ToList - если нужно изменять размер, например, в последствии, удалять элементы или добавлять новые
            var fishesWithBiggestWeight = fishes.Where(w => w.Weight == biggestWeight);
            foreach (var w in fishesWithBiggestWeight)
                Console.Write("{0}, ", w.Name);

            //- есть ли хоть одна старше 5 лет
            var fishesOlderThanFiveYears = fishes.Any(a => a.Age > 5);
            if(!fishesOlderThanFiveYears)
                Console.WriteLine("Animal_New_World.Tests(): There are no fishes with age over 5 years");
            else
                Console.WriteLine("Animal_New_World.Tests(): There is at least one fish with age over 5 years");

            //но вместо размаха крыльев проверь все ли рыбы коллекции могут плавать глубже километра
            var fishesWithMaxDepthOverOneKm = fishes.All(a => a.MaxDepth > 1);
            if (!fishesWithMaxDepthOverOneKm)
                Console.WriteLine("\nAnimal_New_World.Tests(): Not all of fishes are with max depth over 1km");
            else
                Console.WriteLine("\nAnimal_New_World.Tests(): all fishes are with max depth over 1km");

            //метод Test мы пометили как static, потому мы можем обращаться к нему по упрощенной форме: ИмяКласса.ИмяМетода
            TypeCastingTest.Test();
            //метод NonStaticTest не помечен как статический, потому для обращения к нему сначала нужно создать объект класса TypeCastingTest
            //именно это мы производили во всеми классами до этого
            //TypeCastingTest.NonStaticTest();
            var testObject = new TypeCastingTest();
            //после того, как объект типа TypeCastingTest создан, через него можно обращаться к нестатическим методам
            //оставлю здесь этот вызов для чистоты эксперимента
            testObject.NonStaticTest();
            //как видим, такой подход подразумевает написания большего количества кода, без каких либо преимуществ
            //когда объект предполагается в нескольких копиях - тогда методы делают нестатичными
            //для тестовых методов, которые будут вызываться только раз, статичность позволяет быстрее написать код, который будет делать тоже самое
            //чаще всего мы будем использовать классы и нестатичные методы, но иногда, для каких либо тестов, мы будем создавать и статичные
            //обрати внимание, что через объект можно вызывать только нестатичные методы, 
            //testObject.Test();
            //в то время, как через имя класса только статичные
            //TypeCastingTest.NonStaticTest();

            Console.ReadKey();
        }
    }
}
