﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_class
{
    public enum CPUCompany { Intel, AMD };
    public enum CPUSocketType { Socket_H3, Socket_R3, LGA_1151, Socket_R4, LGA_1151_v2 };

    public class CPU
    {
        //для того, чтобы проконтролировать что процессор допустимый нам нужно построить словарь соотвествий
        //процессоров слотам. Создадим словарь, где ключами будет тип процессора, а значеним - список слотов
        private Dictionary<CPUCompany, List<CPUSocketType>> _cpuSocketRelations = new Dictionary<CPUCompany, List<CPUSocketType>>()
        //это не метод, это инициализатор словаря стартовыми значениями, посмотри позднее - мы так уже делали 
        {
            //каждая пара ключ-значение добавляется в отдельных фигурных скобках
            //значением есть список - следовательно прямо здесь его и создадим
            //так как список не пустой, то сразу же после его создание укажем его элементы, тоже в скобках
            { CPUCompany.AMD, new List<CPUSocketType>() { CPUSocketType.Socket_H3, CPUSocketType.Socket_R3, CPUSocketType.Socket_R4 } },
            { CPUCompany.Intel, new List<CPUSocketType>() { CPUSocketType.LGA_1151, CPUSocketType.LGA_1151_v2 } },
        };

        //класс Процессор:
        //производитель(перечисление ;)), модель, сколько ядер
        //нужно поле типа CPUCompany. Ты просто создал перечисление, 
        //но для того, чтобы эти данные появились в классе нужно создать поле
        private CPUCompany _cpuCompany;
        private CPUSocketType _CPUSocket;
        private string _model;
        private int _amountOfCores;
        private bool _isValid;

        public CPU(CPUCompany cpuCompany, string model, CPUSocketType cpuSocket, int amountOfCores)
        {
            _cpuCompany = cpuCompany;
            _model = model;
            //очень нежелательно создавать параметрам метода имена, который начинаются с большой буквы
            //в C# договорились, что с большой буквы начинают только: имена классов, имена перечисление, 
            //имена Методов и имена свойств(пропертей|гэттэров)
            //свойствами(property) называют и гэттэры и сэттэры
            _CPUSocket = cpuSocket;
            _amountOfCores = amountOfCores;

            //для того, чтобы понять, что процессор валидный, мы должны проверить, что указанный сокет
            //входит в список сокетов, которые определены для этого производителя процессоров
            //вот так по ключу ТипПроцессора мы получили список поддерживаемых сокетов
            var validSockets = _cpuSocketRelations[cpuCompany];
            //метод Contains вернет true, если в списке есть сокет, который мы передали в конструктор
            //иначе вернет false. Для нашей задачи такой простой проверки будет достаточно
            _isValid = validSockets.Contains(cpuSocket);
            //if (_isValid == false)
            //тоже самое, что и выше
            if (!_isValid)
                Console.WriteLine("CPU.Constructor: Invalid processor specification. Socket {0} is not supported by {1}",
                    cpuSocket, cpuCompany);
            //но эта штука не запретит создать объект
            //если мы сделаем гэттэр для поля _isValid, мы дадим возможность спрашивать у процессора
            //валидный ли он. Добавь такое проперти (гэттеры еще называют пропертями)
        }

        //я предлагаю сделать все же IsValid, потому как в будущем могут добавиться и другие проверки
        //действительно и я об этом писал, когда первый раз рассказывал, обычно имя гэттэра - это
        //имя поля, но без подчерка и с большой буквы
        public bool IsValid
        {
            get { return _isValid; }
        }

        public CPUSocketType CPUType
        {
            get { return _CPUSocket; }
        }

        //обычно когда что-то откладываешь на потому, то пишут todo и это поддерживается
        //на уровне IDE
        //todo: finish method
        public override string ToString()
        {
            return string.Format("CPU {0} {1}, Socket {2} and {3} cores", _cpuCompany, _model, _CPUSocket,
                _amountOfCores);
        }
    }
}
