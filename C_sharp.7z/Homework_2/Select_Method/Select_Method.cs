﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Select_Method
{
    class Select_Method
    {
        static void Main(string[] args)
        {
            string[] teams = { "Бавария", "Боруссия", "Реал Мадрид", "Манчестер Сити", "ПСЖ", "Барселона" };

            //у Linq есть два варианта записи одного и того же
            //первая - то, что мы с тобой рассматривали раньше
            //мне она нравится больше, так как она максимально похожа на то, что ты будешь видеть
            //в других языках
            //вторую они придумали в виде похожем на SQL запрос. Типа язык в языке. С одной
            //стороны такие запросы более лаконичны, но они требуют особый порядок команд
            //нужно привыкать к чему-то новому, что в других языках не используется
            //и потому я даже не хочу особо использовать этот метод
            //ну да рассмотрим, что он делает

            //если нам нужен сам объект, то Select не нужен, но покажу когда без него никуда
            //var classicCall = teams.Where(t => t.ToUpper().StartsWith("Б")).OrderBy(t => t);
            //допустим нам нужны только первые две буквы от слова, а не все. Строка выше вернет
            //только целое слово и Select позволяет провести дополнительную обработку над 
            //результатом
            //еще раз и процедурный способ и SQL способ - это LINQ. Оба способа!
            //SQL предусматривает в конце select obj, даже если не нужно проводить
            //дополнительной обработки объекта. 
            //Процедурный способ позволяет при ненужности что-то дополнительное делать с 
            //результатом Select не писать, но можно и написать
            //вот эта строка кода делает тоже самое, что и строка выше.
            //но это не тот же Select, что в SQL методе. Там это команда которая говорит, какой
            //объект вернуть
            //var classicCall = teams.Where(t => t.ToUpper().StartsWith("Б")).OrderBy(t => t).
            //    Select(t => t);
            //здесь же Select это как бы возможность выполнить дополнительную обработку результата
            //так код ниже вернет не все название, а только первые 2 буквы
            //var classicCall = teams.Where(t => t.ToUpper().StartsWith("Б")).OrderBy(t => t).
            //    Select(t => t.Substring(0, 2));
            //а этот код преобразует название в верхний регистр
            //var classicCall = teams.Where(t => t.ToUpper().StartsWith("Б")).OrderBy(t => t).
            //    Select(t => t.ToUpper());
            //а этот метод заменит все буквы а на _
            var classicCall = teams.Where(t => t.ToUpper().StartsWith("Б")).OrderBy(t => t).
                Select(t => t.Replace('а', '_'));
            //мы рассматривали вариант, когда Select позволял из целого объекта создать
            //объект другого типа, в котором будет только пару полей
            //Для этого метода можно придумать множество применений, главное понять зачем он
            //метод Select - это метод, который позволяет провести дополнительну работу!
            //в SQL способе это чаще всего просто часть синтаксиса, без которой даже не получить
            //необработанное значение
            Console.WriteLine("classicCall:");
            foreach (string s in classicCall)
                Console.WriteLine(s);

            Console.WriteLine("SQL style:");
            var selectedTeams = from t in teams // определяем каждый объект из teams как t
                                where t.ToUpper().StartsWith("Б") //фильтрация по критерию
                                orderby t // упорядочиваем по возрастанию
            //SQL стайл предусматривае всегда вначале писать from VariableName in CollectionVar
            //вначале запрос и обязательно в конце писать select VariableName
            //Другими словами это не тот select, который мы рассматривали как метод
            //именно из-за таких прикольчиков мне и нравится процедурный способ больше - меньше
            //отличий от остального кода
                                select t; // выбираем объект

            foreach (string s in selectedTeams)
                Console.WriteLine(s);

            //еще маленький пример
            //например у нас есть массив чисел
            //создай массив из 5 любых чисел, где есть и позитивные и негативные
            int[] oddPos = { -1, 2, -3, 4, -5 };
            //допустим нам нужны только числа, которые по модулю не больше 3
            //какой метод подходит? но я спрашиваю о методе LINQ, какой подходит?
            var numbers = oddPos.Where( n => Math.Abs(n) <= 3);

            Console.WriteLine("\nчисла, которые по модулю не больше 3:");
            foreach (var n in numbers)
                Console.Write("{0}, ", n);

            var invertedNumbers = oddPos.Where(n => Math.Abs(n) <= 3).Select( n => n*(-1));

            Console.WriteLine("\nТе же числа, которые по модулю не больше 3, но инвертированные:");
            foreach (var n in invertedNumbers)
                Console.Write("{0}, ", n);

            var invertedArray = oddPos.Select(n => n * (-1));

            Console.WriteLine("\n Взяли изначальный массив и инвертировали числа:");
            foreach (var n in invertedArray)
                Console.Write("{0}, ", n);

            //напиши код, который все числа их первого списка преобразует в новый список,
            //где каждое число - квадрат числа их первого списка


            var arrayWithSquaredNumbers = oddPos.Select(n => Math.Pow(n, 2));
            //лучше было
            //var arrayWithSquaredNumbers = oddPos.Select(n => n*n);
            //т.к. Pow всегда возвращает вещественное число,
            //а n*n вернет того типа, которого был n и будет работать быстрее

            Console.WriteLine("\n Взяли изначальный массив и применили квадрат ко всем числам:");
            foreach (var n in arrayWithSquaredNumbers)
                Console.Write("{0}, ", n);

            Console.ReadKey();
        }
    }
}
