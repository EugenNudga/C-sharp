﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_14
{
    class Task_14
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры два целых числа.
            //Программа должна произвести только одну из следующих операций:
            //-Если первое число больше второго и второе число больше нуля, вывести alpha
            //-Если первое число меньше нуля и второе число равно нулю, вывести bravo
            //-Если любое из чисел равно нулю, вывести charlie
            //-Если не сработало ничего из вышеуказанного, вывести zulu
            //Пример ввода
            //100 50
            //Пример вывода
            //alpha
            Console.Write("Enter first integer number: ");
            var num0 = Convert.ToInt16(Console.ReadLine());
            Console.Write("Enter second integer number: ");
            var num1 = Convert.ToInt16(Console.ReadLine());

            if ( (num0 == 0) | (num1 == 0))
            {
                Console.WriteLine("charlie");
            }
            else if ((num1 == 0) & (num0 < 0))
            {
                Console.WriteLine("bravo");
            }
            else if ((num0 > num1) & (num1 > 0))
            {
                Console.WriteLine("alpha");
            }
            else
            {
                Console.WriteLine("zulu");
            }

            Console.ReadKey();

        }
    }
}
