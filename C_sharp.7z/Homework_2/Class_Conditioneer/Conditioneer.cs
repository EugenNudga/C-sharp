﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Conditioneer
{
    public class Conditioneer
    {
        //класс Кондиционер
        //-поля: название, текущее количество фреона(л), средний расход(л / ч), максимальный объем(л)
        //- в конструктор передаем 4 параметра, чтобы присвоить их полям
        //- перегружаем ToString, чтобы можно было увидеть основную информацию о кондее
        //- создаем методы Work(float time) - для иммитации работы кондиционера,
        //которая тратит фреон и метод FillUp, для заправки.
        //Класс будет похож на автомобильный с урока

        private string _name;
        private float _freonAmount;
        private float _averageConsumption;
        private float _maxVolume;

        public Conditioneer(string name, float freonAmount, float averageConsumption, float maxVolume)
        {
            _name = name;
            _freonAmount = freonAmount;
            _averageConsumption = averageConsumption;
            _maxVolume = maxVolume;
        }

        //само начилие этого метода не говорит, что-то выводить на экран
        //нужнро 
        public override string ToString()
        {
            return string.Format("Conditioneer name: {0},\namount of freon: {1},\naverage consumption: {2},\nmax volume: {3}", _name, _freonAmount, _averageConsumption, _maxVolume);
        }


        public void Work(float time)
        {
            //- создаем методы Work(float time) - для иммитации работы кондиционера,
            //которая тратит фреон и метод FillUp, для заправки.
            //рекомендую присвоить переменной то к - во, которое нужно для работы на протяжении time
            var amountNeeded = time * _averageConsumption;
            //сравнение происходит между _freonAmount < amountNeeded
            var spentAmount = _freonAmount < amountNeeded ? _freonAmount : amountNeeded;

            _freonAmount -= spentAmount;
            //если что-то осталось, значит фреона хватило на все запрошенное время, а вот если 0
            //то значит работали меньше, нужно вычислить сколько. Для этого просто разделим 
            //все, что было потрачено на скорость расхода
            var workTime = spentAmount / _averageConsumption;
            Console.WriteLine("\nThe conditioneer worked {0} hours and spent {1} liters.\n The amount of freon left: {2}",
                workTime, spentAmount, _freonAmount);


        }

        //Пример вывода: Кондиционер поработал N часов и потратил X литров. Осталось Y литров
        //предлагаю при логировании указывать, что происходил такой-то процесс и столько то
        //фреона было потрачено/пополнено по факту, а не сколько было запрошено или сколько просто стало
        public void FillUp(float liters)
        {
            float initialFreonAmount = _freonAmount;
            _freonAmount += liters;
            if(_freonAmount >= _maxVolume)
                _freonAmount = _maxVolume;
            Console.WriteLine("\nThe conditioneer had {0} liters and was filled up for {1}.\n The amount of freon after fill-up: {2}", initialFreonAmount, liters, _freonAmount);

        }

    }
}

