﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_22
{
    class Task_22
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры целое положительное число.
            //Вывести в строку все числа, кратные 5, от нуля до указанного числа включительно.
            //Пример ввода      //17
            //Пример вывода     //0 5 10 15

            Console.Write("Enter a positive integer number: ");
            var num = Convert.ToByte(Console.ReadLine());

            for (var i = 0; i <= num; i+=5)
            {
                Console.WriteLine("{0} ", i);
            }
            Console.ReadKey();
        }
    }
}
