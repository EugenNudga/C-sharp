﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_20
{
    class Task_20
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры целое положительное число.
            //Вывести в строку все нечётные числа от нуля до указанного числа включительно.
            //Пример ввода      //9
            //Пример вывода     //1 3 5 7 9

            //здесь код выполняет то, что ты написал, а не то, о чем думал ;)
            //ты написал дословно, подождать что я нажму и если это 1, то написать введите число 
            //иначе еще подождать нажатия какой-то клавишы

            //по хорошему твой код должен сначала попросить ввести число
            //если это 0 - закончить программу, а иначе выполнить действие и снова запросить число

            while (true)
            {
                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter a positive integer number: ");
                    var num1 = Convert.ToByte(Console.ReadLine());

                    for (var i = 1; i <= num1; i+=2)
                    {
                        //здесь точно так же как в прошлом примере можно упростить код
                        //убрать проверку,а изменить шаг цикла
                        //if ((i % 2) == 1)
                            Console.Write("{0} ", i);
                    }
                    Console.WriteLine();
                    //эта строка лишняя, так как ты сделал цикл и выше снова вызывается Console.ReadKey().Key
                    //Console.ReadKey();
                }
                else
                    break;
            }
            //эта команда лишняя, так как ты выше написал код, дождись нажатия клавиши и если это 1, то...
            //иначе говоришь еще раз дождаться нажатия любой клавиши
            //else
            //    Console.ReadKey();
        }
    }
}
