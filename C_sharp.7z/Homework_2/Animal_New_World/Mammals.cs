﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal_New_World
{
    public class Mammals : Animals
    {
        //млекопитающие пусть содержат: сколько минимально/ максимально рождают за раз детей, впадают ли в спячку, стадное ли животное
        private int _maxAmountOfKids;
        private bool _doHibernation;
        private bool _isHerd;

        public Mammals (string name, int age, int weight, bool canSwim, bool isPredator, int levelOfFullness,
            int maxAmountOfKids, bool doHibernation, bool isHerd) 
            : base(name, age, weight, TypeOfReproduction.viviparous, canSwim, false, isPredator, levelOfFullness)
        {
            _maxAmountOfKids = maxAmountOfKids;
            _doHibernation = doHibernation;
            _isHerd = isHerd;
        }

        public override void Voice()
        {
            //эта строка просто отличается от того, что в других классах, что конкретно выводится не важно
            Console.WriteLine("{0} voice", _name);
        }

        public override void Eat(int amount)
        {
            base.Eat(amount);
            Console.WriteLine("{0} makes a \"whatever\" sound", _name);
        }

        public override string ToString()
        {
            var animalInfo = base.ToString();
            return string.Format("{0}\nMax amount of kids: {1}", animalInfo,_maxAmountOfKids);
        }
    }
}
