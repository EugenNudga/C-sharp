﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_32
{
    class Task_32
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры целое положительное число - количество чисел в последовательности.
            //Затем считать с клавиатуры заданное количество чисел и вывести наибольшее из них.
            //пример ввода

            //5
            //1 2 3 4 5

            //пример вывода //5

            Console.Write("Enter a positive integer number (amount of numbers for output): ");  //
            var num0 = Convert.ToByte(Console.ReadLine());

            Console.WriteLine("Enter {0} integer numbers: ", num0);
            //у тебя были не числа, а текстовые строки, но потом была бы проблема сравнивать их как числа
            //оно может сравнивать, но сравнивает коды и это не тоже самое
            //например, если ввести 0000, то оно будет считать, что это строка из 4х символов
            //и эта строка будет больше 1, 100 и даже 999, так как строки сравниваются сначала по длинне
            //а потом уже по коду
            //именно по-этому проще считывать числа как числа
            var numbers = new int[num0];
            var numNames = new string[] { "st", "nd", "rd" };
            for (int i = 0; i < numbers.Length; i++)
            {
                if (i < numNames.Length)
                    Console.Write("Enter {0}{2} from {1} integer numbers: ", i + 1, num0, numNames[i]);
                else
                    Console.Write("Enter {0}th from {1} integer numbers: ", i + 1, num0);
                numbers[i] = Convert.ToInt32(Console.ReadLine());
            }

            for (int i = 0; i < numbers.Length; i++)
            {
                Console.Write("{0} ", numbers[i]);
            }

            //этот способ можно конечно использовать, но есть чуть более оптимальный
            //var max = Int32.MinValue;
            //константа Int32.MinValue зависит от типа значений внутри numbers
            //если там будут значения типа byte, то пришлось бы написать Byte.MinValue
            //для типа short - Int16.MinValue - не очень удобно, потому надежнее писать так ;)
            //мы считаем, что максимальное значение - это самое первое
            //а потом уже сравниваем его со веми остальными
            var max = numbers[0];
            //обрати внимание на то, что int i = 1
            //можно написать и 0, но зачем сравнивать 0й элемент с самим собой, ясно же, что он не больше самого себя :)
            for (int i = 1; i < numbers.Length; i++)
            {
                if (numbers[i] > max)
                    max = numbers[i];                    
            }
            Console.Write("\n{0} ", max);

            Console.ReadKey();

        }
    }
}
