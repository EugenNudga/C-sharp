﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_9
{
    class Task_9
    {
        static void Main(string[] args)
        {
            Console.Write("Enter first integer number: ");
            var num0 = Convert.ToByte(Console.ReadLine());
            Console.Write("Enter second integer number (it must not be zero): ");
            var num1 = Convert.ToByte(Console.ReadLine());
            while( num1 == 0)
            {
                Console.Write("The entered second number is zero, so try again: ");
                num1 = Convert.ToByte(Console.ReadLine());
            }

            Console.WriteLine("{0}",
                ((num0%num1) == 0) ? "The first number is a multiple of second =)" : "The first number is a NOT multiple of second =(");

            Console.WriteLine("The first number is a {0}multiple of second =)", (num0 % num1) == 0 ? "" : "NOT ");

            Console.ReadKey();
        }
    }
}
