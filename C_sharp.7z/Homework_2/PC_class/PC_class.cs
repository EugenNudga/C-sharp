﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//когда появляется сообщение об ошибке, то вместе с ним прилагается так называемый колстэк
//это порядок вызова методов, которые привели к ошибке
//на верху этого стэка находится именно та команда, которая привел к ошибке, а в самом низу -
//самая первая команда, которая в последствии привела к вызову ошибочного метода
//то есть получается, что колстэк это обратный порядок вызова методов, который привел к ошибке
//верхней мы видим не первую команду - а последную

//такой ошибки не было, когда мы использовали списки и появилась только с массивами
//причина в том, что список имеет изменяемый размер, там появлялись модули только после добавления
//массивы же требуют сразу выделить память под все слоты, хоть там в начале и будут пустые объекты
//именно по-этому пришлось изменить код, добавив проверку, что в слоте есть объект, а не пустышка

namespace PC_class
{
    class PC_class
    {
        static void Tests()
        {
            //здесь мы поучимся работать с массивами объектов
            //например, у нас есть такой массив или список модулей памяти
            var modules = new Memory[]
            {
                new Memory(MemoryCompany.Kingmax, TypeOfMemory.DDR3, MemorySize._4Gb, 1800),
                new Memory(MemoryCompany.Corsair, TypeOfMemory.DDR4, MemorySize._4Gb, 2666),
                new Memory(MemoryCompany.Corsair, TypeOfMemory.DDR4, MemorySize._2Gb, 2666),
                new Memory(MemoryCompany.OCZ, TypeOfMemory.DDR4, MemorySize._2Gb, 2666),
                new Memory(MemoryCompany.Corsair, TypeOfMemory.DDR4, MemorySize._32Gb, 2666),
                //обрати внимание, что в конце можно оставить , даже если ничего дальше нет
                //это бывает удобно, так как если нам потом придется добавить еще элементы, не
                new Memory(MemoryCompany.Kingston, TypeOfMemory.DDR4, MemorySize._16Gb, 2666),
                //придется ставить запятую. Ну и не забываем ставить ; после того, как указали
                //весь список
            };
            //у нас есть целый ряд методов, которые позволят произвести некие статистические вычисления
            //например, сколько модулей памяти типа DDR3 или SD_RAM
            var sdRamCount = modules.Count(m => m.MemoryType == TypeOfMemory.SD_RAM);
            //либо модулей, с частотой выше 1600Мгц
            var fastModules = modules.Count(m => m.Frequency > 1600);
            //так же просто считать суммы
            //например, нам нужно подсчитать суммарный объем памяти у модулей DDR4
            //можешь  сам написать код?
            //теперь, нужно написать правильно условие
            //условие m.MemoryType == TypeOfMemory.DDR4 для того, чтобы различать модули, которые нам 
            //подходят от остальных. Вот для этих модулей нужно прибавлять из объем, а для остальных 0
            //единственное, что здесь пришлось добавить - приведение ModuleSize к числу, так как это было
            //перечисление, а суммировать можно только числа
            var ddr4TotalVolume = modules.Sum(m => m.MemoryType == TypeOfMemory.DDR4 ?
                    (int)m.ModuleSize : 0);
            //если бы мы хотели посчитать сумму всех модулей, не важно какого типа, было бы еще проще
            var allTotalVolume = modules.Sum(m => (int)m.ModuleSize);

            //хорошо, а как найти первый модуль фирмы OCZ?
            var oczMemory = modules.FirstOrDefault(m => m.MemoryCompany == MemoryCompany.OCZ);
            //у нас не было модулей этой фирмы и transcendMemory будет равен null
            //WriteLine в таком случае не выводит ничего в том месте, где пустой объект
            //если мы хотим показать явно, что там пустой объект придется дописывать условие
            var transcendMemory = modules.FirstOrDefault(m => m.MemoryCompany == MemoryCompany.Transcend);

            //добавь теперь код, который выведет на экран все наши переменные, который мы получили выше
            Console.WriteLine("\nPC_class.Tests(): {0} sdRam modules, {1} fast mem modules, {2}Gb in ddr4 modules, {3}Gb in all mem modules,\nocz modules: {4},\ntranscend modules: {5}",
                sdRamCount, fastModules, ddr4TotalVolume, allTotalVolume, MemoryToString(oczMemory),
                MemoryToString(transcendMemory));

            if (transcendMemory == null)
                Console.WriteLine("\nPC_class.Tests(): No one Transcend module was found");
            else
                Console.WriteLine("\nPC_class.Tests(): {0} of Transcend", transcendMemory);

            //существует еще целый ряд методов, которые мы рассматривали для коллекций примитивных типов
            //данных, которые будут так же работать и для коллекций классов
            //я подумаю и подберу тебе д.з. на такие функции, которые мы сегодня не успели рассмотреть
            //но описание которых ты легко найдешь в интернете или в нашей прошлой теме
            //задание будет в течении часа

            //public void NvidiaOrATICards(VideocardCompany videocard_name)
            //{
            //    Console.WriteLine("Motherboard.NvidiaOrATICards() list:\n");
            //    for (var i = 0; i < _videocards2.Count; ++i)
            //    {
            //        if (_videocards2. == videocard_name)
            //            Console.WriteLine("{0} {1}\n", videocard_name, _model);
            //    }
            //}

            //часто, если нет обязательного условия, то для меня нет разницы между списком или массивом
            //обобщенно их называют коллекциями. Но коллекции это и стэки и очереди и словари и множества
            //потому я часто говорю список, но подразумеваю, что массив тоже подходит
            //- создать список из нескольких видеокарт
            //- посчитать количество видеокарт только под слот AGP
            //- подсчитать количество видеокарт под все разновидности PCI-E
            //- получить список только видеокарт NVidia и вывести их на экран
            //- сказать, есть ли среди общего списка видеокарт хоть одна ATI
            //- все ли видеокарты в списке имеют объем видеопамяти больше 1Gb
            //- вывести информацию о первой видеокарте, которая имеет разрядность
            //  шины больше 256бит(это задание с небольшим подвохом ;))

            var videocards = new Videocard[]
            {
                new Videocard(VideocardCompany.Nvidia, "Mars1", VideocardSocketType.AGP, BitCapacity._256bit, 4),
                new Videocard(VideocardCompany.Nvidia, "Razvod", VideocardSocketType.PCI_E_3, BitCapacity._384bit, 4),
                new Videocard(VideocardCompany.Radeon, "Old_Razvod", VideocardSocketType.PCI_E, BitCapacity._256bit, 1),
                new Videocard(VideocardCompany.Nvidia, "Colossus", VideocardSocketType.AGP, BitCapacity._128bit, 3),
                new Videocard(VideocardCompany.Radeon, "Zero", VideocardSocketType.PCI_E_2, BitCapacity._384bit, 1),
            };

            //- посчитать количество видеокарт только под слот AGP
            var agpCount = videocards.Count(v => v.VideocardSocket == VideocardSocketType.AGP);

            //- подсчитать количество видеокарт под все разновидности PCI-E
            var pci_e_all_Count = videocards.Count(v => (v.VideocardSocket == VideocardSocketType.PCI_E)
            || (v.VideocardSocket == VideocardSocketType.PCI_E_2)
            || (v.VideocardSocket == VideocardSocketType.PCI_E_3));

            //FirstOrDefault - это найти первый объект, который соответствует условию
            //я хотел, чтобы ты поискал метод, который вернет все объекты, которые соотвествтуют условию. Мы его
            //раньше рассматривали
            //я расчитывал, что ты найдешь метод Where
            //- получить список только видеокарт NVidia и вывести их на экран
            //если вызвать Where он вернет не список объектов, а так называемый энумератор. Это обобщенная конструкция
            //которая позволяет перебрать все объекты по порядку в цикле foreach и то только один раз!, 
            //но не позволит больше практически ничего
            //для ситуации, когда нужно просто один раз перебрать элементы, то одного Where достаточно
            //но если ты потом захочешь что-то делать большее, то удобнее результат Where преобразовать в список используя
            //ToList(). Есть еще ToArray() - который преобразует коллекцию в массив
            //если ты не собираешься изменять результат, то ToArray() предпочтительнее. Если ты потом из результата 
            //что-то захочешь дополнительно удалить или добавить или перебрать в цикле несколько раз
            var nvidiaVideocards = videocards.Where(v => v.VideocardCompany == VideocardCompany.Nvidia).ToList();
            if (nvidiaVideocards == null)
                Console.WriteLine("\nPC_class.Tests(): No Nvidia videocard was found");
            else
            {
                Console.WriteLine("\nAll NVidia cards:");
                //еще раз, если нам просто нужно вывести список объектов, то можно было не переводить его в List
                //как видишь, сам цикл от этого не изменился
                //но если бы ты захотел использовать цикл for, то уже бы не получилось
                //for (var i = 0; i < nvidiaVideocards.Count; ++i) { }
                foreach (var v in nvidiaVideocards)
                    Console.WriteLine("{0}, ", v);
            }

            //ты говоришь о возможности еще одного метода, который мы не рассматривали
            //Where всегда возвращает все объекты, как они былы, но при этом только те, 
            //которые соответствовали некоему условию
            //если же тебе нужно получить список только частичной информации об объекте, например список разрядностей
            //всех видеокарт, которые были в первоначальной коллекции или даже только nVidia карт, то есть метод Select
            //так мы получим разрядность всех карт, которые были в коллекции nvidiaVideocards
            //то есть только те, которые оказались nVidia картами в общем списке
            var nVidiaBitness = nvidiaVideocards.Select(c => c.BitCapacity);
            Console.WriteLine("\nBit capacity of all NVidia cards:");
            foreach (var v in nVidiaBitness)
                Console.WriteLine("{0}, ", v);
            //если бы мы захотели получить коллекцию разрядностей абсолютно всех карт, то мы бы написали так
            var allBitness = videocards.Select(c => c.BitCapacity);
            Console.WriteLine("\nBit capacity of all cards:");
            foreach (var v in allBitness)
                Console.WriteLine("{0}, ", v);

            //последнее, методы Linq для коллекций можно применять над результатами любого метода, который вернет
            //другую коллекцию. Так например метод Where вернул нам только видеокарты, у которых AGP шина
            //мы сразу же к этой коллекции можем применять метод Select или Count или любой другой, чтобы получить
            //другую информацию
            //ты хочешь получить больше одного значения получить - это просто так не сделать. Select позволяет получить
            //только одно поле, но можно конечно в нем создавать объект другого класса и тогда сохранить больше данных
            //это посмотрим в другой раз
            //если же тебе нужно получить результат, который соответствует более чем одному условию, то ничто не мешает 
            //добавить && в условии Where. Можно конечно написать и цепочку Where, но комбинированное условие эффективнее
            //так мы получим только карты, которые и AGP и 256бит

            //раз ты хочешь больше одного объекта - показываю ;)
            //как видишь, это реально, просто пришлось делать еще один класс
            //на самом деле со временем в шарпе появились анонимные классы, которые позволяют создавать объекты на лету
            //но это тебе будет домашним заданием почитать о таких классах
            //более того, ты даже в документации по одной из функций находил когда-то пример таких классов
            //но они обычно полезны только для какой-то черновой работы. Чаще всего надежнее создать реальный класс
            //чуть больше работы, но в классе можно создавать дополнительные методы и тп, типа ToString
            //и тогда объект выводится на экран просто написав переменную, а не указывая каждый раз явного поля
            var pcie3Brands = videocards.Where(c => c.VideocardSocket == VideocardSocketType.AGP && c.BitCapacity == BitCapacity._384bit)
                                        .Select(c => new CompositInfo(c.VideocardCompany, c.VideocardModel));
            //эта команда равнозначна по результату верхней, но требует больше памяти и медленнее ее
            //var pcie3Brands = videocards.Where(c => c.VideocardSocket == VideocardSocketType.AGP).Where(c.BitCapacity == BitCapacity._256bit)
            //                            .Select(c => c.VideocardCompany);
            //как видим можно делать запрос к результату предыдущего запроса, если им была коллекция
            Console.WriteLine("\nBrands of AGP and 256bit cards:");
            foreach (var v in pcie3Brands)
                Console.WriteLine("{0}, ", v);
            //если же нам нужно выбрать по условию || или любому другому, то единственный Where решит все как нужно
            //например, так мы получим видеокарты, которые либо минимум 256 бит, либо более 3Гб видеопамяти
            var goodEnoughCards = videocards.Where(c => (int)c.BitCapacity >= (int)BitCapacity._256bit || c.VideocardVolume >= 3);
            Console.WriteLine("\nGood enough cards:");
            foreach (var v in goodEnoughCards)
                Console.WriteLine("{0}, ", v);

            //- сказать, есть ли среди общего списка видеокарт хоть одна ATI
            //когда нужно ответить на вопрос True/False, то это расточительно использовать метод Where, который вернет
            //абсолютно все объекты, который соотвествуют условию
            //для ответа на вопрос "все ли" идеально подходит All. Он так же подходит для вопроса "ни одной"
            //если записать videocards.All(условие) == false или !videocards.All(условие)
            //а вот для ответа на вопрос "хоть один" удобнее Any
            var atLeastOneAatiVideo = videocards.Any(v => v.VideocardCompany == VideocardCompany.ATI);
            if (!atLeastOneAatiVideo)
                Console.WriteLine("\nPC_class.Tests(): No ATI videocard was found");
            else
                Console.WriteLine("\nPC_class.Tests(): found at least one ATI videocard");
            //в основе массива или списка или не важного еще какой коллекции лежит класс, следовательно - это объекты
            //объект - обобщающее понятие для всего, что представляет собой инстанс любого класса
            //коллекция - обобщающее понятие для объектов, которые содержат в себе несколько объектов другого типа

            //- все ли видеокарты в списке имеют объем видеопамяти больше 1Gb
            var over_1gb_Video = videocards.All(v => v.VideocardVolume > 1);
            if (!over_1gb_Video)
                Console.WriteLine("\nPC_class.Tests(): Not all videocard with over 1GB was found");
            else
                Console.WriteLine("\nPC_class.Tests(): all videocards are with over 1GB memory");

            //- вывести информацию о первой видеокарте, которая имеет разрядность
            //  шины больше 256бит(это задание с небольшим подвохом ;))
            //в том и подвох, чтобы представить разрядность как число, а не как перечисление
            //ну и внимательно читай условие "больше 256бит"
            //если написать просто v.BitCapacity == BitCapacity._384bit, то ты проверишь только на 384 бита
            //но если в будущем добавишь еще 512 битность, то это условие больше не будет работать правильно для 512 битных карт
            //потому надежнее проверять на больше, но представить значение как число
            var _256bit_Videocard = videocards.FirstOrDefault(v => (int)v.BitCapacity > (int)BitCapacity._256bit);

            //для начала запомни, если ты используешь метод предназначенный для коллекций, то обычно они уже сами внутри вызывают 
            //цикл и еще один писать не нужно!
            //то есть, метод Max работает так, как я напишу сейчас код
            //-подумай как в списке видеокарт найти ту, которая имеет самый большой объем видеопамяти
            //этот метод мы написали сами. Он возвращает объем, а не позицию карты с таким объемом или саму карту
            //к сожалению нет библиотечного метода, который бы возвращал объект или его позицию
            //есть метод который вернет объект (FirtsOrDefault()) или позицию(FindIndex()), 
            //которому скажем конкретное значение. Но пока мы не найдем это значение (которое может менятся от запуска
            //программы к запуску) мы не можем знать, что искать
            //этот метод я написал только для того, чтобы показать, как работает библиотечная, но писать ее каждый раз
            //конечно же нет смысла и лучше взять готовую Max
            var maxVolume = GetMaximumVolume(videocards);
            //этот вызов библиотечного метода даст тот же результат, что и вызов метода, который мы написали сами
            var maxVolumeLibrary = videocards.Max(c => c.VideocardVolume);
            //еще раз, раньше мы использовали методы, которые возвращали либо коллекцию либо объект
            //эти же методы возвращают простое число
            Console.WriteLine("\nMaximum volume is {0}|{1}", maxVolume, maxVolumeLibrary);

            //поскольку сверху находили только число, а не сам объект с макс. объёмом памяти,
            //то делаем способ, возвращающий объект, а не число

            //первое - метод Where возвращает коллекию объектов, которые соответствуют условию
            //следовательно, если используем Where, то переменная должна называться видеокарты ;)

            //второе, ты хотел поместить videocards.Max(c => c.VideocardVolume) прямо во внутрь Where
            //вместо maxVolume - это плохая идея, особенно если список будет большим
            //там каждый раз для каждого числа будет искаться максимальное - это называется оверхед по операциям
            //да, технически такое возможно, но практически лучше разбивать на несколько команд
            //одна находит максимальное значение и сохраняет его в переменной, вторая ищет это значение
            //var maxVolumeCards = videocards.Where(v => v.VideocardVolume == videocards.Max(c => c.VideocardVolume)).ToList();

            //третье, по условию было достаточно взять первую попавшуюся видеокарту с максимальным объемом
            //когда тебе достаточно одного объекта - используй FirstOrDefault вместо Where!
            //так не будет создаваться дополнительный итератор, который потом еще и в список преобразовывается
            //более того, Where должен пройти по всему списку, прежде чем закончится
            //а методу FirstOrDefault достаточно найти первое значение и он сразу же заканчивается

            //здесь это оптимальнее потому, что мы уже, вызвав Max, перебрали все элементы и точно знаем
            //что в коллекции точно есть хотябы один элемент с таким количеством памяти
            //следовательно, если нам нужен только один объект, FirstOrDefault его найдет намного быстрее, чем 
            //Where, которому нужно выполнить намного больше работы
            //var maxVolumeCards = videocards.Where(v => v.VideocardVolume == maxVolume).ToList();
            //Console.WriteLine("\nAll videocards with max memory:");
            ////for (var i = 0; i < maxVolumeCards.Count; ++i) { }
            //foreach (var v in maxVolumeCards)
            //    Console.WriteLine("{0}, ", v);
            //этот метод возвращает один объект, а не коллекию, потому не нужен цикл, чтобы его выводить
            //более того, у тебя даже не получится это :)
            //так как мы точно знаем, что есть объект со значением maxVolume (мы это узнали используя Max)
            //то мы точно знаем, что ответ будет найден
            var maxVolumeFirstCard = videocards.FirstOrDefault(v => v.VideocardVolume == maxVolume);
            Console.WriteLine("\nFirst videocard with max memory is {0}:", maxVolumeFirstCard);


            //-аналогично, найди видеокарту у которой самая маленькая разрядность шины
            var minBitness = videocards.Min(b => b.BitCapacity);
            //обрати внимание, ты пытался написать так
            //это была попытка не сравнить, а присвоить полю значение. Компилятор говорил, что у него нет гэттэра :)
            //var minBitnessFirstCard = videocards.FirstOrDefault(b => b.BitCapacity = minBitness);
            var minBitnessFirstCard = videocards.FirstOrDefault(b => b.BitCapacity == minBitness);
            Console.WriteLine("\nFirst videocard with min bitness is {0}:", minBitnessFirstCard);

            //прежде чем переходить к пилотам еще пару замечаний
            //написанный мною метод с одной стороны нет нужды писать каждый раз, но у него есть преимущество
            //он ведь мог вернуть не просто число, он ведь нашел позицию объекта и мог вернуть сразу сам объект
            //попробуй написать еще один метод, типа моего, который вернет найденный объект, без необходимости потом
            //использовать FirstOrDefault
            //а потом я покажу еще более простой метод ;)
            //чем мне нравится шарп - он дает очень много вариантов решения задачи, которые, когда понимаешь, 
            //позволяют в той или иной ситуации написать более оптимальный код
            //мы рассмотрели
            Console.WriteLine("\nVideocard with maximum volume is {0}", GetMaximumVolumeCard(videocards));

            //еще один способ - использовать сортировку ;)
            var fromMinToMaxOrderedCards = videocards.OrderBy(c => c.VideocardVolume).ToList();
            var fromMaxToMinOrderedCards = videocards.OrderByDescending(c => c.VideocardVolume).ToList();
            //так мы получим самые большие объекты в конце списка для OrderBy или в начале для OrderByDescending
            //если нам нужно взять только один, то берем один элемент с нужного конца и все
            Console.WriteLine("\nMin card from list1 = {0}, min card from list2 = {1}",
                fromMinToMaxOrderedCards[0], fromMaxToMinOrderedCards[fromMaxToMinOrderedCards.Count - 1]);
            //Count -1  - это индекс последнего элемента
            Console.WriteLine("\nMax card from list1 = {0}, min card from list2 = {1}",
                fromMinToMaxOrderedCards[fromMinToMaxOrderedCards.Count - 1], fromMaxToMinOrderedCards[0]);

            //Получается, если нам нужны все объекты, которые соответствую минимальному или максимально
            //мы можем в цикле выводить элементы до тех пор, пока объем текущего будет равен объему первого/последнего
            //напишешь сам такой цикл для массива fromMinToMaxOrderedCards, чтобы получить только карты с минимальным объемом?
            Console.WriteLine("\n List of cards with min volume:");
            var minVolume = fromMinToMaxOrderedCards[0].VideocardVolume;
            for (var i=0; i < fromMinToMaxOrderedCards.Count; ++i)
            {
                //то, что внутри цикла не меняется, лучше вычислять перед циклом и сохранять (еще говорят "кэшировать")
                //в переменной
                //var minVolume = fromMinToMaxOrderedCards[0].VideocardVolume;
                //было так:
                //if (fromMinToMaxOrderedCards[i] == minVolume)
                //а надо так, т.к. мы сравниваем конкретную характеристику, а не объекты в целом
                if (fromMinToMaxOrderedCards[i].VideocardVolume == minVolume)
                    Console.WriteLine("{0}", fromMinToMaxOrderedCards[i]);
                else
                    break;
            }
        }

        //мы передаем методу коллекцию видеокарт, а он вернет одно число - какой самый большой объем памяти был найден
        //не саму видеокарту с таким объемом, а именно цифру объема
        static int GetMaximumVolume(Videocard[] cards)
        {
            var maxVolumeIndex = 0;
            for (var i = 1; i < cards.Length; ++i)
                if (cards[i].VideocardVolume > cards[maxVolumeIndex].VideocardVolume)
                    maxVolumeIndex = i;
            //он возвращает не позицию объекта с максимальным объемом, не сам объект с таким объемом, а только
            //это максимальное найденное число :(
            return cards[maxVolumeIndex].VideocardVolume;
        }

        static Videocard GetMaximumVolumeCard(Videocard[] cards)
        {
            //попробуй сам ;)
            var maxVolumeIndex = 0;
            for (var i = 1; i < cards.Length; ++i)
                if (cards[i].VideocardVolume > cards[maxVolumeIndex].VideocardVolume)
                    maxVolumeIndex = i;
            //этот метод возвращает уже объект, а не только одно его поле, что обычно удобнее и потом
            //нет нужды вызывать дополнительные методы
            //но этот способ подходит только для нахождения первого такого объекта
            //а вот, если нужно несколько, то нужно использовать Max + Where или еще один способ, который показываю выше
            return cards[maxVolumeIndex];
        }
        
        static string MemoryToString(Memory m)
        {
            //if (m == null)
            //    return "None";
            //return m.ToString();
            return m == null ? "None" : m.ToString();
        }

        static void Main(string[] args)
        {
            var module1 = new Memory(MemoryCompany.Kingmax, TypeOfMemory.DDR3, MemorySize._4Gb, 1800);
            var module2 = new Memory(MemoryCompany.Corsair, TypeOfMemory.DDR4, MemorySize._4Gb, 2666);
            var module3 = new Memory(MemoryCompany.Corsair, TypeOfMemory.DDR4, MemorySize._2Gb, 2666);
            var module4 = new Memory(MemoryCompany.Corsair, TypeOfMemory.DDR4, MemorySize._2Gb,2666);
            var module5 = new Memory(MemoryCompany.Corsair, TypeOfMemory.DDR4, MemorySize._32Gb, 2666);
            var module6 = new Memory(MemoryCompany.Kingston, TypeOfMemory.DDR4, MemorySize._16Gb, 2666);

            //говорим, что можно установить только 2 модуля
            //public Motherboard(MotherboardCompany motherboardCompany, string model, CPUSocketType supportedCPUSocket,
            //VideocardSocketType supportedVideocardSocket, TypeOfMemory supportedMemoryType, int maxAmountOfMemorySlots,
            //MemorySize amountOfMemory, int maxAmountOfVideocardSlots)
            var board = new Motherboard(MotherboardCompany.ASRock, "Pb5Bt", CPUSocketType.Socket_R4, 
                VideocardSocketType.PCI_E_3, TypeOfMemory.DDR4, 2, MemorySize._8Gb, 4);
            //для того, чтобы доавить все модули - нужно вызвать метод AddMemory столько раз, сколько хотим 
            //установить модулей
            //на момент вызова этого метода установленных модуле 0
            board.AddMemory(module1, 0);
            //память выше не того типа, следовательно после попытки установки неправильного модуля количество 
            //установленных модулей не изменится
            //но после вызова этого метода количество установленных станет равно 1
            board.AddMemory(module2, 1);
            //до вызова этого метода, установлено 1 модуль, но после вызова этого метода количество 
            //установленных станет равно 2
            board.AddMemory(module5, 2);
            //до вызова этого метода, установлено 2 модуль, это максимум, следовательно этот модуль не будет установлен
            //и счетчки как был 2, так и сотанется 2
            board.AddMemory(module4, 4);
            //тоже самое касается и все последующих попыток, они не изменят счетчик, а сгенерируют сообщение об ошибке
            board.AddMemory(module5, 0);
            board.AddMemory(module6, 1);
            //этот метод сгенерирует сообщение о том, что модуль не подходит и до счетчика дело даже не дойдет
            board.AddMemory(module1, 2);

            //копировать заголовок не обязательно, можно просто навестись мышкой на имя класса
            //public CPU(CPUCompany cpuCompany, string model, CPUSocketType CPUSocket, int amountOfCores)
            //для того, чтобы была видна подсказка, какой параметр сейчас вводится, нужно удалить закрывающую скобку
            var cpu1 = new CPU(CPUCompany.AMD, "Athlon", CPUSocketType.LGA_1151_v2, 4); 
            board.AddCPU(cpu1);
            Console.WriteLine();
            //добавь пару правильных процессоров, чтобы увидеть еще один ньюанс
            var cpu2 = new CPU(CPUCompany.AMD, "Athlon", CPUSocketType.Socket_R4, 4);
            board.AddCPU(cpu2);
            Console.WriteLine();
            //второй процессор добавим без применения переменной - на лету
            board.AddCPU(new CPU(CPUCompany.Intel, "Bobobbo", CPUSocketType.Socket_R4, 4));
            Console.WriteLine();
            //давай все же проверим замену процессора - добавь правильный процессор от AMD
            board.AddCPU(new CPU(CPUCompany.AMD, "Athlon XP2", CPUSocketType.Socket_R4, 2));
            Console.WriteLine();
            Console.WriteLine(board);

            Console.WriteLine();
            board.AddVideocard(new Videocard(VideocardCompany.Nvidia, "Razvodilovo", 
                VideocardSocketType.PCI_E_3, BitCapacity._384bit, 4), 0);

            Console.WriteLine();
            Console.WriteLine(board);

            board.DeleteMemory(0);
            //при работе с массивами нужно учитывать еще один ньюанс, как ты думаешь, что будет если вызвать эту команду
            board.DeleteMemory(10);

            Console.WriteLine();
            Console.WriteLine(board);

            board.DeleteVideocard(0);

            Console.WriteLine();
            Console.WriteLine(board);

            Tests();

            Console.ReadKey();
        }
    }
}
