﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Overloaded_Methods
{
    class Overloaded_Methods
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***** Fun with Method Overloading *****\n");
            // Calls int version of Add()
            Console.WriteLine(Add(10, 10));
            // Calls long version of Add()
            Console.WriteLine(Add(900000000000, 900000000000));
            // Calls double version of Add()
            Console.WriteLine(Add(4.3, 4.4));
            Add()
            Console.ReadLine();
        }

        //static void SimpleArrays()
        //{
        //    Console.WriteLine("=> Simple Array Creation.");
        //    // Create an array of ints containing 3 elements indexed 0, 1, 2
        //    int[] myInts = new int[3];
        //    // Create a 100 item string array, indexed 0 - 99
        //    string[] booksOnDotNet = new string[100];
        //    Console.WriteLine();
        //}

        //static void SimpleArrays()
        //{
        //    Console.WriteLine("=> Simple Array Creation.");
        //    // Create and fill an array of 3 Integers
        //    int[] myInts = new int[3];
        //    myInts[0] = 100;
        //    myInts[1] = 200;
        //    myInts[2] = 300;
        //    // Now print each value.
        //    foreach (int i in myInts)
        //        Console.WriteLine(i);
        //    Console.WriteLine();
        //}
    }
}
