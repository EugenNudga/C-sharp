﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Fuck_Sauvagerd
{
    class Fuck_Sauvagerd
    {
        static void Main(string[] args)
        {
            var a = 0x8000;
            var b = (short)a;
            Console.WriteLine("0x8000 = {0}", b);

            Console.ReadKey();
        }
    }
}
