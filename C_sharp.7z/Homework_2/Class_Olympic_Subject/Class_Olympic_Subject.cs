﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Olympic_Subject
{
    class Class_Olympic_Subject
    {
        static void Main(string[] args)
        {
            var someStrings = new List<string>() { "Привет", " тебе ", "идущий!" };
            //для того, чтобы вызвать статик метод не нужно создавать объект, просто
            //пишем имяКласса.имяМетода
            var singleString = HelperClass.ListOfStringsToSingleString(someStrings);
            Console.WriteLine("concatenated string: {0}", singleString);
            //эта строка еще более бесполезна, так как на экран будет выведено
            //не содержимое списка, а строка System.Collections.Generic.List`1[System.String]
            Console.WriteLine("Try to print List: {0}", someStrings);

            var arrayOfStrings = new string[] { "Какое-то ", "предложение которое оказалось в", "массиве строк",
                "и которое объеденим в одну строку" };
            //применение хэлпэр метода для массива строк
            //этот метод вернет массив строк как одну единственную строку
            //которую уже можно без циклов вывести на экран
            var singleString2 = HelperClass.ArrayOfStringsToSingleString(arrayOfStrings);
            //вот эта команда выводит массив, преобразованный в строку
            //и нам при этом больше не нужно использовать цикл, так как цикл был использован
            //внутри метода HelperClass.ArrayOfStringsToSingleString
            Console.WriteLine("concatenated string: {0}", singleString2);
            //в случае массива C# пытается вести себе лучше и выводит часть информации из массива
            //но только часть
            //еще раз, если пробовать вывести на экран список или массив - без цикла не получится
            //вывод массива выводит только первый элемент. Именно по-этому я выше 
            //вызвал хэлпер метод и для массива arrayOfStrings, присвоив результат
            //переменной singleString2 и вывев ее строкой выше
            //не нужно ничего делать, я уже выше все сделал!
            //именно потому, что шарп, не умеет выводить без цикла ни массивы
            //ни списки я создал по одному хэлпер методу для каждого типа
            //эта строка бесполезна, я ее печатал только чтобы показать эту бесполезность
            Console.WriteLine("Try to print Array: {0}", arrayOfStrings);

            var winners1 = new OlympicSubject2();
            //этот конструктор мы делали только для того, чтобы показать
            //что можно создавать конструкторы и другого типа, не только перечисления
            //но он ничего не делает и данные в нем тоже пустышка
            //var winners3 = new OlympicSubject2("foot", "Germany", "Galaluna", "Ukraine");
            //var winners3 = new OlympicSubject2(Subjects.football, Countries.Zimbabwe, Countries.Ukraine, Countries.Galaluna);
            var winners4 = new OlympicSubject2(Subjects.real_Life, Countries.Zimbabwe, Countries.Ukraine, Countries.Galaluna);
            //этот объект будет содержать результаты обо всех дисциплинах за 1998й год
            var result1998 = new YearResult(1998);
            //result1998.AddSubject(winners3);
            //Для того, чтобы добавить объект, не обязательно для него делать переменную
            //объект можно создать прямо в том месте, где он ожидается как параметр
            result1998.AddSubject(winners1);            
            result1998.AddSubject(winners4);
            //вернусь через минуту

            var apartment1 = new ApartmentPassport(30, 4, 150, 100);
            var apartment2 = new ApartmentPassport(34, 4, 150, 100);//после этого надо добавить квартиру в здание
            var room1 = new RoomDescription("Bathroom", 20);
            var building1 = new Building( "Hafencity 777",100);

            //тебе понятны две строки ниже?
            //так в квартиру добавили комнату
            apartment1.AddRoom(room1);
            //так в здание добавили квартиру
            building1.AddApartment(apartment1);
            building1.AddApartment(apartment2);

            Console.WriteLine(building1);

            Console.WriteLine();

            Console.WriteLine(result1998);

            Console.WriteLine();
            
            Console.WriteLine(winners1);

            Console.WriteLine();

            //Console.WriteLine(winners2);

            Console.WriteLine();

            //Console.WriteLine(winners3);

            Console.WriteLine();

            Console.WriteLine(winners4);

            Console.WriteLine();

            Console.WriteLine(apartment1);

            Console.WriteLine();

            Console.WriteLine(room1);

            Console.WriteLine();

            Console.WriteLine(building1);

            Console.ReadKey();
        }
    }
}
