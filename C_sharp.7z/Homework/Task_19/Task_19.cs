﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_19
{
    class Task_19
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры целое положительное число.
            //Вывести в строку все чётные числа от нуля до указанного числа включительно.
            //Пример ввода      //7
            //Пример вывода     //0 2 4 6
            Console.Write("Enter a positive integer number: ");
            var num = Convert.ToByte(Console.ReadLine());

            //но эту задачу можно сделать оптимальнее, не использовать if, а прибавлять 2 вместо 1 ;)
            //i = +2 делает не то, что ты думаешь, оно делает тоже самое, что и i=2, присваивает 2, а не увеличивает на 2
            for ( var i = 0; i <= num; i+=2)
            {
                //есил использовать правильную прибавку на каждой итерации, то проверка на четность избыточна
                //if ((i % 2) == 0)
                Console.Write("{0} ", i);
            }
                

            Console.ReadKey();
        }
    }
}
