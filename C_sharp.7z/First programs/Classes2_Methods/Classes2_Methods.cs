﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Classes2_Methods
{
    class Classes2_Methods
    {
        static void Main(string[] args)
        {
            //создай пару объектов класса Car
            var rydvan = new Car("рыдван", 2000000, 20, 120, 140);
            //у электромобилей есть понятие размер батареи и расход батареи
            //так что не получится вообще с 0 для расхода и размера бака, ну да давай не будем
            //брать пока не бензиновые
            var mers = new Car("mers", 1, 6, 60, 60);

            rydvan.Move(900);
            rydvan.Move(90);
            //всегда вызов метода происходит у объекта
            //ты типа говоришь, конкретный объект мерседес, проедь такое расстояние
            mers.Move(100);
            //а вот мы еще раз сказали ему проехать, уже другое
            //так в коде можно вызывать методы сколько угодно раз
            //каждый объект будет хранить как финально у него изменился пробег и сколько топлива осталось
            mers.Move(5);

            Console.WriteLine("\n\n");
            Console.WriteLine("{0}\n\n{1}", rydvan, mers);

            Console.WriteLine("\n\nChecking the work of method FillUpGasTank:");
            //компилятор сам понимает, какую версию метода вызвать по количеству 
            //и типу параметров, которые передаются в скобках
            mers.FillUpGasTank();
            //rydvan.FillUpGasTank(rydvan.MaxLoad);
            rydvan.FillUpGasTank(50);
            //rydvan._amountOfGas = 1000;//даже если метод FillUpGasTank контролирует, что
            //нельзя влить больше максимума, сделай мы поле _amountOfGas публичным
            //сразу получился бы такой эксплоит, который позволил бы перечеркнуть всю нашу защиту
            Console.WriteLine("\n\n");
            Console.WriteLine("{0}\n\n{1}", rydvan, mers);
            Console.ReadKey();
        }
    }
}
