﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManyConstructors
{
    //класс для точки. Тот редкий случай, когда удобнее оставить поля публичными
    public class Point
    {
        public double X;
        public double Y;
        public Point(double x, double y)
        {
            X = x;
            Y = y;
        }
    }

    public class Rectangle
    {
        //это координаты вершин прямоугольника
        //левого верхнего угла
        private double _x1;
        private double _y1;
        //правого нижнего угла
        private double _x2;
        private double _y2;
        //тогда его можно создать таким конструктором
        public Rectangle(double x1, double y1, double x2, double y2)
        {
            _x1 = x1;
            _y1 = y1;
            _x2 = x2;
            _y2 = y2;
        }
        //но можно и таким способом 
        public Rectangle(Point leftUpper, Point rightBottom)
        {
            _x1 = leftUpper.X;
            _y1 = leftUpper.Y;
            _x2 = rightBottom.X;
            _y2 = rightBottom.Y;
        }
        //а можно еще и таким - через точку и ширину с высотой
        public Rectangle(Point leftUpper, double width, double height)
        {
            _x1 = leftUpper.X;
            _y1 = leftUpper.Y;
            _x2 = _x1 + width;
            _y2 = _y1 + height;
        }
        //сожалению, имя параметра не является сигнатурой метода, а только тип, потому при наличии конструктора public Rectangle(double x1, double y1, double x2, double y2)
        //не получится создать такой
        //.ctor - сокращение от constructor
        //так как первый конструктор имеет 4 параметра double и этот тоже 4 параметра double, то компилятор не может их отличить
        //переименовать имя констукртора не получится - так как это всегда имя класса
        //public Rectangle(double x1, double y1, double width, double height)
        //можно схитрить так. Если у нас ширина и высота точно только целые числа, то вполне сработает. 
        //public Rectangle(double x1, double y1, int width, int height)
        //если все же вещественные, то можно так ;). Компилятор считает, что float это не double. Различить при вызове их тоже просто, то, что с буквой f - float
        //все остальное double. Но такие приколы слишком тонкие и лучше ими не увлекаться
        public Rectangle(double x1, double y1, double width, float height)
        {
            _x1 = x1;
            _y1 = y1;
            _x2 = _x1 + width;
            _y2 = _y1 + height;
        }
    }
}
