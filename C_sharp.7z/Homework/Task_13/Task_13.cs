﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_13
{
    class Task_13
    {
        static void Main(string[] args)
        {
            //Вывести результат логических действий И и ИЛИ.
            //Пример ввода      //0 1
            //Пример вывода
            //0 AND 1 is 0
            //0 OR 1 is 1

            Console.Write("Enter first integer number: ");
            var num0 = Convert.ToInt16(Console.ReadLine());
            Console.Write("Enter second integer number: ");
            var num1 = Convert.ToInt16(Console.ReadLine());

            //извини, я почему-то решил, что тебе нужно деление без остатка :(
            //тогда все до смешного просто Ж)
            // логические операции над числами имеют смысл только над числами 0 и 1! Они дают в ответе только 0 или 1

            Console.WriteLine("{0} AND {1} is {2}", num0, num1, num0 & num1);
            Console.WriteLine("{0} OR {1} is {2}", num0, num1, num0 | num1);

            Console.ReadKey();
        }
    }
}
