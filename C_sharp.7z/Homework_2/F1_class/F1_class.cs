﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace F1_class
{
    //это мы рассмотрели, как создавать и использовать независящие друг от друга классы
    //и ты, наконец, в этом преуспел ;)
    //но обычно один класс в поле не воин, в программе их несколько и они как-то связаны
    //между собой
    //так, если хорошо подумать, то получится, что если у нас будет класс команда, то он может
    //легко содержать у себя список своих пилотов, который со временем может меняться
    //немножко доделаем класс Team, чтобы в нем была информация о пилотах
    class F1_class
    {
        static void Main(string[] args)
        {
            //Пилот
            //ФИО, команда(из перечисления), проведенное к-во этапов, сколько раз был в тройке победителей этапа, очки
            //Команда
            //название(из перечисления), производитель двигателя (можно из перечисления), текущее место в командном зачете

            //mers - экземпляр (instance in English) класса Team
            //то есть когда мы пишем new ИмяКласса() - мы создаем экземпляр этого класса
            //потому если нам где-то нужно иметь список объектов какого-то класса
            //мы создаем переменную типа List<ИмяКласса> и она представляет собой
            //список экземпляров этого класса
            var mers = new Team(Teams.Mercedes, Engines.Mercedes, 1);

            //vovan - экземпляр (instance in English) класса Pilot
            var vovan = new Pilot("Vovochkin Vova Vladimirovich", 12, 0, 0);
            //специально без пробела, чтобы ShortFio вернуло всю строку, так как пробела нет
            var peterson = new Pilot("PetersonPeter", 12, 0, 0);
            var vovan3 = new Pilot("Vovochkin Vova Vladimirovich", 12, 0, 0);

            mers.AddPilot(vovan);
            mers.AddPilot(peterson);
            mers.AddPilot(vovan3);

            //мы переделали ToString класса Team так, чтобы она выводила информацию обо всех
            //пилотах, потому я удалил вывод пилотов отдельно
            Console.WriteLine(mers);

            Console.WriteLine();

            //Console.WriteLine(vovan);

            //- в классах о пилотах формулы1 найди из списка команд ту,
            //у которой больше всего пилотов.Как убедиться,
            //что больше нету команд с таким количеством пилотов?
            //в первую очередь нам нужно создать список команд,
            //каждой из которых нужно добавить по несколько пилотов
            List<Team> teams = new List<Team>();
            var red_bull = new Team(Teams.Red_Bull, Engines.Renault, 1);
            teams.Add(mers);
            teams.Add(red_bull);

            red_bull.AddPilot(vovan);
            red_bull.AddPilot(peterson);


            //var fromMinToMaxOrderedCards = videocards.OrderBy(c => c.VideocardVolume).ToList();
            var fromMaxToMinOrderedCards = teams.OrderByDescending(c => c.PilotsCount).ToList();
            //получили отсортированный список команд в порядке убывания количества пилотов в команде

            //теперь надо список пилотов в каждой тиме
            //задача была найти команду с максимальным числом пилотов
            //потому теперь нужно либо брать последний элемент либо
            //лучше отсортировать в противоположном порядке
            //предлагаю тебе закончить это задание уже самостоятельно
            var maxAmountofPilots = teams.Max(p => p.PilotsCount);

            var teamsWithMaxAmountofPilots = 
                fromMaxToMinOrderedCards.Where(p => p.PilotsCount == maxAmountofPilots).ToList();

            Console.WriteLine("\n Maximum amount of pilots can be found in:");
            foreach (var t in teamsWithMaxAmountofPilots)
                Console.WriteLine(t);

            var namesOfTeams = fromMaxToMinOrderedCards.Where(p => p.PilotsCount == maxAmountofPilots).
                Select(c => new Compositinfo(c.CompanyName));

            Console.WriteLine("\n Maximum amount of pilots can be found in teams:");
            foreach (var t in namesOfTeams)
                Console.WriteLine(t);

            Console.ReadKey();
        }
    }
}
