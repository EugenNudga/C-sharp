﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_38
{
    class Task_38
    {
        static void Main(string[] args)
        {
            //Вывести числовой квадрат заданного размера.
            //В каждой строке числа идут с единицы через пробел.
            //Размер считать с клавиатуры.
            //Пример ввода      //2
            //Пример вывода
            //1 2
            //1 2

            while (true)
            {
                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter a positive integer number (amount of rows): ");
                    var rows = Convert.ToInt32(Console.ReadLine());
                    
                    for (var i = 1; i <= rows; i++)
                    {
                        for (var j = 1; j <= rows; j++)
                        {
                            Console.Write("{0} ", j);
                        }
                        Console.WriteLine();
                    }
                    
                }
                else
                    break;
                Console.WriteLine();
            }   
            Console.ReadKey();
        }
    }
}
