﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_2
{
    class Task_2
    {
        static void Main(string[] args)
        {
            Console.Write("Enter any first digit: ");
            var dig1 = Convert.ToSingle(Console.ReadLine()); //поначалу тут было ToByte, потом ToSingle
            Console.Write("Enter any second digit: ");
            var dig2 = Convert.ToSingle(Console.ReadLine());

            //condition ? resultIfTrue : resultIfFalse <--- тернарный оператор

            //при такой форме можно выбрать, что писать в одном случае и что в другом
            Console.WriteLine("{0} < {1} is {2}", dig1, dig2, dig1 < dig2 ? "правда" : "ложь");
            Console.WriteLine("{0} > {1} is {2}", dig1, dig2, dig1 > dig2 ? 1 : 0);
            Console.WriteLine("{0} <= {1} is {2}", dig1, dig2, dig1 <= dig2 ? 1 : 0);
            Console.WriteLine("{0} >= {1} is {2}", dig1, dig2, dig1 >= dig2 ? 1 : 0);
            Console.WriteLine("{0} == {1} is {2}", dig1, dig2, dig1 == dig2 ? 1 : 0);
            Console.WriteLine("{0} != {1} is {2}", dig1, dig2, dig1 != dig2 ? 1 : 0);

            //при такой форме всегда пишет true/false
            Console.WriteLine("{0} < {1} is {2}", dig1, dig2, dig1 < dig2);
            Console.WriteLine("{0} > {1} is {2}", dig1, dig2, dig1 > dig2);
            Console.WriteLine("{0} <= {1} is {2}", dig1, dig2, dig1 <= dig2);
            Console.WriteLine("{0} >= {1} is {2}", dig1, dig2, dig1 >= dig2);
            Console.WriteLine("{0} == {1} is {2}", dig1, dig2, dig1 == dig2);
            Console.WriteLine("{0} != {1} is {2}", dig1, dig2, dig1 != dig2);

            Console.ReadKey();
        }
    }
}
