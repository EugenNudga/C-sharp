﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Olympic_Subject
{
    //когда разрабатываешь классы - начинай с самых простых и маленьких
    public class RoomDescription
    {
        //содержит поля:
        //название комнаты(например ванная), площадь

        private string _roomName;
        private float _area;
        //формулу 1 не делал?

        public RoomDescription(string roomName, float area)
        {
            _roomName = roomName;
            _area = area;
        }

        public string RoomName
        {
            get { return _roomName; }
        }

        public override string ToString()
        {
            return string.Format("Room information:\nName of the room: {0}\nArea: {1}m2", _roomName, _area);
        }
    }
}
