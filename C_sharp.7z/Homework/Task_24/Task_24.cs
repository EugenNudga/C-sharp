﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_24
{
    class Task_24
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры два целых числа -делимое и делитель, причем делитель не равен нулю.
            //Вывести на экран наименьшее число, кратное делителю, не меньшее (или другими словами >=) делимого.
            //Пример ввода      //15 6
            //Пример вывода     //18        <----это как!?!??!?

            //у нас есть первое число
            //нужно найти ближайшее число, которое >= этого первого числа
            //которое без остатка делится на второе число


            Console.Write("Enter a positive integer number (must be bigger than a divisor): ");
            var num0 = Convert.ToByte(Console.ReadLine());
            Console.Write("Enter an integer divisor (must not be zero): ");
            var num1 = Convert.ToByte(Console.ReadLine());
            while (num1 == 0)
            {
                Console.Write("The entered divisor is zero, so try again: ");
                num1 = Convert.ToByte(Console.ReadLine());
            }

            //Зачем начинать цикл от 0, если его можно начать только от первого числа
            //а вести цикл до числа, которое больше первого на второе
            //как только мы будем находить число, которое кратно второму - выводить на экран текущее и 
            //обрывать цикл
            //так мы выполним итераций не более второго числа
            for (var i = num0; i <= num0 + num1; i++)
            {
                if (i % num1 == 0)
                {
                    Console.Write("{0} ", i);
                    break;
                }
            }

            //этот способ намного оптимальнее твоего, но можно еще оптимальнее сделать
            //без цикла вообще - просто используя математику, клас так за 3й ;)
            //показывать?

            //как узнать, сколько раз число num1 входит в число num0?
            //правильно, разделив num0 / num1 и отбросил остаток - мы полчим, сколько раз num1 входит в num0

            //как видишь нужно маленькое уточнение для ситуации, когда num0 сразу кратно num1
            //заключается в том, что если это правда, то не нужно прибавлять num1
            //красивее всего это записать тернарным оператором ;)
            var num2 = num0 / num1;
            Console.Write("\n{0} ", (num0%num1 == 0) ? (num1*num2) : (num1 * num2) + num1 );
            Console.Write("\n{0} ", (num1 * num2) + ((num0 % num1 == 0) ? 0 : num1 ));
            Console.Write("\n{0} ", (num1 * (num2 + ((num0 % num1 == 0) ? 0 : 1))));
            //мне кажется этот способ самый понятный, хоть и не такой краткий как первый
            //так как не нужно прибавлять 0
            var nearestNumber = num1 * num2;
            if (num0 % num1 != 0)
                nearestNumber += num1;
            Console.Write("\n{0} ", nearestNumber);

            Console.ReadKey();

        }
    }
}
