﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_36
{
    class Task_36
    {
        static void Main(string[] args)
        {
            while (true)
            {
                //Считать с клавиатуры два целых числа, причём второе число не меньше первого.
                //Вывести в строку все нечётные числа в промежутке от первого до второго включительно.
                //В указанном промежутке гарантируется на вывод хотя бы одно число.
                //Пример ввода      //7 15
                //Пример вывода     //7 9 11 13 15 
                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter a first integer number (from which we will start): ");  //
                    var num0 = Convert.ToByte(Console.ReadLine());
                    Console.Write("Enter a second integer number: ");
                    var num1 = Convert.ToByte(Console.ReadLine());

                    if (num0 < num1)
                    {
                        //Пример ввода      //7 15
                        //Пример вывода     //8 10 12 14
                        if (num0 % 2 == 0)
                            num0 += 1;
                        //if (num1 % 2 == 0)
                        //    num1 -= 1;
                        for (var i = num0; i <= num1; i += 2)
                        {
                            Console.Write("{0} ", i);
                        }
                        Console.WriteLine();
                    }
                    else
                    {
                        //Пример ввода      //15 7
                        //Пример вывода     //15 13 11 9 7 
                        if (num0 % 2 == 0)
                            num0 -= 1;
                        //if (num1 % 2 == 0)
                        //    num1 += 1;
                        for (var i = num0; i >= num1; i -= 2)
                        {
                            Console.Write("{0} ", i);
                        }
                        Console.WriteLine();
                    }
                    Console.WriteLine();
                }
                else
                    break;
            }
            Console.ReadKey();
        }
    }
}
