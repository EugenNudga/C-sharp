﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//домашнее задание - сделать метод ToString, который будет выводить информацию обо всех
//дисциплинах нужного года, очень похоже на Team + Pilot
//кроме окончания работ по классу YearResult
//попробуй подумать, как организовать связь между классами Building, Appartment и Room
//так чтобы здание содержало список всех квартир
//а каждая квартира содержала список всех комнат

namespace Class_Olympic_Subject
{
    class YearResult
    {
        //содержит поля: год, диспиплины(массив экземпляров класса OlympicSubject2)
        private int _year;
        private List<OlympicSubject2> _subjects = new List<OlympicSubject2>();

        //передаем только год, для добавления дисциплин сделаем отдельный метод

        public YearResult(int year)
        {
            _year = year;
        }

        public void AddSubject(OlympicSubject2 subject)
        {
            //if (_pilots.Count >= 2)
            //    Console.WriteLine("Can't add more than 2 pilots");
            //else
            //{
            ////если написать так, то, будет выведено не имя пилота, а вся информация о нем
            ////Console.WriteLine("Pilot {0} added to team {1}", pilot, _name);
            ////если нужно только ФИО, то добавим гэттэр пилоту, который возвращает только имя
            //Console.WriteLine("Pilot {0} added to team {1}", pilot.ShortFio, _name);
            //_pilots.Add(pilot);
            //pilot.AssignTeam(_name);
            //}
            _subjects.Add(subject);
            //у пилотом нужно было назначать команду, ну а дисциплине год не нужен
            //потому у нас метод в одну строку
        }

        public override string ToString()
        {
            var subjectsInfo = "";
            for (var i = 0; i < _subjects.Count; ++i)
                subjectsInfo += string.Format("{0}, ", _subjects[i].Subjects);
            return string.Format("Results of {0} in year {1}:\n", subjectsInfo, _year);
        }
    }
}

