﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameUnits
{
    public class Vehicle : Unit
    {
        protected int _crewSize;

        public Vehicle (string name, float health, float maxSpeed,
            bool canFly, bool canSwim, bool canMoveOnGround, int crewSize) :
            base(name, health, maxSpeed, canFly, canSwim, canMoveOnGround)
        {
            Console.WriteLine("Vehicle.Constructor for {0}", name);
            _crewSize = crewSize;
        }

        public void Repair(float repairPack)
        {
            _health += repairPack;
            if (_health > _maxHealth)
                _health = _maxHealth;
        }

        public override string ToString()
        {
            //вот таких подробных ToString делать обычно не нужно
            //даже не обязательно делать в родителях что-то. Посмотрим на примере самолета
            return string.Format("Name: {0}\nHealth: {1}\nMaxSpeed: {2}\nCan fly: {3}\nCan swim: {4}\nCan move on ground: {5}\nCrew size: {6}", 
                _name, _health, _maxSpeed, _canFly, _canSwim, _canMoveOnGround, _crewSize);
        }
    }
}
