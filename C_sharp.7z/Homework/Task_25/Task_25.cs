﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_25
{
    class Task_25
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры два целых числа -делимое и делитель, причем делитель не равен нулю.
            //Вывести на экран наибольшее число, кратное делителю, не превышающее делимое.
            //Пример ввода      //15 6
            //Пример вывода     //12

            Console.Write("Enter a positive integer number (must be bigger than a divisor): ");
            var num0 = Convert.ToDecimal(Console.ReadLine());
            Console.Write("Enter an integer divisor (must not be zero): ");
            var num1 = Convert.ToDecimal(Console.ReadLine());
            while (num1 == 0)
            {
                Console.Write("The entered divisor is zero, so try again: ");
                num1 = Convert.ToByte(Console.ReadLine());
            }

            //for (var i = 2*num1; i <= num0; i++)
            //{
            //    if (i % num1 == 0)
            //    {
            //        Console.Write("{0} ", i);
            //        //break;
            //    }
            //}

            var num2 = Math.Floor(num0 / num1);
            Console.Write("\n{0} ", /*(num0 % num1 == 0) ? (num1 * num2) :*/ (num1 * num2) );

            Console.ReadKey();

        }
    }
}
