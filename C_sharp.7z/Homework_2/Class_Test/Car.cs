﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MySupercar
{
    //пространства имен можно вкладывать одно в другое
    namespace AnotherNamespace
    {
        //если класс используется внутри одного и того же пространства имен (namespace),
        //то можно public class не писать, но посмотрим, что произойдет, если класс с методом Main
        //перенести в другое пространство имен или вообще сделать без него
        //полное имя класса всегда состоит из всех пространств имен, которые он входит + имя класса
        class Car
        {
            private string _name;
            private string _model;
            //здесь логично бы число
            private int _year;

            public string Model { get { return _model; } }

            public Car(string name, string model, int year)
            {
                _name = name;
                _model = model;
                _year = year;
            }

            public override string ToString()
            {
                return string.Format("Car name: {0}, model: {1}, year: {2} ;)", _name, _model, _year);
            }
        }
    }
}
