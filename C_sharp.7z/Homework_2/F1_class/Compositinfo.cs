﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace F1_class
{
    public class Compositinfo
    {
        private Teams _company;

        public Compositinfo(Teams company)
        {
            _company = company;
        }

        public override string ToString()
        {
            return string.Format("{0}", _company);
        }
    }
}
