﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Conditioneer
{
    class Class_Conditioneer
    {
        static void Main(string[] args)
        {
            //класс Кондиционер
            //-поля: название, текущее количество фреона(л), средний расход(л / ч), максимальный объем(л)
            //- в конструктор передаем 4 параметра, чтобы присвоить их полям
            //- перегружаем ToString, чтобы можно было увидеть основную информацию о кондее
            //- создаем методы Work(float time) - для иммитации работы кондиционера,
            //которая тратит фреон и метод FillUp, для заправки.
            //Класс будет похож на автомобильный с урока

            //здесь пока не выводится ничего на экран потому, что у тебя весь код, который выполняется
            //- это только вызов конструктора. Само наличие класса не говорит, что вызови методы
            //то, что вызывается определяет код, который создает объекты класса и вызывает методы
            //у этих объектов
            var conditioneer = new Conditioneer("Fujitsu", 2, 0.1f, 5);

            //две строки ниже абсолютно идентичны для компилятора
            //он автоматически вызывает метод ToString для каждого объекта, если там ожидается
            //строка. Обращение к объекту внутри Console.Write один из таких случаев
            //Console.WriteLine(conditioneer.ToString());
            Console.WriteLine(conditioneer);

            //ты определил метод, что он возвращает какой-то результат, но ни в однои месте 
            //вызова этого метода, ты не присваиваешь его никаким переменным
            //в прошлом классе Автомобиль, мы делали, что этот метод ничего не возвращает
            //сделать логично такое же поведение
            conditioneer.Work(10);

            Console.WriteLine();
            Console.WriteLine(conditioneer);

            conditioneer.FillUp(5);

            Console.WriteLine();
            Console.WriteLine(conditioneer);

            conditioneer.Work(200);

            Console.WriteLine();
            Console.WriteLine(conditioneer);

            Console.ReadKey();

        }

        
    }
}
