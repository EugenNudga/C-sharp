﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace User_Input
{
    class thirdMain
    {
        static void Main(string[] args)
        {
            //Для того, чтобы считать что-то с клавиатуры в шарпе используем команду Console.ReadLine
            //особенность этой команды в том, что чтобы ты не ввел, она считает как текст
            //даже если ввести только цифры
            //потому, для получения чисел, как чисел, нужно преобразовать результат ввода в нужный тип

            //если нужно, чтобы перед вводом появилась подсказка - нужно использовать Console.Write или Console.WriteLine
            //это пример как происходит интпут без ухищрений - это всегда текстовые строки
            //Console.Write("Input some value: ");
            //var input1 = Console.ReadLine();
            //Console.WriteLine("Input another value: ");
            //var input2 = Console.ReadLine();

            //теперь смотрим, как быть, когда нужны числа
            Console.Write("Enter your name please: ");
            //так как имя - это просто текст, то делать ничего дополнительно не нужно
            var name = Console.ReadLine();
            Console.Write("Enter your age now: ");
            //метод Convert.ToInt32 - говорит, попробуй интерпретировать строку как тип int
            // метод Convert.ToInt16 - как short
            // метод Convert.ToByte - это byte, число 0..255
            //если методы для приведение ко всем типа - разберешься ;)
            //так для float Convert.ToSingle
            var age = Convert.ToByte(Console.ReadLine());
            //Single = float
            Console.Write("and weight: ");
            var weight = Convert.ToSingle(Console.ReadLine());

            Console.Write("and height: ");
            var height = Convert.ToSingle(Console.ReadLine());

            //нужно быть готовым к тому, что попытка привести к типу, который ты указываешь может провалиться
            //и программа закрашиться
            //есть способы отлавливать такие ситуации, но о них позднее
            //главное нужно знать, что для вещественных чисел нужно вводить символ, определенный в ОС, а не .
            //на самом деле, в реальных программах консольным вводом почти не пользуются, так что можно 
            //особо не париться с этим

            Console.WriteLine("Hello {0} who is {1} years old with weight {2} kg", name, age, weight);
            //сделаем так, чтобы компьютер всегда говорил, что ему в 2 раза больше лет ;)
            //напиши строку кода, которая скажет, "а я компьютер, мне столько то лет"
            var comFakeAge = age * 2;
            Console.WriteLine(" and i'm a laptop {0} years old", age * 2 /*comFakeAge*/);

            Console.WriteLine(" body's mass index is {0}", weight/Math.Pow(height,2));

            //я поставил break point, чтобы показать немного отладку ну и за одно увидеть типы того, что будем вводить
            Console.ReadKey();
        }
    }
}
