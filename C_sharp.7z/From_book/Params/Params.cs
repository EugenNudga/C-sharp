﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//если коротко, то оператор params просто позволяет сделать возможность упрощенно передавать несколько (неважно сколько) 
//значений в метод, не обязательно явно создавай массив. Без этого, программисту пришлось бы всегда массив
//создавать явно. Это называется синтаксический сахар  и сделано чисто для удобства программиста

namespace Params
{
    class Params
    {
        static void Main(string[] args)
        {
            Addition(1, 2, 3, 4, 5);

            int[] array = new int[] { 1, 2, 3, 4 };
            Addition(array);
            Addition(new int[] { 10, 15 });
            //писать так можно только благодаря тому, что перед int[] integers стоит params
            //этот оператор говорит компилятору, возьми все, что будет передано через запятую и создай из 
            //него массив. Если бы не было слова params, то оба варианта выше были бы доступны, а вот 
            //без вариант ниже, без явного создания массива стал бы недоступен
            //не будь в заголовке этого метода params, пришлось бы вызывать так Addition(new []{10, 15, 20});
            Addition(10, 15, 20);
            //у метода Additional2 не написано params и потому в него можно передавать только явно созданные
            //массивы, так
            Addition2(new int[] { 10, 15 });
            //или так
            Addition2(array);
            //но не так
            //Addition2(10, 15, 20);


            Addition();


            Console.WriteLine("***** Fun with Methods *****");
            // Pass in a comma-delimited list of doubles…
            double average;
            average = CalculateAverage(4.0, 3.2, 5.7, 64.22, 87.2);
            Console.WriteLine("Average of data is: {0}", average);
            // …or pass an array of doubles.
            double[] data = { 4.0, 3.2, 5.7 };
            average = CalculateAverage(data);
            Console.WriteLine("Average of data is: {0}", average);
            // Average of 0 is 0!
            Console.WriteLine("Average of data is: {0}", CalculateAverage());
            Console.ReadLine();
        }

        static void Addition2(int[] integers)
        {
            for (int i = 0; i < integers.Length; i++)
            {
                Console.Write("{0}, ", integers[i]);
            }
            Console.WriteLine("\n");
        }
        //оператор params  говорит компилятору, что в этом месте может быть произвольное количество
        //переметров типа, который идет за словом params. С данном случае типа int
        //и хоть мы перечисляем эти параметры просто через запятую, не создавая явно массив
        //компилятор создаст его за нас автоматически
        static void Addition(params int[] integers)
        {
            int result = 0;
            for (int i = 0; i < integers.Length; i++)
            {
                result += integers[i];
            }
            Console.WriteLine("sum = {0} ", result);
            Console.WriteLine();
        }

        static double CalculateAverage(params double[] values)
        {
            Console.WriteLine("You sent me {0} doubles.", values.Length);
            double sum = 0;
            if (values.Length == 0)
                return sum;
            for (int i = 0; i < values.Length; i++)
                sum += values[i];
            return (sum / values.Length);
        }
    }
}
