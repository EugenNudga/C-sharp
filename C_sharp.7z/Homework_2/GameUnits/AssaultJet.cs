﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameUnits
{
    public class AssaultJet : Flying
    {
        //штурмовик, который предназначен только для атаки по земле.
        //От кого так же наследуем?
        //Дополнительно содержит: признак имеет ли бронирование, дальность пуска ракет,
        //урон по технике, урон по людям

        private bool _hasArmor;
        private float _rocketMaxRange;
        private int _vehicleDamage;
        private int _peopleDamage;


        public AssaultJet(string name, float health, float maxSpeed, float maxHeight,
            float upSpeed, int crewSize, bool hasArmor, float rocketMaxRange, int vehicleDamage, int peopleDamage) :
            base(name, health, maxSpeed, maxHeight, upSpeed, crewSize)
        {
            _hasArmor = hasArmor;
            _rocketMaxRange = rocketMaxRange;
            _vehicleDamage = vehicleDamage;
            _peopleDamage = peopleDamage;
        }
    }
}
