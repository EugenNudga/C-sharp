﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Object_Functionality
{
    class Object_Functionality
    {
        static void Main(string[] args)
        {
            //когда в месте, где компилятор ожидает текст вставляется булевое значние
            //то для значения true неявно ToString(), который дает такой же результат, что и строка True
            //если не хочешь делать приведения типа, типа это чуть дольше, то можно использовать константу bool.TrueString
            //тоже самое для значения false, есть константа bool.FalseString
            //это такая мелочь, ради которой нет смысла морочиться
            var a = 0;
            Console.WriteLine("1:{0}, 2:{1}", true, bool.TrueString);
            ObjectFunctionality();
        }

        static void ObjectFunctionality()
        {
            Console.WriteLine("=> System.Object Functionality:");
            // A C# int is really a shorthand for System.Int32,
            // which inherits the following members from System.Object.
            //абсолютно у каждого значения C# можно вызвать метод GetHashCode()
            //это именно тот метод, который используется у множеств, для определения положения объекта в нем
            //этот метод для любого типа возвращает число
            //обычно простому обывателю этот метод не нужен, но незаметно он вызывается автоматически всегда, когда нужно 
            //добавить объект в множество или словарь.
            //мы немного поговорим об этом, когда будем рассматривать словари
            Console.WriteLine("12.GetHashCode() = {0}", 155.GetHashCode()); //смысл пока непонятен
            Console.WriteLine("12.Equals(23) = {0}", 12.Equals(23));
            //точно так же как и с GetHashCode, у любого значения есть метод ToString
            //он незаметно вызывается каждый раз, когда ожидается текст, а получаем что-то другого типа
            //больше поговорим об этом когда будем рассматривать классы
            Console.WriteLine("12.ToString() = {0}", 12.ToString()); //просто тип поменяется с любого на стринг? да
            //эта строка сделает тоже самое, что и строка выше, просто метод ToString() будет вызван автоматически
            Console.WriteLine("12.ToString() = {0}", 12);
            Console.WriteLine("12.GetType() = {0}", 12.5.GetType());
            Console.WriteLine();

            Console.ReadKey();
        }
    }
}
