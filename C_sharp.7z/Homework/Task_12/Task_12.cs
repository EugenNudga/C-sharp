﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_12
{
    class Task_12
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры три целых не равных нулю числа.
            //Программа должна произвести только одну из следующих операций:
            //-Если сумма первого и второго чисел больше третьего числа, вывести alpha
            //- Если первое число меньше разности второго и третьего чисел, вывести bravo
            //- Если второе число кратно третьему, вывести charlie
            //- Если не сработало ничего из вышеуказанного, вывести zulu
            //Пример ввода      //2 2 3
            //Пример вывода     //alpha
            
            Console.Write("Enter first integer number: ");
            var num0 = Convert.ToInt16(Console.ReadLine());
            while (num0 == 0)
            {
                Console.Write("The entered first number is zero, so try again: ");
                num0 = Convert.ToByte(Console.ReadLine());
            }
            Console.Write("Enter second integer number: ");
            var num1 = Convert.ToInt16(Console.ReadLine());
            while (num1 == 0)
            {
                Console.Write("The entered second number is zero, so try again: ");
                num1 = Convert.ToByte(Console.ReadLine());
            }
            Console.Write("Enter third integer number: ");
            var num2 = Convert.ToInt16(Console.ReadLine());
            while (num2 == 0)
            {
                Console.Write("The entered third number is zero, so try again: ");
                num2 = Convert.ToByte(Console.ReadLine());
            }

            if ( (num0 + num1) > num2 )
            {
                Console.WriteLine("alpha");
            }
            else if ( num0 < (num1-num2) )
            {
                Console.WriteLine("bravo");
            }
            else if ( (num1%num2) == 0)
            {
                Console.WriteLine("charlie");
            }
            else
            {
                Console.WriteLine("zulu");
            }

            Console.ReadKey();

        }
    }
}
