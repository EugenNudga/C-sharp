﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

class Class_Test
{
    static void Main(string[] args)
    {
        var anotherCar = new AnotherCar();
        //var internalObject = new AnotherCar.OneMoreClass();
        //создать класс Car, который содержит:
        //марку, модель, год выпуска
        //для поля модель создать гэттэр
        //перегрузить метод ToString, чтобы он возвращал все об автомобиле

        //так как класс Class_Test не находится в пространстве имен класса Car
        //то для доступа к нему нужно указать это пространство перед именем класса
        var car = new MySupercar.AnotherNamespace.Car("Tesla","Marsiano", 2020 );

        Console.WriteLine("da modello: {0}, ragazza!", car.Model);
        Console.WriteLine("{0}", car.ToString());
        Console.ReadKey();
    }
}
