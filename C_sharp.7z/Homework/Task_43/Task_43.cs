﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_43
{
    class Task_43
    {
        static void Main(string[] args)
        {
            while (true)
            {
                //Вывести числовую пирамидку на total строк.
                //В первой строке стоит число 1.
                //В последующих строках стоят увеличивающиеся числа через пробел.
                //Пример ввода      //3
                //Пример вывода
                //1
                //2 3
                //4 5 6 //оказывается, это "Треугольник Флойда"
                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter a positive integer number (amount of rows): ");
                    var rows = Convert.ToInt32(Console.ReadLine());
                    var number = 1;
                    //не нужно сюда это вставлять, я просто показываю, что ты ниже написал код
                    //который работал для прямой задачи, этот код в чистом виде можно скопировать 
                    //в функцию GetStep в задаче 44 и таким образом не придумывать формулу
                    //которая не такая и простая, без подготовки
                    for (var i = 1; i <= rows; i++)
                    {
                        for (var j = 1; j <= i; j++)
                        {
                            Console.Write("{0,3} ", number);
                            number++;
                        }
                        Console.WriteLine();
                    }
                }
                else
                    break;
            }
            Console.ReadKey();
        }
    }
}
