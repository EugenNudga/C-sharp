﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameUnits
{
    public class Flying : Vehicle
    {
        //техника, которая может летать, наследуется от Unit
        //это просто один из многих параметров, но который гарантированно равен true
        //Дополнительно хранит: максимальная высота, скорость набора высоты, количество членов экипажа
        protected float _maxHeight;
        protected float _upSpeed;

        //здесь одна маленькая фишка, нам нет нужды передавать параметр canFly, так как мы точно знаем
        //что все летающее летает, так что удаляем сам параметр из конструктора
        //то же самое касается параметров плаванья и езды
        //по большому счету они как-то могут немного ехать, но будем считать, что они могут только летать -
        //это их основная функция
        //если захотим добавить класс гидропланов - добавим еще одни параметр "может садиться на воду"
        //но это не тоже самое, что их будут применять для передвижения по суше
        //здесь также удалены bool canFly, bool canSwim, bool canMoveOnGround,
        //т.к. мы в base сразу можем указать true, false
        public Flying(string name, float health, float maxSpeed,
            float maxHeight, float upSpeed, int crewSize) : 
            //для того, чтобы ты мог сослаться на эти параметры, тебе их нужно сначала добавить в конктруктор этого класса
            base(name, health, maxSpeed, true, false, false, crewSize)
        {
            _maxHeight = maxHeight;
            _upSpeed = upSpeed;
        }
    }
}
