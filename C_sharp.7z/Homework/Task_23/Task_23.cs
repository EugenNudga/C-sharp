﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_23
{
    class Task_23
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры целое неотрицательное число-максимум.
            //Считать с клавиатуры целый, не равный нулю делитель.
            //Вывести в строку числа от нуля до указанного максимума включительно, кратные заданному делителю.
            //Пример ввода      //99 10
            //Пример вывода     //0 10 20 30 40 50 60 70 80 90


            Console.Write("Enter a positive integer number (must be bigger than a divisor): ");
            var num0 = Convert.ToByte(Console.ReadLine());
            Console.Write("Enter an integer divisor (must not be zero: ");
            var num1 = Convert.ToByte(Console.ReadLine());
            while (num1 == 0)
            {
                Console.Write("The entered divisor is zero, so try again: ");
                num1 = Convert.ToByte(Console.ReadLine());
            }

            for (var i = 0; i <= num0; i+=num1)
            {
                Console.Write("{0} ", i);
            }


            Console.ReadKey();

        }
    }
}
