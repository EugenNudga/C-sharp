﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal_World
{
    public class Birds : Animals
    {
        //птицы пусть дополнительно содержат: размах крыльев, максимальную высоту полета,
        //признак "перелетные или постоянно живущие", для перелетных -на какое максимальное расстояние летают

        private int _wingspan;
        private int _maxFlyHeight;
        private bool _isMigratory;
        private int _maxMigrationDistance;

        //ты забыл добавить в конструктор те параметры, которые были в базовом классе
        public Birds (int wingspan, int maxFlyHeight, bool isMigratory, int maxMigrationDistance):
            base(name, age, weight, TypeOfReproduction.egg, canSwim, true, isPredator)
        {
            _wingspan = wingspan;
            _maxFlyHeight = maxFlyHeight;
            _isMigratory = isMigratory;
            _maxMigrationDistance = maxMigrationDistance;
        }

        public override string ToString()
        {
            var animalInfo = base.ToString;
            return string.Format("\nWingspan: {0}",
                _wingspan);
        }
    }
}
