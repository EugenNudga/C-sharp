﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_31
{
    class Task_31
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры целое основание и целый неотрицательный показатель.
            //Вывести через пробел степени числа основания от нулевой до заданной.
            //Пример ввода      //2 3
            //Пример вывода     //1 2 4 8

            Console.Write("Enter an integer number: ");  //
            var num0 = Convert.ToByte(Console.ReadLine());
            Console.Write("Enter a positive integer number: ");
            var num1 = Convert.ToByte(Console.ReadLine());

            for (var i = 0; i <= num1; i++)
            {
                Console.Write("{0} ", Math.Pow(num0, i));
            }

            Console.ReadKey();

        }
    }
}
