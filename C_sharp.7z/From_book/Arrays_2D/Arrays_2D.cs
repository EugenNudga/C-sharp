﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arrays_2D
{
    class Arrays_2D
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=> Rectangular multidimensional array.");
            // A rectangular MD array.
            //для определения одномерного массива пишут [], а для двумерного добавили между скобками ,
            //на самом деле можно создавать массивы и так [][], но такие массивы могут иметь 
            //нефиксированное число столцбов в строке. Обычно такое поведение не нужно и проще использовать
            //матрицы, у которых фиксированное число строк и столбцов.
            //обычно, когда нужно не фиксированное, то используют списки списков
            //так это пример списка, каждый элемент которого тоже список
            //вот так создается список, каждый элемент которого тоже список, но уже обычный
            List<List<int>> a = new List<List<int>>();
            //теперь добавим первую строку
            var line1 = new List<int>() { 10, 5, 1 };
            //во второй строке может быть другое к-во элементов, пусть 1
            var line2 = new List<int>() { 11 };
            //можно даже создать список вообще без элементов - пустой
            var line3 = new List<int>();
            //это мы добавляем в наш список списков первую строку
            a.Add(line1);
            //это вторую
            a.Add(line2);
            //так можно добавить список на лету, пусть будет пустой
            a.Add(new List<int>());
            //ну или с какими-то числами
            a.Add(new List<int>() { 100, 10, 1});
            //все эти команды эквиваленты созданию такой таблицы
            //10 5 1 
            //11
            //
            //100 10 1
            //если же создавать честную матрицу, у которой в каждой строке одно и то же к-во столбцов, 
            //то синтаксис с запятой проще и удобнее
            int[,] myMatrix;  //запятая в скобках!!!!!
            //так создается матрица 3х4
            //обычно считают, что первое число - это номер строки, а второе - столбца.
            //чтобы пока не усложнять, то так и запоминай, но по факту можно считать и наоборот
            //главное для себя принять одно правило и следовать ему везде
            //в литературе почти всегда первое число - строка
            myMatrix = new int[3, 4];
            // Populate (3 * 4) array.
            for (int i = 0; i < 3; i++)
                for (int j = 0; j < 4; j++)
                    myMatrix[i, j] = i * j;
            // Print (3 * 4) array.
            for (int i = 0; i < 3; i++)
            {
                for (int j = 0; j < 4; j++)
                    Console.Write(myMatrix[i, j] + "\t");
                Console.WriteLine();
            }

            //более компактный вариант 
            //for (int i = 0; i < 3; i++)
            //{
            //    for (int j = 0; j < 4; j++)
            //    {
            //        myMatrix[i, j] = i * j;
            //        Console.Write(myMatrix[i, j] + "\t");
            //    }
            //    Console.WriteLine();
            //}

            Console.WriteLine("=> Jagged multidimensional array.");//jagged - зубчатый
            // A jagged MD array (i.e., an array of arrays).
            // Here we have an array of 5 different arrays.
            int[][] myJagArray = new int[5][];
            // Create the jagged array.
            for (int i = 0; i < myJagArray.Length; i++)
                myJagArray[i] = new int[i + 7];
            // Print each row (remember, each element is defaulted to zero!).
            for (int i = 0; i < 5; i++)
            {
                for (int j = 0; j < myJagArray[i].Length; j++)
                    Console.Write(myJagArray[i][j] + " ");
                Console.WriteLine();
            }
            Console.WriteLine();

            Console.WriteLine();

        }
    }
}
