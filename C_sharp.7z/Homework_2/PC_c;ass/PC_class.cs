﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_class
{
    class PC_class
    {
        static void Main(string[] args)
        {
        }
    }
}
