﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//остался еще один общий момент, который позволит лучше читать лог
//нужно строить вывод по каким-то общим правилам, чтобы повысить его читаемость
//сейчас понять, что была попытка добавить/удалить объект, которая произошла неудачно, достаточно сложно
//предлагаю такое правило
//при каждом сообщении пишем имяКласса.ИмяМетода: "ну а дальше уже сам текст сообщения"
//так мы четко будем видеть, внутри какого класса было сгенерировано это сообщение и какой метод его обработал
//покажу пару примеров, а тебе будет д.з. закончить эту работу
namespace PC_class

{
    //добавить перечисление типПроцессорногоСлота
    //добавить перечисление типСлотаВидеокарты
    //добавить поле типа типПроцессорногоСлота в класс процессор
    //добавить поле типа типСлотаВидеокарты в класс видеокарты
    //и добавить в материнку поддерживаемый тип слота процессора и тип слота видеокарты
    //после этого написать методы добавление процессора и видеокарты
    //сам объект процессор удалить из конструктора
    //сначала материнка идет без любых деталей, а потом уже наполняется ими

    public enum MotherboardCompany { Acer, Asus, ASRock, Gigabyte, Biostar, EVGA, MSI};

    public class Motherboard
    {
        //класс Материнская плата:
        //содержит: производитель(из перечисления, нагугли 5 - 6
        //основных производителей), модель, объект процессор,
        //список модулей памяти, список Видеокарт

        //у нас нет контроля, что мы ставим поддерживаемый памятью модуль
        //для этого материнке нужно еще 3 поля - тип поддерживаемой памяти, из того же перечисления
        //что в памяти 
        //+ еще нужно поле сколько модулей можно установить максимум
        //проверять, что в материнской па
        //еще тип сокета процессора
        //еще тип сокета видеокарты
        //тип(перечисление: SD - RAM, DDR, DDR2, DDR3 и тп), 

        private TypeOfMemory _supportedMemoryType;
        private CPUSocketType _supportedCPUSocket;
        private VideocardSocketType _supportedVideocardSocket;
        private int _maxAmountOfMemorySlots;
        private int _maxAmountOfVideocardSlots;
        private MotherboardCompany _motherboardCompany;
        private string _model;
        //это мы объявляем, что в материнской плате может быть процессор
        //пока этой переменной не присоен какой либо объект она равна null (это значение по умолчанию для любого объекта)
        //мы убрали присвоение процессора в конструкторе, а специально для этого сделали отдельный метод
        //который проверяет соответствие слота и выдает предупреждение в случае необходимости
        private CPU _cpu;
        //компилятор по умолчанию делает тоже самое, потому такой код избыточен
        //private CPU _cpu = null;
        //список модулей памяти имеет смысл как список объектов типа Memory
        private Memory[] _memoryModules;
        private Videocard[] _videocards;
        //private List<Memory> _memoryModules = new List<Memory>();
        //private List<Videocard> _videocards = new List<Videocard>();
        //эта переменная говорит, сколько максимум памяти может быть, но она имеет не тот тип
        //по хорошему можно сделать целую переменную, но тогда появится возможность указывать значения, которые не допустимы
        //например, не слышал о материнках, которые бы поддерживали 5 гигабайт, обычно это цифры кратные степени 2: 4, 8, 16, 32, 64
        //потому надежнее(но чуть сложнее) сделать еще одно перечисление для этого
        //чуть позднее сделаем гэттэр, который сообщить сколько сейчас реально установленно
        //это максимум памяти в системе
        private MemorySize _amountOfMemory;

        public Motherboard (MotherboardCompany motherboardCompany, string model, CPUSocketType supportedCPUSocket,
            VideocardSocketType supportedVideocardSocket, TypeOfMemory supportedMemoryType, int maxAmountOfMemorySlots,
            MemorySize amountOfMemory, int maxAmountOfVideocardSlots)
        {
            //списки модулей памяти и видеокарт будут в самом начале пустыми
            //и для того, чтобы там что-то появилось нужно создать методы на добавлени
            //видеокарты и добавлени модуля памяти
            //не перечисления, а конкретного модуля или конкретной видеокарты
            //мы подобное делали когда добавляли команты в квартиру или квартиру в дом
            _motherboardCompany = motherboardCompany;
            _model = model;
            //процессор добавим посредством метода AddCPU
            //_cpu = cpu;
            _supportedCPUSocket = supportedCPUSocket;
            _supportedVideocardSocket = supportedVideocardSocket;
            _supportedMemoryType = supportedMemoryType;
            _maxAmountOfMemorySlots = maxAmountOfMemorySlots;
            _amountOfMemory = amountOfMemory;
            _maxAmountOfVideocardSlots = maxAmountOfVideocardSlots;
            _memoryModules = new Memory[_maxAmountOfMemorySlots]; //все элементы в таком массиве будут пустыми (равны null)
            _videocards = new Videocard[_maxAmountOfVideocardSlots];//все элементы в таком массиве будут пустыми (равны null)
            Console.WriteLine("Motherboard.Constructor(): {0} created", ToString());
        }

        //метод для private List<Memory> _memoryModules = new List<Memory>();
        //public void AddMemory(Memory memoryModule)
        //{
        //    //здесь применяем стандартный подход, делаем отсеивающих проверки, которые не добавляют модуль
        //    //а только выводят сообщение об ошибке, если такова была
        //    //и только в блоке else, куда мы попадем только если не было ошибок, мы добавим модуль

        //    //в этом методе, нудно проверить, что у модуля такой же тип, что и поддерживаемый платой
        //    //а так же нужно проверить, что сейчас пока модулей меньше, чем максимум
        //    //добавим первую - минуем _memoryModules.Count == _maxAmountOfMemorySlots
        //    //добавим вторую - минуем _memoryModules.Count == _maxAmountOfMemorySlots
        //    //добавим третью - минуем _memoryModules.Count == _maxAmountOfMemorySlots
        //    //добавим четвёртую - минуем _memoryModules.Count == _maxAmountOfMemorySlots
        //    //добавим пятую - программа из прошлой истории увидит, что стало 4 == 4
        //    //и выведет All 4 memory slots are fullfiled
        //    //таким образом до счётчика не дойдёт и в списке всегда будет 4 модуля (соответственно всегда 4 == 4)
        //    //если сейчас не максимум - пропускаем сообщение об ошибке и идем ниже
        //    if (_memoryModules.Count== _maxAmountOfMemorySlots)
        //    {
        //        Console.WriteLine("All {0} memory slots are fullfiled", _maxAmountOfMemorySlots);
        //        return;
        //    }
        //    //если не максимум, но не тот тип памяти - выводим д
        //    else if (_supportedMemoryType != memoryModule.MemoryType)
        //        Console.WriteLine("Wrong memory type! You can install only {0}, instead of {1}",
        //            _supportedMemoryType, memoryModule.MemoryType);
        //    //преобразование класса в число невозможно, ты выбрал не тот тип данных
        //    //чтобы получить из перечисление его числовое представление достаточно просто перед ним написать (int)
        //    //например (int)_amountOfMemory
        //    //но здесь тебе нужно было сравнивать не с еще одной переменной, которая хранила тоже самое
        //    //а нужно было вычислить, сколько уже памяти занимают текущие модули
        //    //для подсчета всех модулей можно выделить отдельное поле, а можно использовать LINQ
        //    //сюда попадем только тогда, когда все проверки выше были ложными - значит модуль можно добавить
        //    else
        //    {
        //        //здесь ты выведешь только название компании модуля, а хотелось бы больше
        //        //конкретики, думаю лучше подойдет результат ToString, который коротко опишет модуль
        //        //тогда гэттэр лишний, просто закон ToString для класса Memory
        //        //тоже самое и с видеокартами
        //        //эти строки равнозначны C# сам дописывает ToString для каждого объекта
        //        //который передается в Console.Write или string.Format
        //        //_motherboardCompany, memorys.ToString());
        //        _memoryModules.Add(memoryModule);
        //        //StringBuilder нужен только если тебе в цикле нужно что-то собрать
        //        Console.WriteLine("A memory was added to motherboard {0}:\n{1}. Visible is {2}GB",
        //            _motherboardCompany, memoryModule, VisibleMemory);
        //        //Физически в материнскую плату можно установить модулей на объем больше
        //        //чем она поддерживает, просто она будет видеть меньший объем
        //        //потому это условие приводит к выводу предупреждения, но не блокирует добавление модуля
        //        //единственное что, мы сначала добавим модуль, чтобы учеть и его размер, а потому уже будем проверять ;)
        //        //но вместо такой проверки создадим более удобный способ - создадим еще один гэттер
        //        //в случае когда добавляли по одному модулю, можно было проверять, что текущее количество стало равно
        //        //максимум, а когда добавляем блоками, например по 8 Гигабайт, нужно проверять еще, что стало больше 8
        //        //if (_memoryModules.Sum(m => (int)m.ModuleSize) > (int)_amountOfMemory)
        //        if (TotalMemory > (int)_amountOfMemory)
        //        {
        //            Console.WriteLine("Max amount of volume was reached: {0}GB installed but only {1}Gb is visible",
        //                TotalMemory, VisibleMemory);
        //        }
        //    }
        //}

        private int FindFirstEmptyIndex<T>(T[] array)
            //эта приписка говорит, что в качестве типа можно передавать любой класс
            where T:class
        {
            //этот цикл перебирает все элементы любого массива и если находит пустой элемент - вернет
            //его индекс, если же до конца массива ничего пустого не найдено - вернет -1, как признак этого
            for (var i = 0; i < array.Length; ++i)
                if (array[i] == null)
                    return i;
            //если дошли сюда - пустого элемента нет
            return -1;
        }

        //метод для private Videocard[] _videocards;
        //slotIndex - это порядковый номер слота. Все, метод закончен, но предлагаю его немного усложить
        //предположим, что нам не важно в какой модуль ставить, мы хотим, чтобы класс поместил модуль 
        //в первый свободный. Если же такого нет - говорил об ошибке, как если мы раньше добавляли модули,
        //а свободных слотов больше не было. Для этого сделаем значение по умолчанию -1
        //это значение признак, что мы не указали номер слота и пусть класс сам найдет свободный
        public void AddMemory(Memory memoryModule, int slotIndex = -1)
        {
            //это начнет сообщение, к которому будет прибавлена конкретика, что произошло ниже
            //так как мы не переводим курсор на следующую строку, что все будет выглядеть, как вроде
            //мы каждый раз добавляли этот текст ;)
            Console.Write("Motherboard.AddMemory(): ");
            if (slotIndex == -1)
            {
                //нас попросили самостоятельно найти первый попавшийся слот
                //для этого используем LINQ и найдем первый слот, который пустой
                //к сожалению метода FindIndex нет в массиве, можно преобразовать его в список и так найти
                //а можно поступить хитрее, написать свой метод. Преобразование массива в список, особенно
                //когда там много элементов, затратно по памяти да и время некоторое может занять.
                //потому мы оставим здесь этот код закоментированны, но напишем свой метод, который будет 
                //делать это для массивов
                //var fisrtEmptySlotIndex = _memoryModules.ToList().FindIndex(m => m == null);
                slotIndex = FindFirstEmptyIndex(_memoryModules);
                //после вызова метода FindFirstEmptyIndex slotIndex уже не должен быть -1
                //если остался - значит пустых слотов нет, о чем и выводи предупреждение
                if (slotIndex == -1)
                {
                    Console.WriteLine("No empty slot was found - can't add module");
                    //return заканчивает метод в этом месте и код ниже не пойдет
                    return;
                }
                //если дошли сюда, то в slotIndex будет номер слота, куда можно поставить модуль
                //следовательно код ниже сделает все так же, как еслибы мы с самого начала передали этот же
                //номер слота
            }
            //нам нужно сделать еще одну проверку - убедиться, что полученный номер слота не меньше -1
            //и не больше количества слотов. Так если у нас всего может быть 2 слота, то допустимыми 
            //номерами слотов могут быть только 0 или 1. 
            //проверка slotIndex >= _memoryModules.Length для того, что если слота 2, то 
            //_memoryModules.Length == 2, но slotIndex == 2 тоже не допустим
            else if (slotIndex < -1 || slotIndex >= _memoryModules.Length)
            {
                Console.WriteLine("Can't add memory module - invalid slot index {0}", slotIndex);
                return;
            }

            //если попали сюда, значит номер слота допустим и осталось только проверить, что тип его
            //совпадает
            //проверяем подходит ли слот - тот ли это тип памяти
            if (_supportedMemoryType != memoryModule.MemoryType)
                Console.WriteLine("Wrong memory type! You can install only {0}, instead of {1}",
                    _supportedMemoryType, memoryModule.MemoryType);
            else
            {
                //если слот подходит, то устанавливаем или заменяет карту

                //на самом деле мы можем поступать так же как и с заменой процессора
                //slotIndex - это номер слота, в котором мы можем проверить наличие ранее установленной карты
                //если там null, значит он пустой, если != null - там что-то есть
                //проверять на количество в случае массивов не нужно
                //так как slotIndex нам говорит конкретное место установки
                //если в слоте с номером slotIndex уже что-то стоит мы можем либо сказать, что слот занят,
                //либо сказать, что мы убрали то, что стояло и установить новое, как было с процессором

                //то, что я писал ниже о количестве правильно, действительно Length всегда возвращает размер
                //массива, даже если там не было добавлено ни одного элемента, но в данной ситуации, когда есть
                //номер слота это не важно. Было бы важно, если бы мы не передавали его и это означало бы - найди
                //первый свободный. Мы чуть позднее реализуем и этот вариант, но для начала сделаем замену
                //var emptySlots = _maxAmountOfMemorySlots;

                //так мы получим либо null - слот пустой, либо модуль, который был ранее установлен в этот слот
                var oldModule = _memoryModules[slotIndex];
                //старый процессор мы проверяли так
                //if (_cpu != null)
                if (oldModule != null)
                    Console.WriteLine("Замена модуля {0} модулем {1}", oldModule, memoryModule);
                else
                    Console.WriteLine("A memory was added to motherboard {0}into slot {1}:\n{2}. Visible is {3}GB",
                        _motherboardCompany, slotIndex, memoryModule, VisibleMemory);

                //так мы перетираем старый модуль если он был новым. Ну или просто ставим модуль, разницы нет
                _memoryModules[slotIndex] = memoryModule;
                if (TotalMemory > (int)_amountOfMemory)
                {
                    Console.WriteLine("Max amount of volume was reached: {0}GB installed but only {1}Gb is visible",
                        TotalMemory, VisibleMemory);
                }
            }
        }

        //этот гэттер вернет сколько памяти всего во всех установленных модулях
        //ошибка в том, что мы при суммировании просим дать ModuleSize у каждого модуля
        //но если в каком-то слоте модуля еще нет - то получится, что мы спросим у пустого объекта ModuleSize
        //что не допустимо, потому нужно проверить, если объект пустой, говорить, что там 0 памяти
        //а иначе оставить как было
        //m != null - признак, что модуль есть, тогда возвращаем его размер, а иначе подставляем для
        //этого слота 0
        //для списка было так, так как там не могло быть пустышек
        //public int TotalMemory { get { return _memoryModules.Sum(m => (int)m.ModuleSize); } }
        //для массива пришлось добавить проверку на пустышку
        //получается при работе с массивами объектов нужно думать о ситуации, что объекта нет
        //чего обычно не происходит со списками, где если объекта нет - его удаляют
        //метод Sum берет каждый слот и проверяет если в нем модуль, 
        //если есть - к сумме прибавляет его размер, или прибавляет 0, если слот пустой
        public int TotalMemory { get { return _memoryModules.Sum(m => m != null ? (int)m.ModuleSize : 0); } }

        //создадим еще один гэттэр, который вернет, сколько видит материнка из тех, которые установлены
        //это меньшее из двух чисел. Либо всего меньше, чем максимум, либо максимум
        //функция Math.Min возвращает меньше из двух чисел
        //если TotalMemory (сколько установлено) меньше максимума - вернет TotalMemory
        //если максимум меньше TotalMemory, то вернете максимум
        public int VisibleMemory { get { return Math.Min(TotalMemory, (int)_amountOfMemory); } }

        //метод для private List<Videocard> _videocards = new List<Videocard>();
        //public void AddVideocard(Videocard videocard)
        //{
        //    if (_videocards.Count == _maxAmountOfVideocardSlots)
        //    {
        //        Console.WriteLine("All {0} videocard slots are full", _maxAmountOfVideocardSlots);
        //        return;
        //    }
        //    Console.WriteLine("Videocard {0} added to motherboard {1}\n",
        //        videocard, _motherboardCompany);
        //    _videocards.Add(videocard);
        //}

        //метод для private Videocard[] _videocards;
        public void AddVideocard(Videocard videocard, int slotIndex = -1)
        {
            Console.Write("Motherboard.AddVideocard(): ");
            //теперь нужно этот метод сделать полностью аналогичным методу добавления модуля памяти
            //разница только в именах переменных
            //попробуй сам, подглядывая по минимуму ;)
            if (slotIndex == -1)
            {
                //нужно вызвать метод, который получит как параметр массив видеокарт
                slotIndex = FindFirstEmptyIndex(_videocards);
                if (slotIndex == -1)
                {
                    Console.WriteLine("No empty slot was found - can't add videocard");
                    return;
                }
            }
            else if(slotIndex == -1 || slotIndex >= _videocards.Length)
            {
                Console.WriteLine("Can't add videocard - invalid slot index {0}", slotIndex);
                return;
            }

            if (_supportedVideocardSocket != videocard.VideocardSocket)
                Console.WriteLine("Wrong videocard socket! You can install only {0}, instead of {1}",
                    _supportedVideocardSocket, videocard.VideocardSocket);
            else
            {
                //точно так же нам не нужно проверять количество, как и в случаем модулей памяти
                ////разница между списками и массивами в том, что массив всегда имеет один и тот же размер
                ////даже если в нем все эелементы пустые, его длинна равна тому числу, которое ты указывал
                ////как размер при создании массива
                //if (_videocards.Length == _maxAmountOfVideocardSlots)
                //{
                //    Console.WriteLine("All {0} videocard slots are full", _maxAmountOfVideocardSlots);
                //    return;
                //}
                //осталось только проверить, была ли ранее видеокарта в этом слоте
                var oldVideo = _videocards[slotIndex];

                if (oldVideo != null)
                    Console.WriteLine("Замена видяхи {0} на {1}", oldVideo, videocard);
                else
                    Console.WriteLine("Videocard {0} added to motherboard {1} into slot {2}\n",
                        videocard, _motherboardCompany, slotIndex);

                //тогда метод добавления видеокарт нужно изменить так, чтобы он получали не только саму видеокарту,
                //но и слот, в который она вставляется, тогда установка карты в конкретный слот
                //будет выглядеть так _videocards[slotIndex] = videocard;
                _videocards[slotIndex] = videocard;
            }
        }

        public void AddCPU(CPU cpu)
        {
            Console.Write("Motherboard.AddCPU(): ");
            //у этого метода есть минимум 2 недостатка: 
            //1) когда вставляем процессор, а там уже есть другой, то неплохо бы об этом сообщить
            //типа замена такого-то процессора на такой-то
            //2) у нас абсолютно нет контроля, что то, что мы указали в конструкторе процессора существует
            //в природе. Так мы указали для одного и того же слота, сначала AMD а потом Intel
            //давай для начала решим первую проблему, как более простую
            //добавь проверку того, что добавляемый процессор невалидный - тогда сообщение об ошибке и больше ничего
            if (!cpu.IsValid)
                Console.WriteLine("Can't add processor - invalid processor specification {0}", cpu);
            else if (_supportedCPUSocket != cpu.CPUType)
                Console.WriteLine("Wrong socket! Use {0} instead of {1}", _supportedCPUSocket, cpu.CPUType);
            else
            {
                //для того, чтобы проверить, что поле-объект раньше существовало используем проверку 
                //_cpu != null. Это работает для любых полей, тип которых класс
                //если бы было нужно проверить, что поле пустое, то проверка соотвественно _cpu == null
                if (_cpu != null)
                    //_cpu - тот который был
                    //cpu - новый процессор
                    Console.WriteLine("{0} replace with {1} added on motherboard {2}\n",
                        _cpu, cpu, _motherboardCompany);
                else
                    Console.WriteLine("{0} added to motherboard {1}", cpu, _motherboardCompany);
                //если предусматривается только один объект - не нужно создавать список
                //вот так буднично старый процессор перетирается новым
                //присвоив переменной типа класс новое значение мы на всегда теряем старое и хранит 
                //в будущем только новое. Работает так же, как если бы мы перетерли число новым числом
                //со списками будет сложнее, но всему свое время ;)
                _cpu = cpu;
            }                                  
        }

        //давай теперь здесь добавим вывод логирования о том, что был удален такой-то модуль, 
        //если он конечно же оказался в слоте и после этого напишем второй метод для видеокарт
        //логирование в нашем случае - это просто вывод сообщения
        //вывод на экран сообщения никаким образом не влияет на тип результата метода
        //если метод выводит только на экран, то он конечно void, но если он возвращает объект
        //то метод должен иметь такой же тип, как и у объекта и не важно сколько выводов на экран
        //ты напишешь в этом методе
        public Memory DeleteMemory(int numberOfSlot)
        {
            Console.Write("Motherboard.DeleteMemory(): ");
            //получили объект из нужного слота
            //в переменной removedModule будет либо объект либо null
            //нам нужно еще добавить одну проверку здесь
            //если указать номер слота, который не в диапазоне 0..totalSlotsCount-1, 
            //то получи ошибку времени выполнения о том, что индекс за пределами диапазона 'IndexOutOfRangeException' 
            //чтобы такого не было, нужно проверить, что индекс в допустимом диапазоне. Сделаешь сам ;)?
            if (numberOfSlot < 0 || numberOfSlot >= _memoryModules.Length)
            {
                Console.WriteLine("Wrong index, because the range is 0...{0}", _memoryModules.Length - 1);
                return null;
            }
            var removedModule = _memoryModules[numberOfSlot];
            //мы выведем сообщение о том, что модуль был удален только если в слоте что-то было
            if (removedModule != null)
            {
                Console.WriteLine("\nFrom slot {0} a memory {1} was removed", numberOfSlot, removedModule);
                //пометили, что в слоте больше ничего нет
                _memoryModules[numberOfSlot] = null;
            }
            //иначе выведем на экран, что слот был пустым ;)
            else
                Console.WriteLine("\nThe slot {0} was already empty", numberOfSlot);
            //эту команду можно не переносить выше, она будет работать даже если null уже был в слоте
            //но все же оптимальнее не записывать туда null еще раз, потому перенесем ее только в кейс
            //когда слот не был пустым ;)
            //_memoryModules[numberOfSlot] = null;
            //ну и в самом конце возвращаем то, что было до этого слоте, не важно, пустышка или нет
            return removedModule;
        }

        public Videocard DeleteVideocard (int numberOfSlot)
        {
            Console.Write("Motherboard.DeleteVideocard(): ");
            if (numberOfSlot < 0 || numberOfSlot >= _videocards.Length)
            {
                Console.WriteLine("Wrong index, because the range is 0...{0}", _videocards.Length - 1);
                return null;
            }
            var removedVideo = _videocards[numberOfSlot];
            if (removedVideo != null)
            {
                Console.WriteLine("\nFrom slot {0} a videocard {1} was removed", numberOfSlot, removedVideo);
                _videocards[numberOfSlot] = null;
            }
            else
                Console.WriteLine("\nThe slot {0} was already empty", numberOfSlot);
            return removedVideo;
        }

        //todo: здесь нужно будет вывести информацию типа, материнка такая-то со столькими-то видеокартами
        //и столькими-то модулями памяти. 
        //Что-то типа такого: Motheboard Asus Pb5Bt with 2 videocard and 16Gb of memory in 4 modules
        //Не очень подробно, но нам будет достаточно но сейчас не об этом
        //но это сделаешь сам, а сейчас хочу обратить внимание еще на пару моментов

        ////метод для списков
        //public override string ToString()
        //{//Motheboard Asus Pb5Bt with 2 videocard and 16Gb of memory in 4 modules
        //    return string.Format("Motheboard {0} {1} with {2} videocard and {3}Gb of memory in {4} modules",
        //        _motherboardCompany, _model, _videocards.Count, VisibleMemory, _memoryModules.Count);
        //}

        //вижу, что тебя смушает метод Count. Действительно это свойство у списков, которое возвращает 
        //сколько всего элементов в списке
        //но есть еще и метод с таким же названием, который вернет, сколько объектов в коллекции соответствует
        //определенному условию. В нашем случае, сколько не пустых объектов
        //напиши аналогично для памяти
        //эти два свойста - это просто количество заполненных слотов, но не сами слоты
        //они нужны только для метода ToString, другим мест их применения пока нет
        public int FilledMemorySlots { get { return _memoryModules.Count(memory => memory != null); } }
        public int FilledVideocardSlots { get { return _videocards.Count(card => card != null); } }

        //метод для массивов
        public override string ToString()
        {
            //Motheboard Asus Pb5Bt with 2 videocard and 16Gb of memory in 4 modules
            //когда речь шла о списке объектов, что количество просто равнялось полю Count
            //в случае массивов Length будет всегда равен размеру массива - количеству зарезервированных слотов
            //потому сделаем еще одно свойство, которое будет подсчитывать только те слоты,
            //которые не пустые
            return string.Format("Motheboard {0} {1} with {2} videocard and {3}Gb of memory in {4} modules (total memory is {5})",
                _motherboardCompany, _model, FilledVideocardSlots, VisibleMemory, FilledMemorySlots, TotalMemory);
        }
    }
}
