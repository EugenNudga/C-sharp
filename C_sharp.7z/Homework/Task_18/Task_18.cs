﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_18
{
    class Task_18
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры целое положительное число.
            //Вывести в строку через пробел по порядку все натуральные числа, не превышающие заданное.
            //Пример ввода      //5
            //Пример вывода     //1 2 3 4 5

            Console.Write("Please enter a positive integer number: ");

            var x = Convert.ToInt16(Console.ReadLine());
            var y = 1;

            while ( y <= x )
            {
                Console.Write("{0} ", y++);
            }

            //2 вариант
            Console.WriteLine();
            for(var i = 1; i <= x; ++i)
                Console.Write("{0} ", i);

            Console.ReadKey();
        }
    }
}
