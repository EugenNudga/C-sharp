﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_49
{
    class Task_49
    {
        static void Main(string[] args)
        {
            while (true)
            {
                //Получить число lines, распечатать первые lines строк треугольника Паскаля.
                //Числа выводить с начала строки через пробел.

                //Если очертить треугольник Паскаля, то получится равнобедренный треугольник.
                //В этом треугольнике на вершине и по бокам стоят единицы.
                //Каждое число равно сумме двух, расположенных над ним чисел.
                //Продолжать треугольник можно бесконечно.
                //Строки треугольника симметричны относительно вертикальной оси.
                //Имеет применение в теории вероятности и обладает занимательными свойствами.
                //© Wikipedia

                //  Пример ввода    //6
                //Пример вывода
                //1
                //1 1
                //1 2 1
                //1 3 3 1
                //1 4 6 4 1
                //1 5 10 10 5 1

                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter amount of rows: ");
                    var amount = Convert.ToInt32(Console.ReadLine());
                    var coef = 1;
                    for (var row = 0; row < amount; row++)
                    {
                        for (var column = 0; column <= row; column++)
                        {
                            if (column == 0 || row == 0)
                                coef = 1;
                            else
                                coef = coef * (row - column + 1) / column;

                            Console.Write("{0,2} ", coef);
                        }
                        Console.WriteLine();
                    }
                    //for (j = 0; j <= i; j++)
                    //{
                    //    if (j == 0 || i == 0)
                    //        coef = 1;
                    //    else
                    //        coef = coef * (i - j + 1) / j;

                    //    printf("%4d", coef);
                    //}
                    //printf("\n");
                }
                else
                    break;
            }
            Console.ReadKey();
        }
    }
}
