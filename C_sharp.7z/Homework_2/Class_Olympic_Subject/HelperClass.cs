﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Olympic_Subject
{
    //пример особого класса, который не связан с какими-то данными
    //их часто называют классами-помощниками (helper class)
    //в них все методы static
    //такие классы имеют смысл для данных которые имеют четкий тип
    //но могут придти из любой части программы
    //можно воспринимать такие классы как небольшую библиотеку, для которой не
    //нужно дополнительных действий. Просто пишем имяКласса.имяМетода
    public class HelperClass
    {
        public static string ListOfStringsToSingleString(List<string> strings)
        {
            var sb = new StringBuilder();
            for (var i = 0; i < strings.Count; ++i)
                sb.Append(string.Format("{0}, ", strings[i]));
            //если попытатьтся написать так, то будет ошибка
            //компилятор увидит, что мы должны вернуть тип string, а пытаемся
            //вернуть объект типа StringBuilder
            //автоматический вызов ToString сделали только для string.Format и
            //Console.Write. Потому он не понимает так
            //return sb;
            //приходиться вызывать ToString явно
            return sb.ToString();
        }

        public static string ArrayOfStringsToSingleString(string[] strings)
        {
            var sb = new StringBuilder();
            for (var i = 0; i < strings.Length; ++i)
                sb.Append(string.Format("{0}, ", strings[i]));
            //если попытатьтся написать так, то будет ошибка
            //компилятор увидит, что мы должны вернуть тип string, а пытаемся
            //вернуть объект типа StringBuilder
            //автоматический вызов ToString сделали только для string.Format и
            //Console.Write. Потому он не понимает так
            //return sb;
            //приходиться вызывать ToString явно
            return sb.ToString();
        }

    }
}
