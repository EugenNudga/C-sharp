﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Olympic_Subject
{
    public class Olympic_Subject
    {
        //Класс OlympicSubject
        //поля:
        //- название дисциплины, желательно из перечисления Subjects
        //- страна занявшая первое место
        //- страна занявшая вторе место
        //- страна занявшая третье место
        //Для стран можно создать еще одно перечисление Country, чтобы было удобнее выбирать
        //Конструктор должен получать 4 параметра, для инициализации всех полей
        //Перегружаем, как обычно, метод ToString

        //создай несколько экземпляров OlympicSubject для разных дисциплин
        //На уроке мы используем этот класс для более сложной задачи - учета
        //результатов Олимпийских игр за любой год

        //смысл этого класса содержать информацию о любой дисциплине, а именно: как она называется, какая страна получила первое место, какая второе и какая третье
        //все, ни больше ни меньше
        //var football = new Olympic_Subject("football", "Germany", "France", "Brazil");
        //например так создавать
        //если через перечисления, то так создавать:
        //var football = new Olympic_Subject(Subjects.Football, Countries.Germany, Countries.France, Countries.Brazil);
        
        private string _firstPlaceCountry;
        private string _secondPlaceCountry;
        private string _thirdPlaceCountry;
        private string _subject;
        //private string[] _countries = new[] { "Ukraine", "Germany", "Zimbabwe", "USA", "Japan", "Galaluna" };
        //private string[] _subjects = new[] { "Math", "English", "Real_Life", "Biology", "Physics" };

        //private Dictionary<Subjects, Countries> _place = new Dictionary<Subjects, Countries>();

        //здесь, если убрать "_", то ругается
        public Olympic_Subject(string subject, string firstPlaceCountry, string secondPlaceCountry, string thirdPlaceCountry)
        {
            _subject = subject;
            _firstPlaceCountry = firstPlaceCountry;
            _secondPlaceCountry = secondPlaceCountry;
            _thirdPlaceCountry = thirdPlaceCountry;
        }

        public override string ToString()
        {
            return string.Format("In {0} we have such results:\n1st place: {1}\n2nd place: {2}\n3rd place: {3}",
                _subject, _firstPlaceCountry, _secondPlaceCountry, _thirdPlaceCountry);
        }
    }
}
