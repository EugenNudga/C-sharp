﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

//система классов комп запчастей - это композиция, она будет встречаться намного чаще наследования
//мы не будем глубоко копать наследование, но базовые понятия пройдем, без которых никуда

//для начала попробуем выполнить задание ничего не зная о наследовании
//создай такие классы:
//Person
//содержит ФИО и адрес
//Student
//содержит ФИО, адресс, название ВУЗа (из перечисления ;)), название группы
//Teacher
//содержит ФИО, адресс проживания, название ВУЗа(перечисление), список групп


namespace Inheritance
{
    class Inheritance
    {
        static void Main(string[] args)
        {

            var vasya = new Student("Vasya Vasya Vasya", "hammerstr. 007", UniName.HAW, "IE");

            //ты создал препода, но ни разу не вызвал метод добавить группу, потому список групп пустой
            var marivanna = new Teacher("Mar Mar Mar", "hammerstr. 000", UniName.HAW);
            marivanna.AddGroup("IE");
            marivanna.AddGroup("Abracadabra");
            marivanna.AddGroup("abracadabra");
            marivanna.AddGroup("AbraCadabra");


            Console.WriteLine("\n Info about student:");
            Console.WriteLine(vasya);


            Console.WriteLine("\n Info about teacher:");
            Console.WriteLine(marivanna);

            Console.ReadKey();
        }
    }
}
