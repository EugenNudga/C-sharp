﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_30
{
    class Task_30
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры целое неотрицательное число.
            //Вывести через пробел степени числа 2 от нулевой до заданной. Использовать цикл.
            //Пример ввода      //3
            //Пример вывода     //1 2 4 8

            Console.Write("Enter a positive integer number: ");
            var num = Convert.ToByte(Console.ReadLine());

            for (var i = 0; i <= num; i++)
            {
                Console.Write("{0} ", Math.Pow(2, i));
            }

            Console.ReadKey();

        }
    }
}
