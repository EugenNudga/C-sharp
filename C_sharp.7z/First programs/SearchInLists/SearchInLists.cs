﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SearchInLists
{
    class SearchInLists
    {
        //который вернет тру, если в списке есть переданное в качестве параметра значение
        //и фолс, если нет
        //сейчас имя метода подчеркнуто, так как он пока не возвращает значений типа bool
        //как только ты закончишь метод - подчеркивание пропадет
        static bool IsValueInList( List<string> data, string value )
        {
            for (var i = 0; i < data.Count; ++i)
            {
                if (data[i] == value)
                    return true;
                //если написать так, то оно сравнит только с первым значением и сразу закончит метод
                //return false должно быть после цикла!
                //else
                //    return false;
            }
            return false;
        }

        static bool IsValueInListIgnoreCase(List<string> data, string value)
        {
            //была ошибка!!!
            //for (var i = 0; i < data.Count - 1; ++i)
            //запомни, если начинаем с 0, то всегда нужно перебирать до Count!
            for (var i = 0; i < data.Count; ++i)
            {
                //метод ToLower приводит к нижнему регистру. Есть метод для приведения к верхнему
                //это значит, что из фразы "Some TeXT" этот метод сделает фразу "some text"
                if (data[i].ToLower() == value.ToLower())
                    return true;
                //если написать так, то оно сравнит только с первым значением и сразу закончит метод
                //return false должно быть после цикла!
                //else
                //    return false;
            }
            return false;
        }

        static void  PrintListOnScreen ( string title, List<string> words)
        {
            
            Console.WriteLine("{0}", title);
            Console.Write("[ ");
            for (var i = 0; i < words.Count-1; ++i)
            {
                Console.Write("{0}, ", words[i]);
            }
            //эти две строки можно заменить одной ;)
            //Console.Write("]");
            //Console.WriteLine();
            //он сначала выводит текст, а потом уже переводит курсор на следующую строку :)
            Console.WriteLine("{0} ]", words.Last());
        }

        static void Main(string[] args)
        {
            //мы рассмотрели, как добавлять в и удалять из списков значение, но списки без поиска были бы неполными
            //для кратенького повторения материала, напиши метод, который получает в качестве параметров текстовую строку и список
            //Выводит в качестве заголовка первый параметр, а затем выводит все значения списка. Назад он ничего не возвращает
            //Пусть элементы списка выводятся в одну строку в виде [ первыйЭлемент, второйЭлемент и тд ]
            //так вызов PrintListOnScreen("My super List", new List<string>() {"first", "second"});
            //выводил на экран:
            //My super List
            //[ first, second, ]

            string word = "blah-blah";
            var words = new List<string> { "bmw", "wow", "god"};

            PrintListOnScreen(word, words);
            //нужно учитывать, что сравнение идет с учетом регистра
            //если нужно без учета, то это легко сделать в самописном методе
            var stringToSearch = "God";
            var wasWowFound = IsValueInListIgnoreCase(words, stringToSearch);
            Console.WriteLine("The word <{0}> was {1}found in the list.", stringToSearch, wasWowFound ? "" : "not ");
            //для библиотечного метода можно добавить параметр, который позволит сравнить без учета регистра
            //но пока мы к нему не готовы :)
            //пока запомни, что руками можно легко делать много чего даже новичку
            //бибилотечные методы умеют делать даже больше, но нужно знать больше по языку для этого
            //всему свое время
            wasWowFound = words.Contains(stringToSearch);//этот метод делает тоже самое, что наш самописный
            Console.WriteLine("The word <{0}> was {1}found in the list.", stringToSearch, wasWowFound ? "" : "not ");

            //можно было так:
            PrintListOnScreen("blah-blah2", new List<string> { "bmw", "wow", "god"});

            //потренировались выводить, чтобы проще было смотреть на правильность поиска
            //для начала поиск можно написать самостоятельно
            //создай метод, который вернет тру, если в списке есть переданное в качестве параметра значение 
            //и фолс, если нет
            var list2 = new List<string> { "bmw", "wow", "god" };
            PrintListOnScreen("list2", list2);
            var wasOmgFound = IsValueInList( list2, "omg");
            Console.WriteLine("The word {0} was {1} in the list.", "omg", wasOmgFound ? "found" : "not found");

            Console.ReadKey();
        }
    }
}
