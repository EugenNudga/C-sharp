﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal_World
{
                                //яйцами, живородящие, опылением, споры, делением и тп)
    public enum TypeOfReproduction { egg, viviparous, pollination, spores, dividing}

    public class Animals
    {
        //делаем систему классов для иммитации животного мира
        //каждое животное содержит: название, возраст, вес, тип размножения
        //(создай энемку: яйцами, живородящие, опылением, споры, делением и тп), умеют ли плавать, умеют ли летать, хищник ли

        protected string _name;
        protected int _age;
        protected int _weight;
        protected TypeOfReproduction _typeOfReproduction;
        protected bool _canSwim;
        protected bool _canFly;
        protected bool _isPredator;

        public Animals(string name, int age, int weight, TypeOfReproduction typeOfReproduction, bool canSwim, bool canFly, bool isPredator)
        {
            _name = name;
            _age = age;
            _weight = weight;
            _typeOfReproduction = typeOfReproduction;
            _canSwim = canSwim;
            _canFly = canFly;
            _isPredator = isPredator;
        }

        public override string ToString()
        {
            return string.Format("\nName: {0}\nAge: {1}\nWeight {2}",
                _name, _age, _weight);
        }

        public string Name
        {
            get { return _name; }
        }
    }
}
