﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_33
{
    class Task_33
    {
        //если нужно переменную использовать в нескольких методах
        //то можно:
        //a) сделать ее переменной класса и она станет доступной во всех методах класса
        //b) передавать ее как параметр в каждый метод
        //мы выбрали первый вариант, чтобы увидеть еще одну особенность
        //когда создается локальная переменная, то в качестве ее типа допускается и даже рекомендуется!
        //использовать ключевое слово var =>      var numNames = new string[] { "st", "nd", "rd", "th", "th" };
        //а вот когда эта переменная - поле класса (описана за пределами методов), 
        //то приходится писать тип явно =>     static string[] numNames = new string[] { "st", "nd", "rd", "th", "th" };
        static string[] numNames = new string[] { "st", "nd", "rd", "th", "th" };
        static void Main(string[] args)
        {
            //Считать с клавиатуры целое положительное число -количество чисел в последовательности.
            //«атем считать с клавиатуры заданное количество чисел и вывести наименьшее из них.
            //данна¤ задача решаетс¤ без массивов.
            //пример ввода
            //5
            //1 2 3 4 5
            //пример вывода     //1

            //перенес вначало, чтобы не нужно было ничего вводить из самой задачи и быстрее проверить
            var intA = new[] { 1, 2 };
            var strA = new[] { "1" };//массив может быть из одного элемента
            //var boolA = new bool[] {  };//и даже пустым, это же можно записать и так var boolA = new bool[0];
            //здесь же new bool[] можно упростить до new [], так как в скобках есть значения , по которым 
            //компилятор сам определит тип
            var boolA = new [] { true, true, false }; 
            var minLength = GetMinArrayLength(intA, strA, boolA);
            Console.WriteLine("Min length is {0}", minLength);

            while (true)
            {
                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter a positive integer number (amount of numbers for output): ");  //
                    //мы сейчас проведем рефакторинг твоей программы ;)
                    //первое что сделаем это изменим имена переменных и научимся в будущем давать их правильно
                    //имя num0, num1 и тд никуда не годиться - они совсем не отражают, что там хранится
                    //переименовать переменную просто - нажать правую кнопку мыши на ней и выбрать Refactoring/Rename
                    var amount = Convert.ToByte(Console.ReadLine());

                    Console.WriteLine("Enter {0} integer numbers: ", amount);  //

                    //так как сказали без массивов, то массив удалил
                    //раньше было два цикла, так как в первом заполняли массив, а во втором искали
                    //так как заполнять массив больше нельзя, то в этом цикле мы будем и вводить числа и 
                    //искать наименьшее
                    //здесь используем Int32.MaxValue так как нету возможности узнать самое первое введенное число
                    //точнее можно отдельно ввести его до цикла, но это будет больше кода
                    //рассмотрим этот вариант чуть позднее
                    var min = Int32.MaxValue;
                    for (int i = 0; i < amount; i++)
                    {
                        //здесь не меняем, так как numNames.Length - это количество текстовых приставок
                        //а не к-во чисел, которые нужно обработать
                        if (i < numNames.Length)
                            Console.Write("Enter {0}{2} from {1} integer numbers: ", i + 1, amount, numNames[i]);
                        else
                            Console.Write("Enter {0}th from {1} integer numbers: ", i + 1, amount);
                        var number = Convert.ToInt32(Console.ReadLine());
                        if (number < min)
                            min = number;
                    }
                    Console.Write("\n{0} ", min);
                    Console.WriteLine();

                    //второй вариант сделаем в методе, чтобы потренироваться создавать функции/методы и
                    //кроме того, что-бы можно было использовать имена тех же переменных ;)
                    //в языке паскаль разница между методами и функциями четко выражена, там для каждого типа
                    //используют даже специальные ключевые слова procedure/function
                    //я Си подобных языках эта грань стерлась
                    //по факту, функция - это метод, который возвращает значение
                    //а метод - это именованный кусок кода
                    //но в современных языках позволяется игнорировать результат возвращаемый функцией
                    //и тогда они используются как методы :)
                    //в данном конкретном случае, мы не получаем результат от example2 - так что 
                    //правильно называть его методом, но называть можно и функцией
                    //все, что имеет тип void - это чистый метод
                    //все остальное - функции
                    Example2(amount);
                }
                else
                    break;
            }

            Console.ReadKey();

        }

        //есть такое не правильно, а договоренность чтоли, называется code style
        //в каждом языке они разные и даже бывает, что в каждой компании они разные, 
        //но общие принципы сохраняются
        //так вот, в языке C# правилом хорошего тона считается:
        //называть переменные с маленькой буквы
        //называть методы и классы с большой буквы! (они будут работать и с маленькой, как мы увидели), но так рекомендуют
        //кроме этого, имена давать такие, чтобы было ясно, к чему это имя и если нужно несколько слов
        //то писать эти слова в camel style - каждое последующее слово начинать с большой буквы
        //в языке Си# не принято использовать символ _ без большой нужды
        //например: переменная playerName, damageFromEnemy или методы AttachEngine, CalculateMinWeight
        static void Example2(int amount)
        {
            //здесь тоже не лишним будет ввести подсказку пользователю, что за код выполняется
            //сам себе спасибо скажешь в будущем
            Console.WriteLine("Второй вариант: ");
            Console.Write("Enter 1st from {0} integer numbers: ", amount);
            //здесь говорим, что первое число вначале минимальное
            var min = Convert.ToInt32(Console.ReadLine());

            //здесь цикл не с 0, а с 1, так как первое число уже ввели выше
            for (int i = 1; i < amount; i++)
            {
                //здесь не меняем, так как numNames.Length - это количество текстовых приставок
                //а не к-во чисел, которые нужно обработать
                if (i < numNames.Length)
                    Console.Write("Enter {0}{2} from {1} integer numbers: ", i + 1, amount, numNames[i]);
                else
                    Console.Write("Enter {0}th from {1} integer numbers: ", i + 1, amount);
                var number = Convert.ToInt32(Console.ReadLine());
                if (number < min)
                    min = number;
            }
            //учись всегда, когда выводишь ответ писать, что же ты выводишь
            Console.Write("\nMin value is {0} ", min);
            Console.WriteLine();
        }

        //последнее, что хотел показать, как передавать в методы массивы и тому подобные объекты
        static int GetMinArrayLength(int[] someArray, string[] anotherArray, bool[] oneMoreArray)
        {
            if (someArray.Length <= anotherArray.Length && someArray.Length <= oneMoreArray.Length)
                return someArray.Length;
            return anotherArray.Length <= oneMoreArray.Length ? anotherArray.Length : oneMoreArray.Length;
        }
    }
}
