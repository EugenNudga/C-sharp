﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_class
{
    //- создать список из нескольких видеокарт
    //- посчитать количество видеокарт только под слот AGP
    //- подсчитать количество видеокарт под все разновидности PCI-E
    //- получить список только видеокарт NVidia и вывести их на экран
    //- сказать, есть ли среди общего списка видеокарт хоть одна ATI
    //- все ли видеокарты в списке имеют объем видеопамяти больше 1Gb
    //- вывести информацию о первой видеокарте, которая имеет разрядность
    //  шины больше 256бит(это задание с небольшим подвохом ;))
    public enum VideocardCompany { Nvidia, Radeon, ATI };
    //BitCapacity = разрядность
    //так как мы в коде проверяем разрядность знаком >, то тогда здесь нужно гарантировать
    //что у каждого элемента перечисления либо порядок соответствует возрастанию, либо явно присвоим разрядность как 
    //число каждому значению, что даже удобнее
    public enum BitCapacity { _64bit = 64, _128bit = 128, _192bit = 192, _256bit = 256, _384bit = 384};
    //public enum BitCapacity { bit64, bit128, bit192, bit256, bit384 };
    public enum VideocardSocketType { AGP, PCI_E, PCI_E_2, PCI_E_3 };

    public class Videocard
    {
        //класс Видеокарта:
        //производитель(из перечисления: NVidia, Radeon), модель,
        //сколько памяти, разрядность шины
        //(из перечисления: 64бит, 128бит, 192бит, 256бит или 384бит).
        //Внимание значения перечисления не могут начинаться с цифры,
        //потому можешь использовать что-то типа _64bit или bit64
        private VideocardCompany _videocardCompany;
        private VideocardSocketType _videocardSocket;
        private BitCapacity _bitCapacity;
        private string _model;
        private int _memory;


        public Videocard(VideocardCompany videocardCompany, string model, VideocardSocketType videocardSocket,
            BitCapacity bitCapacity, int memory)
        {
            _videocardCompany = videocardCompany;
            _videocardSocket = videocardSocket;
            _bitCapacity = bitCapacity;
            _model = model;
            _memory = memory;
            Console.WriteLine("Videocard.Constructor(): {0} created", ToString());
        }

        public VideocardSocketType VideocardSocket
        {
            get { return _videocardSocket; }
        }

        public VideocardCompany VideocardCompany
        {
            get { return _videocardCompany; }
        }

        public string VideocardModel
        {
            get { return _model; }
        }

        public int VideocardVolume
        {
            get { return _memory; }
        }

        public BitCapacity BitCapacity
        {
            get { return _bitCapacity; }
        }

        //завершишь метод позднее сам
        //вообще такие методы лучше всего должны коротко возвращать информацию об объекте
        //например здесь я бы вывел что-то типа NVidia GTX 1060| 256bit| 6Gb
        public override string ToString()
        {
            return string.Format("Module {0} {1} | {2} socket | {3} | {4}Gb ", _videocardCompany, _model,
                _videocardSocket, _bitCapacity, _memory);
        }
    }
}
