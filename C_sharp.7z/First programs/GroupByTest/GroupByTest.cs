﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GroupByTest
{
    //можно конечно и не создавать отдельный файл, но обычно для каждого класса создают свой файл
    //class Phone
    //{
    //здесь после имени переменной стоит { get; set; } - это признак автосвойства, 
    //которых мы еще не рассматривали, для тебя не будет никакой разницы, если его вообще убрать
    //    public string Name { get; set; }
    //    public string Company { get; set; }
    //}

    class GroupByTest
    {
        static void Main(string[] args)
        {
            //не очень понятно, зачем маленький кусок кода выводить аж в отдельный класс Phone
            List<Phone> phones = new List<Phone>
            {
                //{Name="Lumia 430", Company="Microsoft" } - это автоконструктор, когда
                //его можно явно не объявлять, но указать в такой компактной форме какому полю
                //что присвоить. Для чего-то побыстрому наляпать такой подход работает, но для
                //больших классов я считаю наличие конструктора обязательно
                //запись через конструктор и короче и безопаснее, но разработчик класса
                //уменьшил себе работу, увеличив ее тому, кто использует класс
                new Phone("Lumia 430", "Microsoft" ),
                new Phone("Mi 5", "Xiaomi" ),
                new Phone("LG G 3", "LG" ),
                new Phone("iPhone 5", "Apple" ),
                new Phone("Lumia 930", "Microsoft" ),
                new Phone( "Lumia 630", "Microsoft" ),
                //для этой задачи способ создание объектов не важен
                //но на будущее запомни. Лучше чуть больше потратить времени на создание класса
                //если потом это съэкономит кучу времени его пользователям
                //new Phone {Name="Lumia 430", Company="Microsoft" },
                //new Phone {Name="Mi 5", Company="Xiaomi" },
                //new Phone {Name="LG G 3", Company="LG" },
                //new Phone {Name="iPhone 5", Company="Apple" },
                //new Phone {Name="Lumia 930", Company="Microsoft" },
                //new Phone {Name="iPhone 6", Company="Apple" },
                //new Phone {Name="Lumia 630", Company="Microsoft" },
                //new Phone {Name="LG G 4", Company="LG" }
            };

            //phone - это просто созданная здесь переменная?
            //типа как в foreach(var str in strings) есть созданная переменная str?
            //в C# есть два способа использовать методы над коллекциями, в виде языка похожего
            //на SQL - LINQ
            //var phoneGroups = from phone in phones
            //                  group phone by phone.Company;

            //при чем линкус нужен далеко не каждому программисту
            //мне вот совсем нмного нужен был в прошлой компании, но это раз за 15 лет 
            //либо через метод, как я показывал раньше. Тебе второй способ должен быть ближе
            //так как мы ранее ничего подобного LINQ в коде не использовали
            //но в будущем сможешь выбрать сам, что тебе удобнее
            //можно ещё так (наверное так лучше? меньше набирать)
            //С++/Java style
            //var phoneGroups = phones.GroupBy(p => p.GetCompany());
            //c# style
            var phoneGroups = phones.GroupBy(p => p.Company);

            //в IGrouping<string, Phone> параметр string указывает на тип ключа,
            //а параметр Phone - на тип сгруппированных объектов
            foreach (IGrouping<string, Phone> g in phoneGroups)
            {
                Console.WriteLine(g.Key);//в качестве ключа используется название компании
                foreach (var t in g)
                    //Console.WriteLine(t.GetName());
                    Console.WriteLine(t.Name);
                Console.WriteLine();
            }

            Console.WriteLine("Second way, showing the number of models per company:\n");
            //var phoneGroups2 = from phone in phones
            //                   group phone by phone.Company into g
            //                   select new { Name = g.Key, Count = g.Count() };

            //или так (хотя в этот раз уже сильно непривычно)
            var phoneGroups2 = phones.GroupBy(p => p.Company).Select(g => new { CompanyName = g.Key, Count = g.Count() });

            foreach (var group in phoneGroups2)
                //смущает Name, может стоило на Company_Name переимновать?
                Console.WriteLine("{0} : {1}", group.CompanyName, group.Count);

            Console.WriteLine();

            Console.WriteLine("Third way, осуществление вложенных запросов:\n");
            var phoneGroups3 = from phone in phones
                               group phone by phone.GetCompany() into g
                               //здесь показано, как можно создать объект анонимного класса
                               //даже явно не создавая класс с каким-то именем
                               //пока не анализируем глубоко, потом посмотрим
                               select new
                               {
                                   CompanyName = g.Key,
                                   Count = g.Count(),
                                   Phones = from p in g select p
                               };
            foreach (var group in phoneGroups3)
            {
                Console.WriteLine("{0} : {1}", group.CompanyName, group.Count);
                foreach (Phone phone in group.Phones)
                    Console.WriteLine(phone.GetName());
                Console.WriteLine();
            }

            Console.ReadKey();
        }
    }
}
