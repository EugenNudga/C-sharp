﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Homework_Search_In_List
{
    class Homework_Search_In_List
    {
        //попокажу 2 момента
        //первый, как сделать из этих двух методов 1
        //второй - покажу как написать метод, который вернет все индексы, а не только первый с начала
        //здесь результат работы метода не простое значение, а список - список всех позиций,
        //где будет найдено значение word. Говорят: "метод возвращает список значений"
        static List<int> GetValueAllPositions(List<string> test, string word, bool ignoreCase = false)
        {
            //вначале создадим пустой список, куда будем добавлять значения по мере их обнаружения
            //напиши сам код создания нового списка с привоением его переменной indices
            var indices = new List<int>();
            if (ignoreCase)
            {
                for (int i = 0; i < test.Count; ++i)
                {
                    if (test[i].ToLower() == word.ToLower())
                        //здесь не заканчиваем метод, а добавляем каждый найденный индекс в список
                        indices.Add(i);
                }
                return indices;
            }
            //оператор else в этом случае избыточен, так как код в блоке выше обязательно заканчивается return
            //else
            for (int i = 0; i < test.Count; ++i)
            {
                if (test[i] == word)
                    indices.Add(i);
            }
            //var indices2 = new List<int>();
            ////такая операция не проверяет есть ли в списке indices точно такие же элементы,
            ////что и в списке indices. Она всегда вернет false. Так как адрес памяти у indices2 отличается
            ////от адреса памяти indices, так как это два разных списка.
            ////для полноценного сравнения списков нужно писать цикл, который сравнит списки поэлементно
            //var isEqual = (indices == indices2); 
            //var isEqual = indices == indices2; //в таком простом выражении скобки не мешают, но и не нужны
            //по-этому на этом мы глубже generic методы не затрагиваем, всему свое время
            return indices;
        }

        //параметр bool ignoreCase = false говорит, что если не передать его, то будет обычный поиск
        //которому принципиален регистр. Если же передать в него true, то будет поиск без учета регистра
        //сам код будет объединением двух твоих методов
        static int GetValueIndex(List<string> test, string word, bool ignoreCase = false)
        {
            if (ignoreCase)
            {
                for (int i = 0; i < test.Count; ++i)
                {
                    if (test[i].ToLower() == word.ToLower())
                        return i;
                }
                return -1;
            }
            //оператор else в этом случае избыточен, так как код в блоке выше обязательно заканчивается return
            //else
            for (int i = 0; i < test.Count; ++i)
            {
                if (test[i] == word)
                    return i;
            }
            return -1;
        }

        //static int GetValueIndexIgnoreCase(List<string> test, string word)
        //{
        //    for (int i = 0; i < test.Count; ++i)
        //    {
        //        if (test[i].ToLower() == word.ToLower())
        //            return i;
        //    }
        //    return -1;
        //}

        //нужно написать такой же метод как PrintListOnScreen, но который получает параметром не List<string>,
        //а List<int>. Хоть они будут абсолютно одинаковыми с точки зрения кода, для языка C#
        //тип List<T> не совместим с другими List. В скобках обязательно должен стоять такой же тип!

        //но, чтобы не делать много разных методов, которые почти не отличаются по коду, а отличаются только
        //типов параметра, проще сделать один generic метод
        //изменения сводятся к тому, что:
        // - после имени метода добавляется <любоеСловоКакТип>
        //везде где был изменяемый тип подставить это любоеСловоКакТип. Обычно в качестве любоеСловоКакТип
        //используют T
        //прелесть generic методов в том, что компилятор сам понимает, какой тип подставить
        //На основании типа параметра, передаваемого в метод
        //На самом деле не всегда так просто переделать не generic метод в generic версию
        //мы просто постепенно подходим к этой теме
        //главная сложность этой операции в том, что в качестве T компилятор позволит подставить абсолютно
        //любой тип. Но есть действия, которые можно делать над числами, но нельзя делать над пользовательскими
        //классами. Так числа можно делить и вычитать, но делить нельзя строки и вычитать тоже нельзя.
        //var s1 = "Vova";
        //var s2 = "Eva";
        //var s3 = s1 - s2;
        //var s4 = s1 / s4;
        //кроме того есть проблема даже со сравнением значений. Так числовые значени понятно как сравнить
        //но объекты классов сравниваются по умолчанию только по адресу. И можно их сравнить только на то
        //в одной ячейке памяти они находятся или нет, что не одно и тоже, что сравнить объект на значения
        //полей. Так что до generic классов и методов мы как-нить дойдем,
        //сейчас просто робкая попытка о них заговорить :)

        static void PrintListOnScreen<T>(string title, List<T> test)
        {
            Console.WriteLine("List of {0}:", title);
            Console.Write("[ ");
            for (var i = 0; i < test.Count - 1; ++i)
            {
                Console.Write("{0}, ", test[i]);
            }
            Console.WriteLine("{0} ]", test.Last());
        }

        //static void PrintListOnScreen(string title, List<string> test)
        //{
        //    Console.WriteLine("List of {0}:", title);
        //    Console.Write("[ ");
        //    for (var i = 0; i < test.Count - 1; ++i)
        //    {
        //        Console.Write("{0}, ", test[i]);
        //    }
        //    Console.WriteLine("{0} ]", test.Last());
        //}

        ////я предлагаю оставить имя метода таким же, так как он может вывести любой список чисел
        //static void PrintListOnScreen(string title, List<int> test)
        //{
        //    Console.WriteLine("List of {0}:", title);
        //    Console.Write("[ ");
        //    for (var i = 0; i < test.Count - 1; ++i)
        //    {
        //        Console.Write("{0}, ", test[i]);
        //    }
        //    Console.WriteLine("{0} ]", test.Last());
        //}

        static void Main(string[] args)
        {
            //домашнее задание:
            //написать методы, похожие на методы поиска факта наличия, которые мы с тобой написали
            //но пусть возвращают -1, если элемент не найден
            //или индекс элемента, который нашли
            //первый метод без учета регистра
            //второй с учетом

            //но для определения факта начилия элемента в списке достаточно было использовать метод
            //из прошлого урока. Этот же метод позволяет как установить факт наличия (index != -1)
            //так и понять, в какой позиции был найден элемент
            //давай перепишем код, вызывающий твои методы так, чтобы он говорил позицию, 
            //в которой был найден элемент или писал "элемент не найден" в противном случае

            var test = new List<string>() { "shift", "lever", "lever", "crank", "arm", "April", "fool", "banana", "bAnana", "bananA" };

            PrintListOnScreen( "words", test);

            Console.WriteLine("Enter a word you wanna find in the list: ");
            var word = Convert.ToString(Console.ReadLine());

            //здесь передавать false третьим параметром не обязательно, так как он имеет значение по умолчанию
            var wordIndex = GetValueIndex(test, word);
            var wordIndexLibrary = test.IndexOf(word);//это библиотечный метод, который делает тоже самое
            //правда он ищет с учетом регистра. Для того, чтобы он умел искать игнорируя регистр нужно 
            //немножко подучить теорию, но в большинстве случаев обычного IndexOf достаточно
            //Получается, что метод IndexOf более универсальный чем Contains , он позволяет 
            //установить и факт удачности поиска (сравнение с -1) и получить позицию.
            //Но мы запомним Contains, так как есть много других коллекций, где есть только Contains
            //еще раз, метод Contains возвращает либо true, если значение найдено, либо false - когда нет
            //если нужно найти все позиции элементов, которые соответствуют некоему условию,
            //то пока мы не изучим лямбды, такие задачи нужно делать самостоятельно

            Console.WriteLine("The word {0} was {1} in the list.", word, 
                wordIndex != -1 ? "found" : "not found");

            PrintListOnScreen("words", test);

            Console.WriteLine("Enter a word you wanna find in the list: ");
            word = Convert.ToString(Console.ReadLine());

            wordIndex = GetValueIndex(test, word, true);
            //в этом случае тернарный оператор не очень подходит, переделай на if
            if(wordIndex != -1)
            {
                Console.WriteLine("The word {0} was {1} in the list under index {2}."
                    , word, "found", wordIndex);
            }
            else
                Console.WriteLine("The word {0} was not in the list.", word);

            var bananaIndices = GetValueAllPositions(test, "banana");
            var bananaIndices2 = GetValueAllPositions(test, "banana", true);

            PrintListOnScreen("indices", bananaIndices);
            PrintListOnScreen("indices2", bananaIndices2);

            Console.ReadKey();
        }
    }
}
