﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_53
{
    class Task_53
    {
        static uint Result(uint sum, uint amount)
        {
            return sum/amount;
        }

        static void Main(string[] args)
        {
            

            while (true)
            {
                //unsigned int average(unsigned int a, unsigned int b)
                //Вернуть среднее арифметическое двух положительных целых чисел.
                //Использовать только тип unsigned int.
                //Если среднее значение не является целым,
                //то округлить его к ближайшему целому в меньшую сторону.

               Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter amount of numbers (except 0): ");
                    uint amount = Convert.ToUInt32(Console.ReadLine());
                    Console.WriteLine("Enter {0} positive integer numbers (no float numbers like 16,5):", amount);
                    //я не заметил, что требовалось только для двух положительных чисел, но можно и так
                    var nums = new uint[amount];
                    uint sum = 0;
                    for (var i = 0; i < amount; ++i)
                    {
                        Console.Write("Enter {0} out of {1} number: ", i + 1, amount);
                        nums[i] = Convert.ToUInt32(Console.ReadLine());
                        sum += nums[i];
                    }
                    //Math.Floor - только для decimal, другое дело, что из-за uint получается как с floor
                    Console.Write("The arithmetic mean is {0}", Result(sum, amount)); 
                    Console.WriteLine();
                }
                else
                    break;
            }
            Console.ReadKey();
        }
    }
}
