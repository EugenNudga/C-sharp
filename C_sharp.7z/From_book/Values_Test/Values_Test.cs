﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Values_Test
{
    public class Values_Test
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Assigning reference types\n");
            PointRef p1 = new PointRef(10, 10);
            PointRef p2 = p1;
            // Print both point refs.
            p1.Display();
            p2.Display();
            // Change p1.X and print again.
            p1.X = 100;
            Console.WriteLine("\n=> Changed p1.X\n");
            p1.Display();
            p2.Display();
        }
    }
    //я рекомендую все же под каждый класс выделять отедльный файл - тогда меньше вероятность код, который относится к класу
    //попадал в нужно место
    public class PointRef
    {
        //здесь показан пример того, как я сказал делать очень плохо
        //поля публичные. Приватность полей позволяет сделать так, что изменить их может только класс
        //он для этого либо выделяет сэттэр, либо, что чаще и надежнее один/несколько паблик методов
        //которые изменяют значения с контролем, что оно не станет меньше или больше допустимых значений
        //какой-либо контроль над публичными полями невозможен. Это не дает построить надежный класс, который 
        //работает в любой ситуации
        public int X;
        public int Y;
        // Same members as the Point structure...
        // Be sure to change your constructor name to PointRef!
        public PointRef(int XPos, int YPos)
        {
            X = XPos;
            Y = YPos;
        }
        public void Display()
        {
            Console.WriteLine("X = {0}, Y = {1}", X, Y);
        }
    }
}
