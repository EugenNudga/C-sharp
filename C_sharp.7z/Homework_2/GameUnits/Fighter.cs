﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameUnits
{
    public class Fighter : Flying
    {
        //истребитель, который предназначен для уничтожения только воздушных целей.
        //Как думаешь, от какого класса его наследовать;)?
        //Дополнительно содержит: дальность пуска ракет, урон по бронированным целям,
        //урон по небронированным

        private float _rocketMaxRange;
        private int _damageNonarmored;
        private int _damageArmored;
        //мы сразу присваиваем полю нужное значение. Если это значение 0, то даже это можно не писать
        //private int _frags = 0;
        //это тоже самое, что и строка выше
        private int _frags;
        //пусть будет поле. Если все новые самолеты должны иметь в нем 1, то тоже нет нужды добавлять параметр в конструктор
        //и даже явно присваивать это значение в конструкторе - просто при создании поля присваиваем ему нужно значение
        private int _upgradeLevel = 1;
        //еще пример полей, которые нет нужды передавать в конструктор - это коллекции, которые вначале пустые
        //например, нам нужно хранить название убитых этим юнитов врагов
        //private List<string> _kills;//можно так и потом в конструкторе писать еще одну строку _kills = new List<string>();
        //но лучше в ождну строку и объявить поле и инициализировать его пустым объектом
        //прелесть этого способа проявляется, когда нужно иметь более одного конструктора для класса (их может быть сколько угодно с точки зрения компилятора)
        //тогда в каком-то из конструкторов можно забыть создать поле. А так, мы его сразу создали в одном месте и во всех конструкторах
        //оно 100% будет готово к использованию
        //более того, если забыть коллекции создать объект, то в переменной будет значение null и любая попытка добавить такой коллекции что-то или узнать размер,
        //например, приведет к падению программы
        private List<string> _kills = new List<string>();
        //private List<string> _kills;

        //конструктор ДОЛЖЕН быть полным, так как ему нужно присвоить все, что может хранить объект
        //но могут быть поля (и чаще всего в реальных проектах они будут), которые передаются не в конструкторе, а которые в нем создаются пустыми
        //или заполняются каким-то стандартными значениями, которые нет нужды каждый раз передавать одни и те же
        //сейчас придумаю, что-то подобное для самолета
        //ну например, у самолета может хранится счетчик сбитых врагов
        //когда мы создаем объект, он у него конечно же пустой. Зачем требовать от игрока передавать то, что всегда равно 0, мы можем это присвоить 
        //в конструкторе сами
        public Fighter(string name, float health, float maxSpeed, float maxHeight,
            float upSpeed, int crewSize, float rocketMaxRange, int damageNonarmored, int damageArmored) :
            base(name, health, maxSpeed, maxHeight, upSpeed, crewSize)
        {
            _rocketMaxRange = rocketMaxRange;
            _damageNonarmored = damageNonarmored;
            _damageArmored = damageArmored;
            //более того, если можно присвоить полю какое-то значение, то его можно присвоить даже до вызова конструктора
            //смотри создание поля private int _frags = 0;
            //_frags = 0;
            //_kills = new List<string>();
            Console.WriteLine("Constructor for {0}", _name);
            //сейчас будет ошибка, так как мы "забыли" инициализировать коллекцию
            Console.WriteLine("There are {0} object in the kills list", _kills.Count);
        }

        public override string ToString()
        {
            //все, для самолетов нам больше ничего не нужно - значит больше ничего и не выводим
            return string.Format("fighter {0}", _name);
            //return string.Format("Name: {0}\nHealth: {1}\nMaxSpeed: {2}\nMax height: {3}\nUp speed: {4}\nCrew size: {5}\nRocket max range: {6}\nDamage on non-armored enemies: {7}\nDamage on armored enemies: {8}", 
            //    _name, _health, _maxSpeed, _maxHeight, _upSpeed, _crewSize, _rocketMaxRange, _damageNonarmored, _damageArmored);
        }
    }
}
