﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_10
{
    class Task_10
    {
        static void Main(string[] args)
        {
            //-Если первое число не больше второго, вывести alpha
            //-Если первое число меньше нуля, вывести bravo
            //- Если второе число равно нулю, вывести charlie
            //- Если не сработало ничего из вышеуказанного, вывести zulu

            Console.Write("Enter first integer number: ");
            var num0 = Convert.ToInt16(Console.ReadLine());
            Console.Write("Enter second integer number: ");
            var num1 = Convert.ToInt16(Console.ReadLine());

            //эту задачу можно решить по разному
            //первый вариант, мы считаем, что возможен только один ответ, тогда все решается очень просто через if ... else if
            //второй вариант - возможно более одного ответа!, тогда немного сложнее получить zulu

            //первый вариант
            Console.WriteLine("Первый вариант:");
            if (num0 < num1)
            {
                Console.WriteLine("alpha");
            }
            else if(num0 < 0)
            {
                Console.WriteLine("bravo");
            }
            else if(num1 == 0)
            {
                Console.WriteLine("charlie");
            }
            else
            {
                Console.WriteLine("zulu");
            }

            Console.WriteLine("Второй вариант:");
            //здесь нужно писать без else if
            //и придумать как правильно записать условие для получения zulu
            if (num0 < num1)
            {
                Console.WriteLine("alpha");
            }
            if (num0 < 0)
            {
                Console.WriteLine("bravo");
            }
            if (num1 == 0)
            {
                Console.WriteLine("charlie");
            }

            if (num0 >= num1 && num0 >= 0 && num1 != 0)
            {
                Console.WriteLine("zulu");
            }

            Console.ReadKey();
        }
    }
}
