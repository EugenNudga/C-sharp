﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Optional_Parameters
{
    class Optional_Parameters
    {
        static void Main(string[] args)
        {
            Console.WriteLine("***** Fun with Methods *****");
            //смотри, здесь нет второго параметра (Programmer), он там в методе
            EnterLogData("Oh no! Grid can't find data");
            //а здесь второй параметр есть и он имеет преимущество над Programmer
            EnterLogData("Oh no! I can't find the payroll data", "CFO");
            EnterLogData("Some message for another date", new DateTime(1998, 12, 1, 12, 5, 9), "Max");
            //так тоже конечно же можно 
            EnterLogData("Some message for another date", new DateTime(1998, 12, 1));
            Console.ReadLine();
        }

        //DateTime.Now - это значение которое постоянно меняется - возвращает текущее время и дату
        //оно организовано так, что известно только когда будет запущена программа
        //а компилятор требует, чтобы все значения по умолчанию были известны до старта программы
        //именно потому его нельзя использовать как значение для параметра по умолчанию
        //static void EnterLogData(string message, string owner = "Programmer", DateTime timeStamp = DateTime.Now)
        //поэтому параметр timeStamp сделаем обычной переменной
        static void EnterLogData(string message, string owner = "Programmer")
        {
            //чтобы не дублировать код, мы просто вызовем более общий метод, куда передадим текущую дату
            EnterLogData(message, DateTime.Now, owner);
        }

        //если же понадобиться иногда возможность выводить не только текущее время, но и какое-то другое
        //то для этого типа нужно создать еще один метод, где параметр timeStamp не будет иметь значения по умолчанию
        //такой метод более общий, чем тот, который выше, потому верхний можно (нужно!) переписать так
        static void EnterLogData(string message, DateTime timeStamp, string owner = "Programmer")
        {
            Console.Beep();
            Console.WriteLine("Error: {0}", message);
            Console.WriteLine("Owner of Error: {0}", owner);
            Console.WriteLine("Time of Error: {0}", timeStamp);

        }
    }
}
