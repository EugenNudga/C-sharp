﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameUnits
{
    public class Unit
    {
        //общая информация о любой игровой единице: название, количество здоровья,
        //максимальная скорость, может ли летать, может ли плавать, может ли передвигаться по земле

        //все поля, которые потом собираешься использовать в классах наследниках следует делать protected!
        //исправляй
        protected string _name;
        protected float _health; //current health
        protected float _maxHealth;
        protected float _maxSpeed;
        protected bool _canFly;
        protected bool _canSwim;
        protected bool _canMoveOnGround;
        

        public Unit(string name, float health, float maxSpeed, bool canFly, bool canSwim, bool canMoveOnGround)
        {
            Console.WriteLine("Unit.Constructor for object {0}", name);
            _name = name;
            _health = health;
            _maxSpeed = maxSpeed;
            _canFly = canFly;
            _canSwim = canSwim;
            _canMoveOnGround = canMoveOnGround;
        }

        public void ApplyDamage(float damage)
        {
            _health -= damage;
            if (_health < 0)
                _health = 0;
        }

        //гэттэр может прочитать любое поле класса точно так же как и метод ToString у тебя читал любое поле
        //точно так же как ты создаешь гэттэр под любое поле
        //какое ты даешь название гэттеру никто не контролирует, компилятору все равно, он может совершенно не совпадать с тем,
        //что находится внутри

        //задание было:
        //- создай в классе Unit гэттэр IsAlive, который возвращает true, если количество жизни > 0
        public bool isAlive
        {
            //здесь ошибка потому, что ты написал, что вернуть, если health > 0, но не написал, что вернуть , если health <= 0
            //get { if (_health > 0) return true; } //так ошибка
            //у каждого метода, которым являются и гэттэры, если указываешь тип возвращаемого результата, ты обязан написать код возврата значения
            //для всех ситуаций
            //так можно написать, но опытные так никогда не пишут :). Дело в том, что _health > 0 уже само по себе явялется либо true либо false
            //get { if (_health > 0) return true; else return false; }
            //потому код выше упрощается до такого ;). Здесь не нужно писать if!
            //когда я писал задание, то я представлял себе сразу ответ и именно потому написал только о true, что false получается автоматически :)
            get { return _health > 0; }
        }

        public float MaxHealth
        {
            get { return _maxHealth; }
        }

        public string Name
        {
            get { return _name; }
        }

        public float Health
        {
            get { return _health; }
        }

        public float MaxSpeed
        {
            get { return _maxSpeed; }
        }

        public bool CanFly
        {
            get { return _canFly; }
        }

        public bool CanSwim
        {
            get { return _canSwim; }
        }

        public bool CanMoveOnGround
        {
            get { return _canMoveOnGround; }
        }

        //public override string ToString()
        //{
        //    return string.Format("Name: {0}\nHealth: {1}\nMaxSpeed: {2}, ", );
        //}
    }
}
