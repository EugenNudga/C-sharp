﻿using System;
//это namespace, который находится в namespace Collection, который в свою очередь находится в namespace System
//можно делать вложени namespace ("простраства имен" в переводе) до потери пульса, но на маленьких проектах 
//создавать самостоятельно их нет большой нужды
//в тоже время, в стандартной библиотеке все разложено по пространствам имен
//Так в System находится наш любимый класс Console, Math и многие другие.
//В System.Collections находятся почти все коллекции, которые были до C# 2.0, но которые потом с легкостью заменил
//System.Collections.Generic - с generic версиями почти все тех же классов
using System.Collections.Generic;
//namespace System.Linq - это по сути язык в языке, который появился в версии 3.0. Он позволяет очень многие операции
//которые раньше нужно было писать в несколько строк, сейчас записывать на подобии SQL выражений и повысить читаемость
//кода. Так же часто сократить его (код).
using System.Linq;
//здесь находятся классы для особой работы со строками. Я из него использовал только StringBuilder. Если он не нужен
//(а используют его только когда нужно составить строку из большого к-ва частей, что бывает не часто), то его подключать 
//не нужно. Сам тип string и большинство методов для обратотки строк находятся в System и будут работать без System.Text
using System.Text;
//это пространство имен используют если нужно многопоточное программирование. Для нас это еще долго будет не актуально
//все, что мы не используем IDE выделяет серым цветом и его можно спокойно удалить
using System.Threading.Tasks;

namespace Numerical_Formats
{
    class Numerical_Formats
    {
        static void Main(string[] args)
        {
            var numbers = new List<int>() { -5, 10, -100, 20 }; //|-5| = 5
            //допустим нам нужно найти самое большое число по модулю
            //естьбиблиотечный метод Max, но он вернет просто самое большое число
            var maxValue = numbers.Max();
            //для нахождения максимально по модулю значения по можно написать такой цикл:
            //если мы всегда присваиваем maxValue2 значение по модулю, по в if не нужно еще раз брать модуль
            int maxValue2 = Math.Abs(numbers[0]);
            
            for(var i = 0; i < numbers.Count; ++i)
            {                
                if(maxValue2 < Math.Abs(numbers[i]))
                {
                    maxValue2 = Math.Abs(numbers[i]);
                }
            }
            //эта одна короткая строка делает тоже самое, что и менее понятный и более длинный цикл выше
            //одну эту строку можно разбить на 2, чтобы немного стало понятнее, как это работает
            //метод Select позволяет получить из коллекции другую, где над каждым элементом произвели какую-то операцию
            //v => Math.Abs(v) - это лямбда выражение, которые всегда тестно сопровождают LINQ. Можно и без них
            //но с ними намного короче и удобнее. Это выражение нужно понимать, как foreach в укороченном виде
            //типа возьми каждое значение коллекии и присвой его переменной v, а потом над каждым значением выполни то
            //что стоит после =>, в данном случае возьми его модуль
            var allAbsValues = numbers.Select(v => Math.Abs(v));
            //ну а эта команда говорит сама за себя
            var maxValue4 = allAbsValues.Max();
            //ну либо тоже самое в одну строку
            var maxValue3 = numbers.Select(v => Math.Abs(v)).Max();
            Console.WriteLine("The biggest value (with module) is {0}. Linq result is {1}", maxValue2, maxValue3);


            Console.WriteLine("The value 99999 in various formats:");
            Console.WriteLine("c format: {0:c}", 99999);  //когда-нить почитаешь о том, как выводить локализированные данные
            Console.WriteLine("hh:mm:ss format: {0:d2}:{1:d2}:{2:d2}", 2, 12, 9); //немного странная штука, пока неясно применение
            Console.WriteLine("f3 format: {0:f3}", 99999);
            Console.WriteLine("n format: {0:n}", 99999);
            // Notice that upper- or lowercasing for hex
            // determines if letters are upper- or lowercase.
            Console.WriteLine("E format: {0:E}", 99999);
            Console.WriteLine("e format: {0:e}", 99999);
            Console.WriteLine("X format: {0:X}", 99999);
            Console.WriteLine("x format: {0:x}", 99999);

            Console.WriteLine("N format: {0:N}", 99999);

            Console.WriteLine();
            // Using string.Format() to format a string literal.
            string userMessage = string.Format("100000 in hex is {0:x}", 100000);
            // You need to reference PresentationFramework.dll
            // in order to compile this line of code (the one belows)!
            //System.Windows.MessageBox.Show(userMessage);  //??????????????

            Console.ReadKey();
        }
    }
}
