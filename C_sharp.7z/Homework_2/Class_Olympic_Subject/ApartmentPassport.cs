﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Olympic_Subject
{
    public class ApartmentPassport
    {
        //содержит поля:
        //номер, этаж, количество комнат, общий метраж, метраж жилой площади

        private int _number;
        //предлагаю сначала оставить это поле, а позднее посмотреть, 
        //как от него избавиться
        private int _amountOfRooms;
        private float _totalArea;
        private float _livingArea;

        private List<RoomDescription> _rooms = new List<RoomDescription>();

        public ApartmentPassport(int number, int amountOfRooms, float totalArea, float livingArea)
        {
            _number = number;
            _amountOfRooms = amountOfRooms;
            _totalArea = totalArea;
            _livingArea = livingArea;
        }

        public int FlatNumber
        {
            get { return _number; }
        }

        public string FlatNumberAsString
        {
            get { return _number.ToString(); }
        }

        //этот метод нужен - мы хотим добавлять комнаты в описание квартиры
        public void AddRoom(RoomDescription room)
        {
            Console.WriteLine("Room \"{0}\" added to apartment {1}\n", room.RoomName, _number);
            _rooms.Add(room);
        }

        public override string ToString()
        {
            //хорошо, но теперь рассказываю еще раз почему так делать плохо
            //способ сложения строк я показал только потому, что времени было мало
            //а хотелось подать тему как законченную
            //для собирания строки из кусочков в цикле нужно использовать StringBuilder
            //это досаточно похоже, но с небольшой разницей
            //нужно создать объект билдера вместо пустой строки
            var sb = new StringBuilder();
            //var roomsInfo = "";
            //заголовок цикла не меняется, но меняется немного его тело
            for (var i = 0; i < _rooms.Count; ++i)
                //вместо того, чтобы прибавлять к строке еще одну
                //мы методом Append добавляем строки в объект StringBuilder
                sb.Append(string.Format("{0}, ", _rooms[i].RoomName));
            //for (var i = 0; i < _rooms.Count; ++i)
            //    roomsInfo += string.Format("{0}, ", _rooms[i].RoomName);
            //return string.Format("Apartment information:\nfloor: {0}\namount of rooms: {1}\ntotal area of apartment: {2}m2\nliving area of apartment: {3}m2\nrooms: {4}",
            //    _number, _rooms.Count, _totalArea,_livingArea, roomsInfo);
            //последняя строка тоже слабо отличается. Если нам просто нужно вывести
            //текст на экран, то можно написать sb, а если то, что нужно получилось
            //в sb, получить как текст, то sb.ToString(). 
            //Просто когда подставляем sb в string.Format или Console.Write
            //ToString вызывается автоматически
            return string.Format("Apartment information:\nfloor: {0}\namount of rooms: {1}\ntotal area of apartment: {2}m2\nliving area of apartment: {3}m2\nrooms: {4}",
                _number, _rooms.Count, _totalArea, _livingArea, sb);
                //строка выше более короткая запись того же самого
                //_number, _rooms.Count, _totalArea, _livingArea, sb.ToString());
        }

    }
}
