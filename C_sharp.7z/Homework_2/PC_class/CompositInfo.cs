﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_class
{
    //мы специально создали класс, который будет хранить только часть нужной нам информации
    //это может быть даже информация из разных классов - не важно, главное, что она вся в одном классе, он имеет
    //конструктор на инифиализацию всей этой информации и либо имеет гэттэры, либо ToString(), которого нам будет 
    //достаточно, чтобы увидеть результат на экране
    public class CompositInfo
    {
        private VideocardCompany _company;
        private string _model;

        public CompositInfo(VideocardCompany company, string model)
        {
            _company = company;
            _model = model;
        }

        public override string ToString()
        {
            return string.Format("{0} {1}", _company, _model);
        }
    }
}
