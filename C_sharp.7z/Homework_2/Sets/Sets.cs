﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Sets
{
    class Sets
    {
        static void AddRange(HashSet<int> someSet, List<int> numbers)
        {
            //эта команда начинается со слова new - следовательно создается новое множество!
            //которое содержит только то, что было в списке но теряет то, что было до вызова этого метода
            //someSet = new HashSet<int>(numbers);

            //эта команда умеет добпавлять только 1 элемент, а ты пытаешься передать целый список
            //если бы была библиотечная функция AddRange, она бы именно так и получала параметр, но ее нет
            //нужно в цикле перебрать все, что есть в списке и по-элементно добавить их во множество
            
            for ( var i = 0; i < numbers.Count; ++i)
            {
                //var j = numbers[i];
                //someSet.Add(j);
                someSet.Add(numbers[i]);
            }

            //этот цикл делает тоже самое, что и for выше
            //если в цикле только одно действие, то скобки {} не обязательны
            //foreach (var num in numbers)
            //    someSet.Add(num);

            foreach (var num in someSet)
                Console.Write("{0}, ", num);
        }

        static void Main(string[] args)
        {
            //тебе домашнее задание создать метод AddRange, которое получит множество и список
            //и который добавляет из списка во множество все элементы

            //На следующем уроке будут очереди и стэки. Так же неплохо бы почитать о них

            var numbers = new List<int>() { 30, 20, 10, 20, 10, 20, 10, 20, 30 };
            var someSet = new HashSet<int>() { 5, 11};

            AddRange( someSet, numbers );

            Console.ReadKey();
        }
    }
}
