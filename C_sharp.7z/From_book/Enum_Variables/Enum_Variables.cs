﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Enum_Variables
{
    //если перечисление находится на том же уровне, что и класс, то для доступа из другого файла 
    //мы будет указывать просто его имя
    //если поместить перечисление в какой-то класс, то полным именем перечисления будет имяКласса.ИмяПеречисления
    //в пределах одного файла не важно, где помещать, но если собираешься использовать перечисление в других
    //файла, а так обычно и происходит, то перечисление вообще выносят в отдельный файл
    enum EmpType
    {
        Manager, // = 0
        Grunt, // = 1
        Contractor, // = 2
        VicePresident // = 3

        //Manager = 102,
        //Grunt,        // = 103
        //Contractor,   // = 104
        //VicePresident // = 105

        // Elements of an enumeration need not be sequential!
        //Manager = 10,
        //Grunt = 1,
        //Contractor = 100,
        //VicePresident = 9
    }

    class Enum_Variables
    {
        //воспринимай перечисление как набор констант
        //например, можно создать константы
        const int Manager = 0;
        const int Grunt = 103;
        //так объявляются глобальные переменные со значением самым первым в перечислении
        static MyEnum _someGlobalValue;
        //строка выше, более короткая запись такой
        //static MyEnum _someGlobalValue = MyEnum.First;
        //ну или так с явно заданным значением
        static MyEnum _anotherGlobalValue = MyEnum.Third;
        //такие константы ты просто вставишь в коде ради получения числа, которому они равны
        //и никогда не будешь ожидать получить их имя
        //проблема констант - каждая из них сама по себе, их нельзя поместить в группу
        //и сказать, что в каком-то месте можно использовать только одну из таких констант
        //именно эту задачу решают перечисления, они позволяют сказать, в этой группе только такие имена
        //и значения. Просто в случае перечислений значение редко имеет ценность. Их используют
        //для повышения читаемости кода. Ведь куда удобнее создать словарь, как я показа ниже
        //Dictionary<EmpType, string> _books
        //чем такой:
        static Dictionary<int, string> _books2 = new Dictionary<int, string>()
        {
            { 1, "Some text for Grunt"},
            { 102, "Some text for Manager"}
        };
        //когда в коде есть числа - они не читаются. Их называют magic number
        //значение каждого такого числа понятны только тому, кто писал код, но со временем и он забудт,
        //что такое 102. А перечисления в первую очередь повышают читаемость и самодокументируемость кода
        //нам не важно, что 102 - это Manager, нам важно отличать Manager от Grunt и язык потому дает
        //им разные числовы значения

        static void Main(string[] args)
        {
            //как видно, перечисление из другого файла ничем не отличается от тех, что объявлены в нем же
            var anotherValue = MyEnum.Second;
            Console.WriteLine("**** Fun with Enums *****");
            // Make an EmpType variable.
            EmpType emp = EmpType.Manager;
            AskForBonus(emp);
            AskForBonus2(emp);
            AskForBonus2(EmpType.VicePresident);

            //это вообще немного вводит в недоумение,
            //кажется, что мы стринг написали, а на деле они интегеры
            //хотя постой, это наверное о ключах, т.е. Manager -> 0
            Console.WriteLine("\nEmpType uses a {0} for storage",
                                Enum.GetUnderlyingType(emp.GetType()));
            // обычно не заморачиваются и после двоеточия ничего не пишут enum EmpType.
            //Это эквивалентно записи enum EmpType : int    

            Console.WriteLine("\n{0}", MyEnum.First);
            Console.WriteLine("\n{0}", _anotherGlobalValue);

            Console.WriteLine();

            Console.WriteLine("**** Fun with Enums *****");
            //фишка строчки внизу и следующих строчек не в Contractor, Monday или Gray,
            //а в EmpType, DayOfWeek и ConsoleColor
            //см. в методе EvaluateEnum на строчку Console.WriteLine("=> Information about {0}", e.GetType().Name);
            //именно в Name будет EmpType, DayOfWeek или ConsoleColor
            EmpType e2 = EmpType.Contractor;
            // These types are enums in the System namespace.
            //два этих перечисления уже созданны в самой библиотеке .Next в пространстве имен System
            //метод EvaluateEnum позволяет посмотреть какие значения есть в этих перечислениях
            //но есть и другой способ, почитать в документации или нажать F12
            DayOfWeek day = DayOfWeek.Monday;
            ConsoleColor cc = ConsoleColor.Gray;
            EvaluateEnum(e2);
            EvaluateEnum(day);
            EvaluateEnum(cc);
            Console.ReadLine();

            Console.ReadKey();
        }

        //здесь в качестве типа параметра указано не конкретное перечисление, а общий для всех перечислений
        //тип Enum. Это значит, что этот метод можо вызвать с любым перечислением
        //System.Enum можно упростить до просто Enum, так как в само начале написали using System;
        //по хорошему Console тоже находится в пространстве имен System и полное имя для него System.Console
        static void EvaluateEnum(Enum e)
        {
            //обращение к методу GetType() позволяет через специальный механизм рефлексии получить всю информацию
            //о любом типе данных. Рефлексия достаточно медленная потому без особой нужды я бы в нее не лез.
            //за все время мне приходилось максимум пару раз ее использовать, почти всегда можно обойтись без нее
            //этот метод позволяет по одному единственному значению перечисления узнать как называлось это перечисление
            //узнать все его текстовые значения и какие числовые эквиваленты им присвоены
            Console.WriteLine("=> Information about {0}", e.GetType().Name);
            Console.WriteLine("Underlying storage type: {0}",
            Enum.GetUnderlyingType(e.GetType()));
            // Get all name/value pairs for incoming parameter.
            //она возвращает массив всех значений перечисления, которое получит метод как параметр
            Array enumData = Enum.GetValues(e.GetType());
            Console.WriteLine("This enum has {0} members.", enumData.Length);
            // Now show the string name and associated value, using the D format
            // flag (see Chapter 3).
            for (int i = 0; i < enumData.Length; i++)
            {
                //Console.WriteLine("Name: {0}, Value: {0:D}", // {0:D} - это аналог (int)enumValue, т.е. принуждение в int
                //enumData.GetValue(i));
                var enumValue = enumData.GetValue(i);
                //приведение значение перечисления к целому числу мы ранее рассматривали
                //но такое нужно очень редко. В книге пытаются рассказать обо всех возможностях, я тебе даю информацию
                //дозированно, по мере того, как в ней появляется необходимость, чтобы не перегружать лишней информацией
                Console.WriteLine("Name: {0}, Value: {1}", enumValue, (int)enumValue);
            }
            Console.WriteLine();
        }

        //в этом примере можно увидеть красоту и элегантность применения словарей
        //здесь четко видна зависимость между значением перечисления и строкой, которую нужно вывести
        //тогда компактнее создать такой словарь
        static Dictionary<EmpType, string> _books = new Dictionary<EmpType, string>()
        {
            { EmpType.Manager, "How about stock options instead?"},
            { EmpType.Grunt, "You have got to be kidding..."},
            { EmpType.Contractor, "How about stock options instead?"},
            { EmpType.VicePresident, "VERY GOOD, Sir!"},
        };

        static void AskForBonus2(EmpType e)
        {
            //одна строка кода, вместо длинного switch!!!
            //здесь команда получить значение по ключу, который получили
            Console.WriteLine(_books[e]);
        }

        static void AskForBonus(EmpType e)
        {
            switch (e)
            {
                case EmpType.Manager:
                    Console.WriteLine("How about stock options instead?");
                    break;
                case EmpType.Grunt:
                    Console.WriteLine("You have got to be kidding...");
                    break;
                case EmpType.Contractor:
                    Console.WriteLine("You already get enough cash...");
                    break;
                case EmpType.VicePresident:
                    Console.WriteLine("VERY GOOD, Sir!");
                    break;
            }
        }

        
    }
}
