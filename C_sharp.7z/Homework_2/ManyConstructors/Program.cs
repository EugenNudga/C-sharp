﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ManyConstructors
{
    class Program
    {
        static void Main(string[] args)
        {
            //а это создание по координатам левого верхнего угла и правого нижнего угла
            var r1 = new Rectangle(10, 10, 10, 10.0);
            //обрати внимание, что обе строки ниже вызовут один и тот же конструктор, у которого последний параметр float
            //из-за такой неочевидности, лучше так не извращаться
            //слишком много конструкторов тоже плохо
            //var r2 = new Rectangle(10, 10, 10, 10f);
            //так тоже указываем высоту и ширину в 3 и 4м параметрах
            var r2 = new Rectangle(10, 10, 10, 10f);
            //можно вполне для создания через ширину и высоту использовать 3й конструктор
            //то мы создали прямоугольник с координайто левого верхнего угла (10, 10), шириной 10 и высотой 5
            var r3 = new Rectangle(new Point(10, 10), 10, 5);
        }
    }
}
