﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GameUnits
{
    public class Tank : GroundVehicle
    {
        //танк, стреляет только по наземным и надводным целям.
        //Дополнительно содержит: урон по людям, урон по зданиям, урон по технике

        private int _peopleDamage;
        private int _buildingDamage;
        private int _vehicleDamage;

        private int _calibr;

        public Tank(string name, float health, float maxSpeed, float weight, int crewSize,
            int peopleDamage, int buildingDamage, int vehicleDamage, int calibr) :
            base(name, health, maxSpeed, weight, crewSize)
        {
            Console.WriteLine("Tank.Constructor({0})", name);
            _peopleDamage = peopleDamage;
            _buildingDamage = buildingDamage;
            _vehicleDamage = vehicleDamage;
            _calibr = calibr;
        }

        public override string ToString()
        {
            //здесь мы получим то, что описано в базовом классе, чтобы не дублировать информацию
            //иначе много копипаста, а копипаст всегда плохо
            //когда пишем base - это значит поищи метод по иерархии выше, с таким же названием. Если у прямого родителя нет, то он сам поищет
            //у родителя родителя и так вверх, пока не найдет подходящий метод
            //конкретно здесь, так как у GroundVehicle нет метода ToString, то компилятор поищет у его родителя, которым есть Vehicle и возьмет все там
            var vehicleInfo = base.ToString();
            return string.Format("{0}\nPeople damage: {1}\nBuilding damage: {2}\nVehicle damage",
                vehicleInfo, _peopleDamage, _buildingDamage, _vehicleDamage);
        }
    }
}
