﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Class_Olympic_Subject
{
    class Building
    {
        //содержит поля:
        //адрес(в виде строки), количество этажей, количество квартир
        private string _address;
        private int _amountOfFloors;
        //опасность поля _amountOfApartments при наличии списка в том, что нужно
        //не забывает его увеличивать при добавлении описания квартиры и удалять 
        //при удалении описания. Если забыть где-то добавить изменения этого поля -
        //получим разные значения в _apartments.Count и _amountOfApartments
        //так как _apartments всегда содержит все квартиры - следовательно это более
        //точное описание, а _amountOfApartments избыточно
        //private int _amountOfApartments;

        private List<ApartmentPassport> _apartments = new List<ApartmentPassport>();

        public Building(string address, int amountOfFloors)
        {
            _address = address;
            _amountOfFloors = amountOfFloors;
        }

        public void AddApartment(ApartmentPassport apartment)
        {
            //++_amountOfApartments;
            Console.WriteLine("Apartment {0} added to building at {1}\n", 
                apartment.FlatNumber, _address);
            _apartments.Add(apartment);
        }

        public override string ToString()
        {
            //Получить массив или список в виде строки можно и здесь
            //например нам здесь нужно вернуть номера всех квартир
            //Эта команда вернет нам список строк, где будут только номера квартир
            //для этого используется метод Select, который встроен в класс List
            //для того, чтобы использовать наш хэлпер метод, который умеет
            //преобразовывать только массивы или только списки используем .ToList()
            var onlyNumbers = _apartments.Select(a => a.FlatNumberAsString).ToList();
            var numbersAsString = HelperClass.ListOfStringsToSingleString(onlyNumbers);
            return string.Format("Building address: {0}\namount of floors: {1}\namount of flats: {2}\nThey are: {3}", 
                _address, _amountOfFloors, _apartments.Count, numbersAsString);
        }
    }
}
