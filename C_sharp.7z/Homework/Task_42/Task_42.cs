﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_42
{
    class Task_42
    {
        static void Main(string[] args)
        {
            while (true)
            {
                //Вывести числовую пирамидку на total строк. Порядок строк – обратный.
                //В каждой строке числа идут от единицы до номера строки через пробел.
                //Пример ввода      //3
                //Пример вывода
                //1 2 3
                //1 2
                //1
                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter a positive integer number (amount of rows): ");
                    var rows = Convert.ToInt32(Console.ReadLine());

                    for (var i = rows; i >= 1; i--)
                    {
                        for (var j = 1; j <= i; j++)
                        {
                            Console.Write("{0} ", j);
                        }
                        Console.WriteLine();
                    }
                }
                else
                    break;
            }
            Console.ReadKey();
        }
    }
}
