﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_11
{
    class Task_11
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры целое число.
            //- Если число четное, вывести alpha
            //- Если число кратно трем, вывести bravo
            //-Если число кратно пяти, вывести charlie
            //-Если число не кратно ни одному из них, вывести zulu
            //Пример ввода      //8
            //Пример вывода     //alpha

            Console.Write("Enter first integer number: ");
            var num0 = Convert.ToInt16(Console.ReadLine());
            
            if ( (num0 % 5) == 0)
            {
                Console.WriteLine("charlie");
            }
            else if ( (num0 % 3) == 0)
            {
                Console.WriteLine("bravo");
            }
            else if ( (num0 % 2) == 0)
            {
                Console.WriteLine("alpha");
            }
            else
            {
                Console.WriteLine("zulu");
            }

            Console.ReadKey();

        }
    }
}
