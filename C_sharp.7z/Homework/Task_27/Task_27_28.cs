﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace Task_27_28
{
    class Task_27_28
    {
        //создание константы - нужно использовать ключевое слово const
        //большие буквы в имени не обязательны, но они бросаются в глаза и так подсказывают читающему код
        //что это не простая переменная
        const int SOME_CONST = 10;

        //функция возвращает число, которое не меньше n и которое кратно divider
        static int FindNearestMod(int n, int divider)
        {
            //через цикл решать эту задачу можно, но это не самый оптимальный способ
            //while (n % divider != 0)
            //    ++n;
            //return n;

            //мы уже решали эту задачу в одной и тасков
            //проблема этого метода в том, что при большом divider придется много раз выполнить цикл
            //while, прежде чем будет найдено нужное число
            //математический способ всегда решает задачу за 2 действия
            var count = n / divider; //n = 3, divider = 3   =>     3/3=1
            return (n % divider == 0) ? (divider * count) : (divider * count) + divider;//3*1=3
        }

        static void Main(string[] args)
        {   //Task_27
            //Считать min, max. Вывести в столбик кратные тройке числа от min до max включительно.
            //Пример ввода      //0 9
            //Пример вывода     //0 3 6 9

            while (true)
            {
                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nCase кратные тройке:\nEnter a min integer number: ");
                    var min = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter a max integer number: ");
                    var max = Convert.ToInt32(Console.ReadLine());
                    //было i = 3; переписали на DIVIDER1 = 3;
                    //если ты уже хочешь сделать константу - то назови ее так, чтобы было понятно, что она выражает
                    //а просто заменить цифру 3 буквой i - не сделать код понятнее
                    //здесь DIVIDER1 НЕ константа, так как нету команды const, мы просто выделили имя
                    //капслоком, чтобы привернуть внимание, что это не простая переменная
                    // мы не написали const здесь потому, что нельзя создать константу внутри метода
                    //так что проще было просто выделить имя и все
                    var DIVIDER1 = 3;
                    //без min = ты просто терял результат работы метода. Метод находил ответ, но ты его
                    //ничему не присваивал и он игнорировался
                    min = FindNearestMod(min, DIVIDER1);

                    //это нужно сделать оптимальнее, без if!
                    for (var output = min; output <= max; output+= DIVIDER1)
                    {
                        Console.Write("{0} ", output);
                    }
                    Console.WriteLine();

            //Task28
            //Считать min, max. Вывести в столбик кратные пяти числа от min до max включительно.
            //Пример ввода      //0 15
            //Пример вывода     // 0 5 10 15

                    Console.Write("\nCase: кратные пяти:\nEnter a min integer number: ");
                    var min1 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter a max integer number: ");
                    var max1 = Convert.ToInt32(Console.ReadLine());
                    var DIVIDER2 = 5;
                    min1 = FindNearestMod(min1, DIVIDER2);
                    //это нужно сделать оптимальнее, без if!
                    for (var output1 = min1; output1 <= max1; output1+= DIVIDER2)
                    {
                        Console.Write("{0} ", output1);
                    }
                    Console.WriteLine();
                }
                else
                    break;
            }

            Console.ReadKey();
        }
    }
}
