﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_35
{
    class Task_35
    {
        static void Main(string[] args)
        {
            while (true)
            {
                //запомни простую запись, если тебе нужно выполнить цикл n раз, всегда незадумываясь пиши
                //for(var i = 0; i < n; i++), если нужно начинать с 0
                //если же нужно начать с 1, тогда
                //for(var i = 1; i <= n; i++)
                //но когда нужно перебирать в обратном порядке, то немного не так
                //for (var i = n - 1; i >= 0; i++) - если нужно для числа 5 получить индексы 4 3 2 1 0
                //for (var i = n; i >= 1; i++) - если нужно для числа 5 получить индексы 5 4 3 2 1
                //for (var i = n; i > 0; i++) - еще вариант, если нужно для числа 5 получить индексы 5 4 3 2 1

                //Считать с клавиатуры два целых числа.
                //Вывести в строку все чётные числа в промежутке от первого до второго включительно.
                //В указанном промежутке гарантировано наличие хотя бы одного числа, подлежащего выводу.
                //Пример ввода      //7 15
                //Пример вывода     //8 10 12 14

                Console.Write("If you want to continue - enter 1, else any other button to exit: ");
                //ConsoleKey.D1 - это цифра 1
                if (Console.ReadKey().Key == ConsoleKey.D1)
                {
                    Console.Write("\nEnter a first integer number (from which we will start): ");  //
                    var num0 = Convert.ToInt32(Console.ReadLine());
                    Console.Write("Enter a second integer number: ");
                    var num1 = Convert.ToInt32(Console.ReadLine());

                    if (num0 < num1)
                    {
                        //Пример ввода      //7 15
                        //Пример вывода     //8 10 12 14
                        if (num0 % 2 == 1)
                            num0 += 1;
                        //в данном случае избыточно приведение num1 к четному
                        //так как за нас все делает цикл
                        //проверкой выше мы гарантируем, что стартовое число четное
                        //всегда прибавляем 2 на каждой итерации, следовательно i тоже всегда четное
                        //и нам достаточно указать минимальное число, которое нас устраивает
                        //пример, укажем 3 и 5
                        //num0 станет 4, после этого i сначала равно 4, а на второй итерации станет 6
                        //6 > 5 (последнего числа), следовательно на этом цикл и закончится
                        //так что ты перестраховывался на том, что можно было не перестраховываться ;)
                        //if (num1 % 2 == 1)
                        //    num1 -= 1;
                        for (var i = num0; i <= num1; i+=2)
                        {
                            Console.Write("{0} ", i);
                        }
                        Console.WriteLine();
                    }
                    else
                    {
                        //Пример ввода      //15 7
                        //Пример вывода     //14 12 10 8 
                        if (num0 % 2 == 1)
                            num0 -= 1;
                        //if (num1 % 2 == 1)
                        //    num1 += 1;
                        for (var i = num0; i >= num1; i -= 2)
                        {
                            Console.Write("{0} ", i);
                        }
                        Console.WriteLine();
                    }
                    Console.WriteLine();
                }
                else
                    break;
            }
            Console.ReadKey();
        }
    }
}
