﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Animal_New_World
{
    public enum Months {January, February, March, April, May, June, July, August, September, October, November, December}
    public enum Abilities { None, HasSharpTeeth, ElectricTail, SwordNose, Poisonous}

    public class Fishes : Animals
    {
        //рыбы пусть содержат: максимальную глубину, на которой встречаются, в каком месяце нерестятся(из энумки 12 месяцев),
        //список особых умений если есть(например мурена ядовита, скаты с электричеством,
        //осьминоги используют чернила для маскировки + имеют присоски...)

        private int _maxDepth;//в км
        private Months _monthOfReproduction;
        //здесь не создаем массив потому, что нам все равно придет другой массив в конструкторе, который перетрет чтобы мы здесь не создали
        //это тот редкий случай, когда при конструировании объекта уже нужно знать содержимое одной из его коллекций.
        //животные еще при рождении получают те или иный способности, что мы и иммитируем конструктором. Считай, что вызов конструктора - это
        //рождение объекта.
        private Abilities[] _specialAbilities;

        public Fishes(string name, int age, int weight, bool isPredator, int levelOfFullness,
            int maxDepth, Months monthOfReproduction, Abilities[] specialAbilities) :
            base (name, age, weight, TypeOfReproduction.caviar, true, false, isPredator, levelOfFullness)
        {
            _maxDepth = maxDepth;
            _monthOfReproduction = monthOfReproduction;
            _specialAbilities = specialAbilities;
        }

        //вернули метод и теперь рыбы снова могут "говорить" по своему :)
        public override void Voice()
        {
            //эта строка просто отличается от того, что в других классах, что конкретно выводится не важно
            Console.WriteLine("fish {0} has no voice", _name);
        }

        public override void Eat(int amount)
        {
            //вот так вызывается метод Eat базового класса
            //виртуальный метод базового класса нужно конечно же вызывать в одноименном методе класса наследника!
            //альтернатива писать код, но зачем дублировать его?!
            //_levelOfFullness += amount;
            //if (_levelOfFullness > 100)
            //    _levelOfFullness = 100;
            //получается, тот код, который повторяется во всех классах - выносим в базовый метод, а в наследниках не забываем вызывать
            //base.ИмяМетода
            base.Eat(amount);
            //эта строка остается, она добавляет рыбам то, чего не делает базовый класс, но чтобы изменилась переменная _levelOfFullness
            //нужно вызвать метод Eat(int amount) базового класса до этой строки
            //кормим в методе Eat - это отдельное действие. Именно здесь нужно вызывать метод базового класса. Ладно, показываю
            //рыба просто пишет, что не может говорить :)
            Console.WriteLine("{0} say nothing - it's a fish", _name);
        }

        public string SpecialAbilities()
        {
            if (_specialAbilities != null)
            {
                var ab = new StringBuilder();
                for (var i = 0; i < _specialAbilities.Length; ++i)
                    ab.Append(string.Format("{0}, ", _specialAbilities[i]));
                return ab.ToString();
            }
            else
                return "no abilities";

        }

        public int MaxDepth
        {
            get { return _maxDepth; }
        }

        public override string ToString()
        {
            //эта строка обращается к методу ToString() базового класса, чтобы не дублировать код из него
            //вместо того, чтобы писать в каждом наследнике код 
            //return string.Format("Name: {0}\nAge: {1} years\nWeight: {2} kg", _name, _age, _weight);
            //мы пишем просто base.ToString();
            //более того, если мы потом захотим изменить базовый текст - нам будет достаточно сделать это только в базовом классе
            //тот же принцип и с методом Eat. В базовом классе мы пишем код, который кормит животное - контролирует, чтобы не перекормить на 100%
            //и изменяет переменную сытости, а в методах классов наследников мы просто добавляем какую-то дополнительную работу
            //например птица покаркает при этом, а рыба просто пустит пузыри. Сейчас не важно что дополнительное они сделают, главное понять принцип
            //как дать возможность что-либо сделать дополнительное в методах классов наследников. Ты в принципе сделал почти все, что нужно, но забыл 
            //вызвать метод base.Eat()
            var animalInfo = base.ToString();
            return string.Format("{0}\nMax depth: {1} km\nAbilities: {2}", animalInfo, _maxDepth, SpecialAbilities());
        }
    }
}
