﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_29
{
    class Task_29
    {
        static void Main(string[] args)
        {
            //Считать с клавиатуры целые числа min, max и положительный делитель.
            //Вывести в столбик числа, кратные делителю, от min до max включительно.
            //Пример ввода      //0 8 2
            //Пример вывода     //0 2 4 6 8
            
            Console.Write("Enter a min integer number: ");
            var min = Convert.ToByte(Console.ReadLine());
            Console.Write("Enter a max integer number: ");
            var max = Convert.ToByte(Console.ReadLine());
            Console.Write("Enter a positive divisor: ");
            var div = Convert.ToByte(Console.ReadLine());

            for (var output = min; output <= max; output++)
            {
                if ((output % div) == 0)
                    Console.Write("{0} ", output);
            }

            Console.ReadKey();

        }
    }
}
