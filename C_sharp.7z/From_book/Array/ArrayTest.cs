﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


//смотри, в стандартной библиотеке есть класс Array
//Ты мало того, что назвал свой класс так же, ты еще и создал пространство имен с таким же именем
//В таком случае компилятор ищет дубликат имени в текущем пространстве имен
//но даже если очень нужно назвать класс так же, как стандартный, такие конфликты имен позволяют разрулить 
//пространства имен, для чего они и были созданы. Если ты используешь имя, которое присутствует 
//в другом пространсве имен, то можно перед именем, которое компилятор понял неправильно
//ставить имя правильного (например, ArrayTest) и все будет ок
namespace Array
{
    class ArrayTest
    {
        static void Main(string[] args)
        {
            Console.WriteLine("=> Working with System.Array.");
            // Initialize items at startup.
            string[] gothicBands = { "Tones on Tail", "Bauhaus", "Sisters of Mercy" };
            // Print out names in declared order.
            Console.WriteLine("-> Here is the array:");
            for (int i = 0; i < gothicBands.Length; i++)
            {
                // Print a name.
                Console.Write(gothicBands[i] + ", ");
            }
            Console.WriteLine("\n");
            // Reverse them...
            //здесь компилятор подумал, что ты ссылаешь на свое пространство имен
            //а не на одноименный класс из пространства System
            //в таком случае просто допишем System переде Array и получим то, что нужно
            //если не знаешь в каком пространсве находится тот или иной стандартный класс
            //можно гуглить так имяКласса C# - первая же ссылка будет на msdn, где все будет написано
            //так смотрим результат для поиска Array c# - ссылку https://msdn.microsoft.com/ru-ru/library/system.array(v=vs.110).aspx
            System.Array.Reverse(gothicBands);
            Console.WriteLine("-> The reversed array");

            // ... and print them.
            for (int i = 0; i < gothicBands.Length; i++)
            {
                // Print a name.
                Console.Write(gothicBands[i] + ", ");
            }
            Console.WriteLine("\n");
            // Clear out all but the first member.
            Console.WriteLine("-> Cleared out all but one...");
            //хоть такое и можно делать с массивами благодаря библиотечным методам
            //я все же рекомендую массивы использовать тогда, когда количество элементов 
            //не меняется с момента создания массива и до конца его использования
            //если же нужно изменять размер - то лучше взять класс List, он оптимизирован под это
            System.Array.Clear(gothicBands, 1, 2);//1- это с какого места начать, а 2 - количество элементов
            for (int i = 0; i < gothicBands.Length; i++)
            {
                // Print a name.
                Console.Write(gothicBands[i] + ", ");
            }
            Console.WriteLine();

            ArrayInitialization();

            Console.ReadKey();
        }

        static void ArrayInitialization()//explicit arrays!!! for implicit arrays look below
        {
            Console.WriteLine("=> Array Initialization.");
            // Array initialization syntax using the new keyword.
            string[] stringArray = new string[]{ "one", "two", "three" };
            Console.WriteLine("stringArray has {0} elements", stringArray.Length);
            // Array initialization syntax without using the new keyword.
            bool[] boolArray = { false, false, true };
            Console.WriteLine("boolArray has {0} elements", boolArray.Length);
            // Array initialization with new keyword and size.
            int[] intArray = new int[4] { 20, 22, 23, 0 };
            Console.WriteLine("intArray has {0} elements", intArray.Length);
            Console.WriteLine();
        }


        static void DeclareImplicitArrays()
        {
            Console.WriteLine("=> Implicit Array Initialization.");
            // a is really int[].
            //я тебе уже рассказывал о том, что для массивов тип писать не обязательно, 
            //если указаны стартовые значения. Обычно можно так и писать
            //указывать конкретный тип приходится если тебе целые значения нужно хранить не как int
            //а как byte или short, например. Ибо компилятор все, что целое считает int
            var a = new[] { 1, 10, 100, 1000 };
            Console.WriteLine("a is a: {0}", a.ToString());
            // b is really double[].
            var b = new[] { 1, 1.5, 2, 2.5 };
            Console.WriteLine("b is a: {0}", b.ToString());
            // c is really string[].
            var c = new[] { "hello", null, "world" };
            Console.WriteLine("c is a: {0}", c.ToString());
            Console.WriteLine();
        }
    }
}
