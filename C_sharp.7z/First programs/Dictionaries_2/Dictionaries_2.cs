﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Dictionaries_2
{
    class Dictionaries_2
    {
        enum TM { VW, AUDI, PORSHE, NISSAN, INFINITI}

        static void Main(string[] args)
        {
            //цифра 5 в круглых скобка не то, что ты думаешь - это не к-во элементов в словаре,
            //это к-во, которое будет создано в самом начале, но оно может потом меняться
            //Dictionary<int, string> countries = new Dictionary<int, string>(5);
            //countries.Add(1, "Russia");
            //countries.Add(3, "Great Britain");
            //countries.Add(22, "USA");
            //countries.Add(4, "France");
            //countries.Add(5, "China");
            //так инициировать словарь стартовыми значениями немного удобнее
            //здесь, в отличии от списков, каждая  пара ключ-значение ограничивается отдельными {}
            //для сравнения списки выглядят так {"", "", ""}
            var countries = new Dictionary<int, string>()
            {
                { 1, "Russia" },
                { 3, "Great Britain" },
                { 22, "USA" },
                { 4, "France" },
                { 5, "China" },
            };

            //пример, который показывает, что ключами могут быть перечисления, а значениями любые типы, например списки
            var cars = new Dictionary<TM, List<string>>()
            {
                { TM.AUDI, new List<string>() {"A3", "A6", "A8", "Q5" } },
                { TM.VW, new List<string>() {"Golf", "Passat", "Polo" } },
            };
            //тогда, чтобы получить список моделей ауди пишем так
            var audiList = cars[TM.VW];
            foreach(var car in audiList)
                Console.Write("{0}, ", car);
            Console.WriteLine();
            Console.WriteLine();

            foreach (KeyValuePair<int, string> keyValue in countries)
            {
                Console.WriteLine(keyValue.Key + " - " + keyValue.Value);
            }

            // получение элемента по ключу
            string country = countries[4];
            Console.WriteLine("Key 4 was {0}, key 1 was {1}", country, countries[1]);

            // изменение объекта по ключу
            countries[4] = "Spain";
            countries[5] = "Spain";
            //если ключа такого раньше не было, то эта команда создаст его!
            countries[44] = "Spain";
            //но если попробовать прочитать значение по ключу, которого не было, то будет ошибка
            //Console.WriteLine("Try to take value for invalid key {0}", countries[111]);
            //для ситуаций, когда нужно прочитать значение по ключу, которого может не быть
            //можно использовать два способа:
            //1) чуть более понятный, но не такой быстрый
            //заключается в том, что сначала проверяем наличие ключа и лишь после этого читаем
            if (countries.ContainsKey(44))
                Console.WriteLine("Key 44 is present in dictionary. It holds {0}", countries[44]);
            //2) используем метод, который вернет true, только если такой ключ есть и присвоит переменной someValue
            //так четко видно, что метод возвращает признак того, найден ли ключ, но опытные так не пишут
            //if (countries.TryGetValue(44, out value) == true)
            //так короче, но может не так понятно, что метод возвращает true|false
            //в любом случае, если ключ есть, переменной someValue будет присвоено значение, хранящееся по этому ключу
            //выгода здесь в том, что за один раз происходит и поиск значения и проверка на его присутствие
            //в первом варианте выполняется две операции, но можно не заморачиваться на это
            //поиск по ключу в словаре очень и очень быстрая операция
            string someValue;
            if (countries.TryGetValue(44, out someValue))
                    Console.WriteLine("Key 44 is present in dictionary. It holds {0}", someValue);
            //эта разница в скорости важна только тогда, когда ты за секунду делаешь очень много таких поисков
            //если же он один в пятилетку, то разницы можно сказать нет
            // удаление по ключу
            countries.Remove(22);
            countries[33] = "Belazzz";

            Console.WriteLine();

            //указывать явно тип для keyValue конечно же можно, но большого смысла в этом нет, var сокращает время набора
            //главное понимать, что foreach в переменную запишет объект, который содержит и ключ и значение
            //доступ к которым пррисходит по keyValue.Key для ключа и по keyValue.Value для значения
            //foreach (KeyValuePair<int, string> keyValue in countries)
            foreach (var keyValue in countries)
            {
                Console.WriteLine(keyValue.Key + " - " + keyValue.Value);
            }
            Console.WriteLine();
            //второй способом сделать тоже самое - перебирать только ключи:
            foreach (var key in countries.Keys)
                //тогда в переменную записывается один только ключ, а значение получаем через него явно
                Console.WriteLine(key + " - " + countries[key]);
            Console.WriteLine();

            //нужно учитывать, что ключи в словарях не сортируются в каком-либо виде
            //иногда это не совсем удобно, но всегда есть способ получить ключи и отсортировать их
            //так мы получаем ключи в виде списка, так как коллекция Keys это что-то более хитрое
            Console.WriteLine("Sorted output:");
            var keys = countries.Keys.ToList();
            keys.Sort();
            foreach (var key in keys)
                Console.WriteLine(key + " - " + countries[key]);
            Console.WriteLine();

            //здесь в качестве значения используется тип Person
            //такого типа нет в библиотеке, значит это класс, который был создан в книге рядом, но ты не заметил
            //мы обязательно рассмотрим этот вариант немного позднее. Коротко покажу сейчас
            //Dictionary<char, Person> people = new Dictionary<char, Person>();
            //people.Add('b', new Person() { Name = "Bill" });
            //people.Add('t', new Person() { Name = "Tom" });
            //people.Add('j', new Person() { Name = "John" });

            //foreach (KeyValuePair<char, Person> keyValue in people)
            //{
            //    // keyValue.Value представляет класс Person
            //    Console.WriteLine(keyValue.Key + " - " + keyValue.Value.Name);
            //}

            //// перебор ключей
            //foreach (char c in people.Keys)
            //{
            //    Console.WriteLine(c);
            //}

            //// перебор по значениям
            //foreach (Person p in people.Values)
            //{
            //    Console.WriteLine(p.Name);
            //}

            Console.ReadKey();
        }
    }
}
