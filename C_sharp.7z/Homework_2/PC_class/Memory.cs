﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PC_class
{
    //да, здесь каждой переменной перечисления присвоили явные значения, но это позволит легко привести их к типу int
    //чего у тебя не получилось сделать с классом
    //такое перечисление нам даст возможно выбирать вариант максимального количества памяти только из возможных вариантов
    //и при этом знать, чему как целое число равно каждое значение перечисления
    public enum MemorySize { _1Gb = 1, _2Gb = 2, _4Gb = 4, _8Gb = 8, _16Gb = 16, _32Gb = 32, _64Gb = 64}
    public enum MemoryCompany { Hynix, Samsung, Corsair, Kingmax, Transcend, Kingston, OCZ};
    public enum TypeOfMemory { SD_RAM, DDR, DDR2, DDR3, DDR4 };

    public class Memory
    {
        //класс Память:
        //производитель(создай перечисление для 5 - 6
        //основных производителей памяти, нагуглить, думаю сможешь),
        //тип(перечисление: SD - RAM, DDR, DDR2, DDR3 и тп), 
        //частота памяти, количество Мегабайт
        private MemoryCompany _memoryCompany;
        private TypeOfMemory _typeOfMemory;
        //это поле заменило _amountOfMemory, так как оно удобнее для использования, оно не даст ввести 3Gb или 5Gb
        //которых не существует в природе, а только то, что есть в перечислении
        private MemorySize _moduleSize;
        private int _frequency;

        public Memory(MemoryCompany memoryCompany, TypeOfMemory typeOfMemory, MemorySize moduleSize,
            int frequency)
        {
            _memoryCompany = memoryCompany;
            _typeOfMemory = typeOfMemory;
            _moduleSize = moduleSize;
            _frequency = frequency;
            Console.WriteLine("Memory.Constructor(): {0} created", ToString());
        }

        public MemoryCompany MemoryCompany
        {
            get { return _memoryCompany; }
        }

        public int Frequency
        {
            get { return _frequency; }
        }

        public MemorySize ModuleSize
        {
            get { return _moduleSize; }
        }

        public TypeOfMemory MemoryType
        {
            get { return _typeOfMemory; }
        }

        //этот метод подставит короткое описание модуля памяти там, где мы в Console.Write
        //передадим любой объект типа Memory
        public override string ToString()
        {
            return string.Format("Module {0} {1} {2}Gb {3}MHz ", _memoryCompany, _typeOfMemory,
                (int)_moduleSize, _frequency);
        }
    }
}
