﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_3_and_4
{
    class Task_3_and_4
    {
        static void Main(string[] args)
        {
            Console.Write("Enter any integer number: ");
            var num = Convert.ToByte(Console.ReadLine());
            
            if( (num % 2) == 0 )
            {
                Console.WriteLine("The number you entered is even =)");
            }
            else
            {
                Console.WriteLine("The number you entered is odd =(");
            }

            Console.ReadKey();
        }
    }
}
