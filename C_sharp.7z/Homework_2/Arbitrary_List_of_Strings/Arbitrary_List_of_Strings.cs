﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Arbitrary_List_of_Strings
{
    class Arbitrary_List_of_Strings
    {
        static void Main(string[] args)
        {

            //1) из произвольного списка строк вывести на экран только те строки,
            //    длина которых больше 5 символов
            //2) подсчитать в произвольном списке целых чисел сколько чисел больше 0,
            //    которые кратны 5
            //3) вывести на экран "Нет таких значений",
            //    если в списке строк нету ни одной строки, которая содержит цифры

            
            var listOfStrings = new List<string> { "bwahahahaa", "subdurally", "antivirals", "CT", "IT", "stake", "makak"};

            var listOfNumbers = new List<int> { -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14, -15, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31, 32, 33, 34, 35, 36, 37, 38, 39, 40, 41, 42, 43, 44, 45, 46, 47, 48, 49, 50, 51, 52, 53, 54, 55, 56, 57, 58, 59, 60, 61, 62, 63, 64, 65, 66, 67, 68, 69, 70, 71, 72, 73, 74, 75, 76, 77, 78, 79, 80, 81, 82, 83, 84, 85, 86, 87, 88, 89, 90, 91, 92, 93, 94, 95, 96, 97, 98, 99, 100 };
            var listOfNumbers1 = new List<int> { -1, -2, -3, -4, -5, -6, -7, -8, -9, -10, -11, -12, -13, -14, -15, 1, 2, 3, 4, 6, 7, 8, 9 };

            foreach (var str in listOfStrings)
                Console.Write("{0}, ", str);

            Console.WriteLine();

            PrintStrings(listOfStrings);//с более, чем 5-ю символами

            Console.WriteLine();

            var res = 0;
            foreach (var num in listOfNumbers1)
            {
                if ((num > 0) && (num % 5 == 0))
                    res++;
            }
            if(res>0)
                Console.WriteLine(res);
            else
                Console.WriteLine("Нет таких значений");

            Console.WriteLine();

            //это работает, но не очень эффективно
            //когда стоит задача, есть ли хоть один элемент, который соответствует условию
            //то, при нахождении первого такого соответствия нужно обрывать цикл, так как этого
            //достаточно. В случае двух вложенных циклов это сделать не очень удобно.
            //в таком случае проще вынести оба цикла в отдельный метод, но для начала попробуй без
            //вынесения. Другими словами, модифицируй код так, что как только находит первую цифру
            //оба цикла обрываются
            //в ситуациях, когда достаточно одного соответствия логично использовать тип bool
            //вместо int. До цикла выставляем его в false. А в сработавшем условии меняем на true
            var flag = false;
            foreach (var str in listOfStrings)
            {
                //if (flag == true)
                //эта проверка обрывает внешний цикл после того, как внутренний цикл оборвется
                if (flag)
                    break;
                foreach (var ch in str)
                {
                    if (Char.IsNumber(ch))
                    {
                        flag = true;
                        break;
                        //Console.Write("{0}, ", ch);
                        //flag++;
                    }
                }
            }
            //if (flag == false)
            if (!flag)
                Console.WriteLine("В списке не найдено строк с цифрами");
            if (!IsNumberInList(listOfStrings))
                Console.WriteLine("В списке не найдено строк с цифрами ");
            //но эту и все прошлые задачи можно рещить без циклов, используя методы
            //которые мы совсем чуть-чуть рассматривали в теме списков - лямбда выражения
            //есть методы, которые позволяют решить многие типовые задачи со списками в одну
            //строку

            Console.ReadKey();
        }

        //3я задача, но через метод, что проще
        private static bool IsNumberInList(List<string> listOfStrings)
        {
            //дополнительный флаг не нужен, так как всю работу сделает return
            foreach (var str in listOfStrings)
            {
                foreach (var ch in str)
                {
                    if (Char.IsNumber(ch))
                    {
                        //нашли первое соответствие - обрываем все, что относится к этому методу
                        //так можно прервать хоть 100 циклов и потому церез метод подобное проще
                        return true;
                    }
                }
            }
            //если дошли сюда - в цикле ни разу не выполнилось условие - значит ответ false
            return false;
        }

        static void PrintStrings(List<string> listOfStrings)
        {
            foreach (var str in listOfStrings)
            {
                if (str.Length > 5)
                {
                    Console.Write("{0}, ", str);
                }
            }            
        }

        //static void PrintStrings(List<string> listOfStrings)
        //{
        //    foreach (var str in listOfStrings)
        //    {
        //        if (str.Length > 5)
        //            Console.Write("{0}, ", str);
        //    }
        //}
    }
}
