﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Task_5_6_7_8
{
    class Task_5_6_7_8
    {
        //метод Main обязательно должен быть static, а нельзя из static метода класса вызвать не статик метод этого же класса
        //потому метод GetMaxValue тоже должен быть помечен как static
        static void Main(string[] args)
        {
            Console.Write("Enter first number: ");
            var num0 = Convert.ToByte(Console.ReadLine());
            Console.Write("Enter second number: ");
            var num1 = Convert.ToByte(Console.ReadLine());
            Console.Write("Enter third number: ");
            var num2 = Convert.ToByte(Console.ReadLine());
            Console.Write("Enter fourth number: ");
            var num3 = Convert.ToByte(Console.ReadLine());
            Console.Write("Enter fifth number: ");
            var num4 = Convert.ToByte(Console.ReadLine());

            //Console.WriteLine("{0} {1} {2} {3} {4}", num0, num1, num2, num3, num4);

            //это способ средствами языка
            if (num0 >= num1 && num0 >= num2 && num0 >= num3 && num0 >= num4)
                Console.WriteLine("The biggest number is {0}", num0);
            else if (num1 >= num0 && num1 >= num2 && num1 >= num3 && num1 >= num4)
                Console.WriteLine("The biggest number is {0}", num1);
            else if (num2 >= num1 && num2 >= num3 && num2 >= num4 && num1 >= num0)
                Console.WriteLine("The biggest number is {0}", num2);
            else if (num3 >= num1 && num3 >= num2 && num3 >= num4 && num3 >= num0)
                Console.WriteLine("The biggest number is {0}", num3);
            else
                Console.WriteLine("The biggest number is {0}", num4);

            //а это способ, который намного проще благодаря библиотечному методу
            Console.WriteLine("The biggest number is {0}", Math.Max(num0, Math.Max(num1, Math.Max(num2, Math.Max(num3, num4)))));
            //но есть еще проще способ, для того, кто ищет максимальное значение, если написать свой метод
            //здесь вся "магия" в слове params, оно заставляет компилятор принимать через запятую произвольное к-во параметров
            //а потом автоматически превращать его в массив
            Console.WriteLine("The biggest number is {0}", GetMaxValue(num0, num1, num2, num3, num4));



            Console.ReadKey();
        }

        //это тоже функция, просто с другим именем
        //здесь нужно обратить внимание на слово static - оно первое время должно быть в заголовке каждой функции, которую ты будешь создавать!
        //когда придет время - покажу что на самом деле это скорее исключение из правила, просто в простых программах static это правило :)
        static byte GetMaxValue(params byte[] values)
        {
            var max = values[0];
            for (var i = 0; i < values.Length; ++i)
                if (max < values[i])
                    max = values[i];
            return max;
        }
    }
}
